# Studio 1.0 development: M0 through M4

This source tree builds the **0.13.0 development preview**, not the final 1.0 release.
The stable 0.9 VSIX and installer remain unchanged. Node.js 22 and Python 3.11+
are used in CI. Building does not read personal model settings or contact a model.

```sh
npm ci
npm test
python test/bridge_test.py
python test/comfy_bridge_test.py
npm run build
npm run check:release
npm run package:preview
```

Optional real VS Code host checks (isolated profiles and fixture projects):

```sh
node test/run-host-suite.js
```

On headless Linux use `xvfb-run -a node test/run-host-suite.js`. The runner downloads
the pinned VS Code test build unless `VSCODE_EXECUTABLE` is set. These tests use
offline fixtures; they never use a personal SSH endpoint or model API key.
Only the Linux CI test launcher disables the Electron sandbox for the isolated
fixture host, because hosted runners restrict unprivileged user namespaces.
The packaged extension does not change VS Code sandbox settings.

## M0 release baseline

- Previous stable artifact: 0.9.0, repository commit `ac770fd`.
- Previous baseline: 50 passing Node tests, rerun during the 1.0 audit.
- Source, lockfile, license, tests and scripts are tracked together.
- CI runs on Windows, macOS and Linux and uploads a preview artifact only after
  checks. It does not publish to the Marketplace or replace the stable installer.
- `evals/cases.json` defines 20 real-task acceptance cases. Their model outcomes
  must be recorded separately; unit tests do not count as model task success.
- Configuration remains the existing `macstudio.*` VS Code settings. M1 defaults include command timeout (600 seconds) and background threshold (10
  seconds). M3 adds empty hooks and reviewed MCP effects, always requiring explicit tool selection and invocation approval. No connection settings or secrets are rewritten.

## M1 behavior

Long commands return a job ID after the background threshold. Live output appears
in Work. The agent checks the ID rather than launching the command again. A live
identical command in the same task and directory reuses that ID. Verification
waits for the exit result unless the user explicitly backgrounds it, in which
case it remains unverified and can be checked again.

Commands run with the user's OS permissions; this is **not an OS sandbox**.
Approval is once or for the exact command and canonical project directory in
the current task. A task grant also covers subsequent changes to scripts invoked
by that command. Work shows grants and supports revocation. They are never saved
or restored. Read-only/Plan mode, disabled command permission, pending edits and
unapproved plans still block dispatch.

Pause stops the current foreground operation and retains queued input. Existing
background commands remain visible and can be stopped individually. Stop also
requests termination of all owned commands in the task. Windows uses taskkill
with `/T /F`; POSIX uses an owned process group. Processes that deliberately escape
their process group, remote jobs and external services require separate management.
Never signal a PID loaded from a saved record.

While a response is running, Enter queues the next message. **Guide next step**
inserts guidance at the next safe model boundary; undispatched calls from the old
response receive explicit `not_executed` results. Completed effects are not rolled
back. Repeated identical calls pause after three executions (status polls are
excluded). The existing per-turn round limit remains a second bound.

## Persistence and upgrade

New conversation snapshots use schema 2, containing queued input and command IDs.
Schema 1 reads migrate in memory; restore writes an independent continuation and
preserves original snapshots. Unsupported future schemas are rejected. Image and
job formats retain their existing schema. Command metadata and `.log` files live
under extension global storage `commands/`; logs are capped at 8 MB and the chat
gets only the last 24,000 characters. Logs may contain project information and are
not included in release artifacts or automatically uploaded.

After extension-host restart, unfinished command records become
`interrupted_unknown`. Commands are neither restarted nor adopted by stale PID.
The user explicitly continues after inspecting actual state. This preview does
not promise background process survival across VS Code shutdown.

Rollback: reinstall the stable VSIX. The original 0.9 snapshots remain readable;
0.9 cannot load new schema-2 continuations. Back up global storage before testing
previews on important work. The development tests use isolated profiles.

## Deferred stages

The release-candidate acceptance stage remains separate. The full 20-case real-model
evaluation is still incomplete; unit and fixture passes do not replace it.

## M2 and M3

See [M2-M3.md](M2-M3.md) for current behavior, configuration, limits and recovery.

## M4

See [M4.md](M4.md) for isolated read-only subagents, searchable local history and
the tested connection wizard. This preview does not include parallel writing agents.
