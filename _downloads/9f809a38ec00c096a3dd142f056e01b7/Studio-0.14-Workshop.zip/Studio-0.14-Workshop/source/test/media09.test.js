const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const os=require('node:os');
const path=require('node:path');
const Module=require('node:module');
const {ImageStore,dimensions}=require('../src/images');
const settings={};
const load=Module._load;Module._load=function(name,...args){if(name==='vscode')return {workspace:{isTrusted:true,getConfiguration:()=>({get:(k,d)=>settings[k]??d})},env:{language:'en'}};return load.call(this,name,...args);};
const controller=require('../src/media-controller');Module._load=load;
const png=()=>{const data=Buffer.alloc(32);Buffer.from('89504e470d0a1a0a','hex').copy(data);data.write('IHDR',12);data.writeUInt32BE(512,16);data.writeUInt32BE(512,20);return data;};
test('image storage validates limits and keeps binary outside canonical history',async t=>{
 const root=await fs.mkdtemp(path.join(os.tmpdir(),'studio-image-'));t.after(()=>fs.rm(root,{recursive:true,force:true}));const store=new ImageStore(root);
 const asset=await store.add(png(),'fixture');assert.equal(asset.width,512);const canonical=[{role:'user',content:'Inspect image',images:[asset.id]}];
 const payload=await store.messages(canonical);assert.equal(typeof canonical[0].content,'string');assert.equal(payload[0].images,undefined);assert.equal(payload[0].content[1].image_url.url.startsWith('data:image/png;base64,'),true);
 const reloaded=new ImageStore(root);assert.equal((await reloaded.get(asset.id)).label,'fixture');await assert.rejects(reloaded.get('../outside'));
 assert.throws(()=>dimensions(Buffer.alloc(30)));const huge=png();huge.writeUInt32BE(9000,16);assert.throws(()=>dimensions(huge));
});
test('generation spec is bounded and cannot inject arbitrary ComfyUI nodes or paths',()=>{
 const good=controller.validateSpec({prompt:'Still life',extraNodes:'malicious'});assert.equal(good.extraNodes,undefined);assert.equal(good.width,512);
 for(const value of [{width:257},{count:5},{steps:100},{width:1536,height:1536},{seed:-1},{workflow:'arbitrary'},{prompt:''}])assert.throws(()=>controller.validateSpec({prompt:'fixture',...value}));
});
test('image requests need Review and explicit approval; uncertain submission is never replayed',async()=>{
 let requests=0;const a={...controller,permission:'readonly',session:'chat',imageJobs:new Map(),imageAssets:new Map(),services:{comfy:{models:['m'],encoders:['e'],vaes:['v'],checkedAt:Date.now()}},task:{steps:[]},requiresPlanApproval(){return require('../src/workflow').requiresPlanApproval(this.task,this.permission);},trusted(){},publish(){},add(){},checkpoint:async()=>{},saveImageJob:async()=>{},comfyTarget:()=>({host:'fixture',baseUrl:'http://127.0.0.1:8188'}),comfyRequest:async()=>{requests++;throw Error('Connection lost after submit');}};
 settings['comfy.enabled']=true;settings['comfy.model']='m';settings['comfy.encoder']='e';settings['comfy.vae']='v';a.comfyCatalogTarget=JSON.stringify(a.comfyTarget());
 await assert.rejects(a.proposeImage({prompt:'fixture'}),/Review/);a.permission='review';const proposed=await a.proposeImage({prompt:'fixture'});assert.equal(requests,0);assert.equal(proposed.status,'awaiting_approval');
 const duplicate=await a.proposeImage({prompt:'fixture'});assert.equal(duplicate.id,proposed.id);
 settings.allowImageGeneration=false;await assert.rejects(a.approveImage(proposed.id),/disabled/);assert.equal(requests,0);settings.allowImageGeneration=true;
 await a.approveImage(proposed.id);assert.equal(a.imageJobs.get(proposed.id).status,'unknown');await a.approveImage(proposed.id);assert.equal(requests,1);
 a.permission='plan';await assert.rejects(a.cancelImage(proposed.id),/Review/);
 await a.cancelImage('unowned');assert.equal(requests,1);
});


test('manual image request persists a chat and refresh coalesces without undoing cancellation',async()=>{
 settings['comfy.enabled']=true;settings.allowImageGeneration=true;
 const a={...controller,permission:'review',session:'blank',root:undefined,history:[],imageJobs:new Map(),imageAssets:new Map(),services:{comfy:{models:['m'],encoders:['e'],vaes:['v'],checkedAt:Date.now()}},trusted(){},publish(){},add(){return {};},project:async()=>{},checkpoint:async()=>{},saveImageJob:async()=>{},comfyTarget:()=>({host:'fixture'})};
 a.comfyCatalogTarget=JSON.stringify(a.comfyTarget());
 const draft=await a.proposeImage({prompt:'A leaf'},{fromUi:true});assert.match(a.history[0].content,/A leaf/);
 const job=a.imageJobs.get(draft.id);job.status='generating';let resolve,calls=0;
 a.comfyRequest=()=>{calls++;return new Promise(r=>resolve=r);};
 const first=a.refreshImageJob(job.id),second=a.refreshImageJob(job.id);assert.equal(calls,1);
 job.status='cancelled';resolve({status:'generating'});await Promise.all([first,second]);assert.equal(job.status,'cancelled');
});
