// Optional real-model acceptance. Supply endpoint credentials only through environment.
// Auto-review is restricted to the two disposable fixture files and one fixed test command.
const vscode=require('vscode');const fs=require('node:fs/promises');const path=require('node:path');const assert=require('node:assert/strict');
exports.run=async()=>{
 for(const key of ['STUDIO_EVAL_SSH_HOST','STUDIO_EVAL_MODEL','STUDIO_EVAL_API_KEY'])if(!process.env[key])throw Error('Missing evaluation environment: '+key);
 const ext=vscode.extensions.getExtension('yyang-local.macstudio-assistant'),a=await ext.activate();await a.ready;await a.newChat();const root=await a.project();
 const config=vscode.workspace.getConfiguration('macstudio');for(const [key,value] of Object.entries({contextTokens:131072,maxOutputTokens:2048,maxToolRounds:12,thinkingProtocol:'none',thinkingLevel:'default',timeoutSeconds:120}))await config.update(key,value,vscode.ConfigurationTarget.Global);
 const options={...a.options(),host:process.env.STUDIO_EVAL_SSH_HOST,mode:'direct',direct:{baseUrl:process.env.STUDIO_EVAL_BASE_URL||'http://127.0.0.1:11436/v1',model:process.env.STUDIO_EVAL_MODEL,apiKey:process.env.STUDIO_EVAL_API_KEY}};
 a.options=()=>options;a.connectionOptions=async()=>options;
 const original=vscode.window.showWarningMessage;
 vscode.window.showWarningMessage=async(message,options,...items)=>message.endsWith('\n\nnode verify.cjs')?items.find(x=>x==='Run once'||x==='运行一次'):undefined;
 const verify="const assert=require('node:assert/strict');const {add}=require('./math.cjs');const {total}=require('./invoice.cjs');assert.equal(add(2,3),5);assert.equal(total([]),0);assert.equal(total([{price:3,quantity:4},{price:5,quantity:2}]),22);console.log('Cross-file fixture passed');";
 try{
  await fs.writeFile(path.join(root,'math.cjs'),'exports.add=(a,b)=>a-b;\n');
  await fs.writeFile(path.join(root,'invoice.cjs'),"const {add}=require('./math.cjs');exports.total=lines=>lines.map(x=>x.price+x.quantity).reduce(add,0);\n");
  await fs.writeFile(path.join(root,'verify.cjs'),verify);
  const baseline=await a.runCommand('node verify.cjs',root,undefined,{waitForExit:true});assert.equal(baseline.exitCode,1);
  await a.setVerification('node verify.cjs');
  await a.send('Fix the two bugs in math.cjs and invoice.cjs. add must add numbers. Invoice total must sum price * quantity for every line and return 0 for an empty invoice. Preserve the exported APIs and do not edit verify.cjs. Inspect the files with local tools, then use local_propose_changes to propose one reviewed group editing both source files. Do not execute shell commands or create a plan; the fixture reviewer will apply your proposal and run node verify.cjs.');
  assert.equal(a.pending.size,1);const group=[...a.pending.values()][0];assert.ok(group.changes);assert.deepEqual(group.changes.map(x=>x.relative).sort(),['invoice.cjs','math.cjs']);assert.ok(group.changes.every(x=>x.before.exists&&x.after.exists));
  await a.applyAllAndVerify();
  assert.equal(await fs.readFile(path.join(root,'verify.cjs'),'utf8'),verify);assert.equal(a.task.checks.at(-1).status,'passed');assert.equal(a.pending.size,0);
  const report={version:ext.packageJSON.version,status:'passed',baselineExit:baseline.exitCode,verifiedExit:a.task.checks.at(-1).result.exitCode,appliedGroup:true,changedFiles:['math.cjs','invoice.cjs'],testsUnchanged:true,toolCalls:a.journal.map(x=>x.name),usage:a.metrics.lastUsage};
  await fs.writeFile(path.resolve(__dirname,'../test-results/model-task11.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
 }finally{vscode.window.showWarningMessage=original;await a.commandRunner.dispose();}
};
