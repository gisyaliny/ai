// Serve the real generated Webview and assets with synthetic messages, no model/credentials.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const originalLoad = Module._load;
const settings = {mode:'direct'};
const mock = {
  env:{language:process.env.PREVIEW_LANG||'en'}, EventEmitter: class { dispose() {} },
  workspace: {getConfiguration: () => ({get:(key,fallback)=>settings[key]??fallback})},
  Uri: {joinPath: (...parts) => parts.join('/')}
};
Module._load = function (name, ...args) { return name === 'vscode' ? mock : originalLoad.call(this, name, ...args); };
const { Assistant } = require('../src/extension');
Module._load = originalLoad;
const assistant = new Assistant({extensionUri:'', subscriptions:[]});
const view = {webview:{cspSource:"'self'", asWebviewUri:x=>x, onDidReceiveMessage:()=>{}, postMessage:()=>{}}};
assistant.resolveWebviewView(view);
const nonce = /script-src 'nonce-([^']+)'/.exec(view.webview.html)[1];
const html = view.webview.html.replace('</head>', `<script nonce="${nonce}" src="/fixture.js"></script><link rel="stylesheet" href="/theme.css"></head>`);
const fixture = `window.sent = []; window.acquireVsCodeApi = () => ({postMessage: m => window.sent.push(m),getState:()=>({}),setState:()=>{}});
window.fixtureState = {skillCommands:[{id:'fixture',name:'inspect',source:'Fixture',hint:'[file]'}],libraries:{active:1,available:72,automatic:true,sources:['Connected local libraries']},permissions:{files:true,commands:true,generation:true,mcp:true},mcpTools:[{id:'docs',source:'Extension settings',transport:'http',tools:[{name:'search_docs',enabled:true},{name:'update_issue',enabled:true,reviewRequired:true}]}],editor:{file:true,selection:true},connectionStatus:'connected',configuredModel:'local-coding-model',models:{items:['local-coding-model','another-model'],loading:false},thinking:{level:'on',protocol:'qwen',supported:['default','off','on'],parameters:{chat_template_kwargs:{enable_thinking:true}},capabilityReported:false},task:{id:'demo',constraints:['保持公开 API 不变','不要新增运行时依赖'],goal:'修复接口并验证测试',status:'awaiting_review',approved:true,repairAttempts:1,verificationCommand:'npm test',steps:[{title:'检查接口和测试',status:'done'},{title:'修复并验证',status:'running'}],checks:[{command:'npm test',status:'failed',result:{output:'Expected 3, got 2'}}]},edits:[{id:'checkpoint1',path:'demo.js',status:'applied',createdAt:'2026-11-19T00:00:00Z'}],compactionMethod:'semantic',compaction:{goal:'修复分页边界',semantic:{overview:'分页的结束位置少取了一项。已定位边界条件，修改尚待审阅；原测试失败，修复后的结果尚未验证。',decisions:['保持函数签名和返回结构不变'],nextSteps:['审阅 diff 后运行 npm test'],constraintCandidates:[{quote:'不要更改现有测试的预期值',sourceIndex:0}]}},mode:'direct',permission:'review',metrics:{inputTokens:4820,budget:27648,countSource:'保守估算（非精确 tokenizer）',lastUsage:{prompt_tokens:1210,completion_tokens:180},totalTokens:1390,usageReported:true},resolved:{model:'local-coding-model',transport:'SSH Python bridge'},instructions:['AGENTS.md','skills/review/SKILL.md'],mcp:['docs: 1 个允许的只读工具'],busy:false,project:'demo-project',connection:'已连接 · 演示数据',attachments:[],pending:[{id:'fixture',path:'demo.js',summary:'待审阅修改；只读模式不可应用'}],messages:[
 {id:'user',role:'user',text:'请展示 **Markdown** 样式和一段代码。'},
 {id:'reply',role:'assistant',text:'# Markdown 显示检查\\n\\n**加粗成功**，*斜体* 与 \`inline code\`。\\n\\n- 列表项目一\\n- 列表项目二\\n\\n> 引用说明：修改代码前先审阅。\\n\\n| 功能 | 状态 |\\n| --- | --- |\\n| Markdown | 正常 |\\n| 代码复制 | 可用 |\\n\\n\`\`\`javascript\\nfunction add(a, b) {\\n  return a + b;\\n}\\n\`\`\`\\n\\n[查看文档](https://example.com/docs)\\n\\n<script>window.injected = true</script>\\n\\n![禁止远程图片](https://example.com/tracking.png)'}]};
window.addEventListener('load', () => window.postMessage({type:'state',state:window.fixtureState},'*'));`;
const theme = `:root { --vscode-font-family:Arial,sans-serif; --vscode-editor-font-family:Consolas,monospace; --vscode-foreground:#202124; --vscode-sideBar-background:#fafafa; --vscode-descriptionForeground:#62666a; --vscode-panel-border:#d8dcdf; --vscode-button-secondaryForeground:#242424; --vscode-button-secondaryBackground:#eceff1; --vscode-button-secondaryHoverBackground:#dde3e6; --vscode-dropdown-background:#fff; --vscode-dropdown-foreground:#222; --vscode-input-background:#fff; --vscode-input-foreground:#222; --vscode-textCodeBlock-background:#edf0f3; --vscode-textLink-foreground:#0069b4; --vscode-button-background:#176b45; --vscode-button-foreground:#fff; --vscode-focusBorder:#176b45; }
@media(prefers-color-scheme:dark) { :root { --vscode-foreground:#e7e7e7; --vscode-sideBar-background:#202124; --vscode-descriptionForeground:#b2b7bc; --vscode-panel-border:#45494d; --vscode-button-secondaryForeground:#eee; --vscode-button-secondaryBackground:#363a3e; --vscode-dropdown-background:#303338; --vscode-dropdown-foreground:#eee; --vscode-input-background:#303338; --vscode-input-foreground:#eee; --vscode-textCodeBlock-background:#2b2f33; --vscode-textLink-foreground:#79baff; } }`;
const server=http.createServer((req,res)=>{
  if(req.url==='/favicon.ico'){res.writeHead(204);res.end();return;}
  if(req.url==='/'){res.setHeader('Content-Type','text/html; charset=utf-8');res.end(html);return;}
  if(req.url==='/demo-image.png'){res.setHeader('Content-Type','image/png');res.end(fs.readFileSync(path.resolve(__dirname,'../media/app-icon.png')));return;}
  if(req.url==='/fixture.js'){res.setHeader('Content-Type','text/javascript; charset=utf-8');res.end(fixture);return;}
  if(req.url==='/theme.css'){res.setHeader('Content-Type','text/css');res.end(theme);return;}
  const resources=['/media/workbench14.js','/media/experience13.js','/media/runtime10.js','/media/media09.js','/media/chat.css','/media/chat.js','/media/composer.js','/media/i18n.js','/media/mentions.js','/media/markdown.js','/media/vendor/markdown-it.min.js'];
  if(resources.includes(req.url)){res.setHeader('Content-Type',req.url.endsWith('.css')?'text/css':'text/javascript');res.end(fs.readFileSync(path.join(__dirname,'..',req.url)));return;}
  res.statusCode=404;res.end();
});
const port=Number(process.env.PREVIEW_PORT||18776);
server.listen(port,'127.0.0.1',()=>console.log('Synthetic Webview preview: http://127.0.0.1:'+port));
