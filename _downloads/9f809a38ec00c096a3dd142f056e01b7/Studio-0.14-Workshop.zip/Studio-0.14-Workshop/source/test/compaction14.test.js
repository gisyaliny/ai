'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const {frontier}=require('../src/compaction-policy'),{page}=require('../src/json-page'),{ReadProgress}=require('../src/read-progress');
test('compaction frontier keeps tool pairs together and advances inside a long active turn',()=>{
 const h=[{role:'user',content:'audit'}];for(let i=0;i<12;i++)h.push({role:'assistant',tool_calls:[{id:'t'+i}]},{role:'tool',tool_call_id:'t'+i});
 const cut=frontier(h);assert.ok(cut>0);assert.equal(h[cut].role,'assistant');assert.ok(h.length-cut>=8);assert.equal(frontier(h,cut),cut);
 h.push({role:'user',content:'new requirement'});assert.equal(frontier(h,cut),h.length-1);
});
test('JSON pages advance through minified records, preserve evidence, and reject misleading truncation',()=>{
 const text=JSON.stringify({packet:Array.from({length:180},(_,i)=>({item_id:i,review:'中文 / exact quote'}))});
 assert.equal(page(text).keys[0].count,180);let offset=0,items=[];
 do{const r=page(text,{pointer:'/packet',offset,limit:8});items.push(...r.items);offset=r.nextOffset;}while(offset!==null);
 assert.equal(items.length,180);assert.equal(new Set(items.map(x=>x.item_id)).size,180);assert.equal(items[179].review,'中文 / exact quote');
 assert.throws(()=>page(text,{pointer:'/__proto__'}),/not found/);assert.throws(()=>page(text,{pointer:'/packet',limit:51}));
 assert.equal(page(JSON.stringify(['x'.repeat(20000)]),{}).needsNarrowerPointer,true);
 assert.equal(page('{"a/b":{"~x":4}}',{pointer:'/a~1b/~0x'}).value,4);
});
test('changing line arguments does not disguise repeated covered reads',()=>{
 const g=new ReadProgress();assert.equal(g.observe('local_read_file',{path:'a'},{startLine:1,endLine:100,content:'all'}),false);
 for(let i=1;i<=3;i++)assert.equal(g.observe('local_read_file',{path:'a'},{startLine:i,endLine:i+1,content:'slice'+i}),i===3);
 assert.equal(g.observe('local_read_file',{path:'a'},{startLine:101,endLine:110,content:'new evidence'}),false);
});

test('fresh file revisions do not count as covered evidence',()=>{
 const g=new ReadProgress();
 for(let i=0;i<5;i++)assert.equal(g.observe('local_read_file',{path:'a'},{startLine:1,endLine:10,revision:'v'+i,content:'updated'+i}),false);
});

test('overlapping JSON pages trigger a report but fresh pages and revisions do not',()=>{
 const g=new ReadProgress(),args={path:'packet.json',pointer:'/items'};
 assert.equal(g.observe('local_read_json',args,{offset:0,items:[1,2,3,4],revision:'a'}),false);
 assert.equal(g.observe('local_read_json',args,{offset:1,items:[2,3],revision:'a'}),true);
 assert.equal(g.observe('local_read_json',args,{offset:4,items:[5,6],revision:'a'}),false);
 assert.equal(g.observe('local_read_json',args,{offset:0,items:[0,2],revision:'b'}),false);
});

test('empty thinking and raw tool templates are not reports; quoted examples remain valid',()=>{
 const {invalidReport}=require('../src/report');assert.equal(invalidReport('Thinking...'),true);assert.equal(invalidReport(''),true);assert.equal(invalidReport('<tool_call>data</tool_call>'),true);assert.equal(invalidReport('Example: <tool_call>data</tool_call>'),false);assert.equal(invalidReport('```xml\n<tool_call>data</tool_call>\n```'),false);
});
