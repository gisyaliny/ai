// Opt-in live regression: synthetic data in an isolated VS Code profile only.
const vscode=require('vscode');
const fs=require('node:fs/promises');
const path=require('node:path');
const assert=require('node:assert/strict');
exports.run=async()=>{
 assert.ok(process.env.STUDIO_FIX_HOST&&process.env.STUDIO_FIX_KEY&&process.env.STUDIO_FIX_MODEL,'Provide fixture connection through environment variables.');
 const extension=vscode.extensions.getExtension('yyang-local.macstudio-assistant');
 const a=await extension.activate();await a.ready;await a.newChat();const root=await a.project();
 const config=vscode.workspace.getConfiguration('macstudio');
 for(const [key,value]of Object.entries({mode:'direct',useServerTokenizer:true,contextTokens:32768,subagentContextTokens:16384,thinkingLevel:'off',thinkingProtocol:'qwen'}))await config.update(key,value,vscode.ConfigurationTarget.Global);
 const options={host:process.env.STUDIO_FIX_HOST,python:'/usr/bin/python3',mode:'direct',includeUsage:true,timeout:120,direct:{baseUrl:process.env.STUDIO_FIX_URL||'http://127.0.0.1:11436/v1',model:process.env.STUDIO_FIX_MODEL,apiKey:process.env.STUDIO_FIX_KEY}};
 a.connectionOptions=async()=>options;a.options=()=>options;a.permission='review';
 const text=('Synthetic audit evidence: preserve the public API and do not modify source. 项目为只读审阅测试。\n').repeat(180)+'Evidence marker: ORCHARD-42.\n';
 const file=path.join(root,'agent-fixture.md');await fs.writeFile(file,text);
 const started=await a.delegateTask({role:'review',maxRounds:3,task:'Read agent-fixture.md lines 1–200 using local_read_file exactly once, then report the evidence marker and restriction. The full file fits in this range. Do not list directories or search unrelated files.'});
 await a.agents.live.get(started.id)?.done;const job=await a.agentStatus(started.id);
 assert.equal(job.status,'completed',job.error);assert.equal(job.countSource,'服务端 tokenizer');assert.ok(job.inputTokens<16384);
 assert.ok(job.result.includes('ORCHARD-42'));assert.equal(await fs.readFile(file,'utf8'),text);
 assert.equal(a.pending.size,0);assert.equal(a.commandRunner.jobs.size,0);
 console.log(JSON.stringify({version:extension.packageJSON.version,liveSubagent:'passed',rounds:job.rounds,inputTokens:job.inputTokens,countSource:job.countSource,fixtureUnchanged:true}));
};
