const {hostExecutable}=require('./host-executable');
const fs = require('node:fs/promises');
const { spawn } = require('node:child_process');
const path = require('node:path');
async function main() {
  const run=process.env.MACSTUDIO_TEST_RUN||'';if(run&&!/^[a-z0-9-]+$/.test(run))throw new Error('Invalid test run name');
  const results=path.resolve(__dirname,'../test-results',run);
  const workspace = path.join(results, 'workspace');
  // macOS Unix-domain sockets reject profile paths longer than 103 characters.
  // The run hash keeps save/restore together while isolating other fixture runs.
  const profile=process.platform==='darwin'?path.join('/tmp','studio-'+require('node:crypto').createHash('sha256').update(results).digest('hex').slice(0,16)):path.join(results,'vscode-profile');
  await fs.mkdir(profile,{recursive:true});
  await fs.mkdir(workspace, { recursive: true });
  await fs.rm(path.join(workspace, 'new-fixture.txt'), { force: true });
  await fs.writeFile(path.join(workspace, 'fixture.txt'), 'first\noriginal\nlast\n');
  const executable=await hostExecutable();
  const log = await fs.open(path.join(results, 'host-run.log'), 'w');
  try { await new Promise((resolve, reject) => {
    // Pass argument boundaries directly: the workspace path contains spaces.
    const child = spawn(executable, [workspace, ...(process.env.CI&&process.platform==='linux'?['--no-sandbox']:[]), '--password-store=basic', '--use-mock-keychain', '--disable-extensions', '--disable-updates', '--skip-welcome', '--skip-release-notes', '--disable-workspace-trust', '--user-data-dir', profile, '--extensions-dir', path.join(results, 'extensions'), '--extensionDevelopmentPath=' + path.resolve(__dirname, '..'), '--extensionTestsPath=' + path.resolve(__dirname, process.env.MACSTUDIO_HOST_TEST || 'workflow-host.js')], { windowsHide: true, stdio: ['ignore', log.fd, log.fd] });
    const timeout=setTimeout(()=>{ child.kill('SIGKILL'); reject(new Error('Fixture host exceeded 180 seconds')); },Math.min(600000,Math.max(10000,Number(process.env.STUDIO_HOST_TIMEOUT_MS)||180000)));
    child.on('error', error=>{clearTimeout(timeout);reject(error);});
    child.on('close', (code,signal) => {clearTimeout(timeout);code === 0 ? resolve() : reject(new Error('Extension host test failed (' + code + ', '+signal+'); see '+path.join(results,'host-run.log')));});
  }); } catch(error) {
    console.error((await fs.readFile(path.join(results,'host-run.log'),'utf8')).slice(-12000));
    throw error;
  } finally { await log.close(); }
  console.log('VS Code extension host tests passed.');
}
main().catch(error => { console.error(error); process.exitCode = 1; });
