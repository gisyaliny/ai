'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const os=require('node:os');
const path=require('node:path');
const crypto=require('node:crypto');
const {CommandRunner}=require('../src/commands');
const {CommandGrants,assertEffect}=require('../src/permissions');
const {SessionStore}=require('../src/session');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const quote=s=>"'"+s.replace(/'/g,process.platform==='win32'?"''":"'\\''")+"'";
const invoke=file=>(process.platform==='win32'?'& ':'')+quote(process.execPath)+' '+quote(file);
async function fixture(t,source){const dir=await fs.mkdtemp(path.join(os.tmpdir(),'studio-runtime-'));const file=path.join(dir,'fixture.cjs');await fs.writeFile(file,source);const runner=new CommandRunner(path.join(dir,'logs'));t.after(async()=>{await runner.dispose();await fs.rm(dir,{recursive:true,force:true});});return {dir,runner,command:invoke(file)};}
test('task grants are exact, revocable, ephemeral and cannot override mode or plan',()=>{
 const g=new CommandGrants();g.allow('npm test','/repo','a');assert.ok(g.has('npm test','/repo','a'));
 for(const args of [['npm test; echo extra','/repo','a'],['npm test','/other','a'],['npm test','/repo','b']])assert.equal(g.has(...args),false);
 assert.equal(new CommandGrants().list('a').length,0);g.revoke(g.list('a')[0].id);assert.equal(g.list('a').length,0);
 for(const options of [{permission:'readonly'},{permission:'plan'},{permission:'review',enabled:false},{permission:'review',planApproved:false},{permission:'review',pending:true}])assert.throws(()=>assertEffect('commands',options));
});
test('commands stream output, return background IDs, persist logs and complete once',async t=>{
 const f=await fixture(t,"console.log('first');setTimeout(()=>console.log('last'),1200)");let notices=0;f.runner.onChange=()=>notices++;
 const id=await f.runner.start({command:f.command,cwd:f.dir,taskId:'task'});
 assert.equal((await f.runner.wait(id,{backgroundAfterMs:5})).status,'running');
 const result=await f.runner.wait(id,{backgroundAfterMs:Infinity});assert.equal(result.exitCode,0);assert.match(result.output,/first[\s\S]*last/);assert.ok(notices>=2);
 assert.match(await fs.readFile(path.join(f.runner.directory,id+'.log'),'utf8'),/last/);assert.equal((await f.runner.store.read(id)).status,'completed');
});
test('cancel kills the owned shell and its descendant process',async t=>{
 const f=await fixture(t,"const {spawn}=require('child_process');const fs=require('fs');const child=spawn(process.execPath,['-e',\"setInterval(()=>require('fs').writeFileSync('heartbeat',String(Date.now())),40)\"],{stdio:'inherit'});setInterval(()=>{},1000);");
 const id=await f.runner.start({command:f.command,cwd:f.dir,taskId:'tree'});
 for(let i=0;i<150&&!await fs.stat(path.join(f.dir,'heartbeat')).catch(()=>false);i++)await sleep(50);
 assert.ok(await fs.stat(path.join(f.dir,'heartbeat')));await f.runner.stop(id);
 const result=await f.runner.wait(id,{backgroundAfterMs:Infinity});assert.equal(result.status,'cancelled');
 const before=await fs.readFile(path.join(f.dir,'heartbeat'),'utf8');await sleep(250);assert.equal(await fs.readFile(path.join(f.dir,'heartbeat'),'utf8'),before);
});
test('timeout is distinct from success and restart never adopts or kills a stale PID',async t=>{
 const f=await fixture(t,'setInterval(()=>{},1000)');const id=await f.runner.start({command:f.command,cwd:f.dir,taskId:'timeout',timeoutMs:300});assert.equal((await f.runner.wait(id,{backgroundAfterMs:Infinity})).status,'timed_out');
 const stale=crypto.randomUUID();await f.runner.store.save({id:stale,session:stale,taskId:'old',status:'running',pid:process.pid,command:'never replay'});
 const restored=new CommandRunner(f.runner.directory);await restored.restore([stale]);assert.equal(restored.result(stale).status,'interrupted_unknown');await restored.stop(stale);assert.equal(restored.live.size,0);
});
test('disk failure prevents dispatch and aborted request never starts',async t=>{
 const f=await fixture(t,"require('fs').writeFileSync('must-not-exist','bad')");f.runner.store.save=async()=>{throw Error('disk full');};
 await assert.rejects(f.runner.start({command:f.command,cwd:f.dir,taskId:'disk'}),/disk full/);assert.equal(f.runner.live.size,0);
 const abort=new AbortController();abort.abort();await assert.rejects(f.runner.start({command:f.command,cwd:f.dir,taskId:'disk',signal:abort.signal}),/停止/);
 assert.equal(await fs.stat(path.join(f.dir,'must-not-exist')).catch(()=>false),false);
});
test('schema 1 sessions migrate on read without touching originals; unknown schemas fail',async t=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'studio-schema-'));t.after(()=>fs.rm(dir,{recursive:true,force:true}));const id=crypto.randomUUID(),file=path.join(dir,id+'.json');
 const old=JSON.stringify({schema:1,session:id,history:[{role:'user',content:'Preserve me'}]});await fs.writeFile(file,old);
 const store=new SessionStore(dir,{schema:2}),data=await store.read(id);assert.equal(data.schema,2);assert.equal(await fs.readFile(file,'utf8'),old);
 data.session=crypto.randomUUID();await store.save(data);assert.equal((await store.read(data.session)).history[0].content,'Preserve me');
 await fs.writeFile(file,JSON.stringify({session:id,schema:999}));await assert.rejects(store.read(id),/Invalid/);
});
