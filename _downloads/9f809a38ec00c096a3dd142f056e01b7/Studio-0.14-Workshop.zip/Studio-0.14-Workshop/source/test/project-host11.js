const vscode=require('vscode');const assert=require('node:assert/strict');const fs=require('node:fs/promises');const path=require('node:path');
exports.run=async()=>{
 const ext=vscode.extensions.getExtension('yyang-local.macstudio-assistant'),a=await ext.activate();await a.ready;await a.newChat();const root=await a.project();
 await fs.writeFile(path.join(root,'alpha.txt'),'one two');await fs.writeFile(path.join(root,'old.txt'),'rename me');await fs.writeFile(path.join(root,'delete.txt'),'keep snapshot');
 const group=await a.executeTool('local_propose_changes',{summary:'Fixture changes',operations:[{kind:'edit',path:'alpha.txt',edits:[{old_text:'one',new_text:'1'},{old_text:'two',new_text:'2'}]},{kind:'rename',path:'old.txt',to:'renamed.txt'},{kind:'delete',path:'delete.txt'},{kind:'create',path:'created.txt',content:'new'}]});
 assert.equal(a.pending.size,1);await a.apply(group.id);assert.equal(await fs.readFile(path.join(root,'alpha.txt'),'utf8'),'1 2');assert.equal(await fs.readFile(path.join(root,'renamed.txt'),'utf8'),'rename me');await assert.rejects(fs.stat(path.join(root,'delete.txt')),{code:'ENOENT'});
 let runs=[];a.runCommand=async command=>{runs.push(command);return {exitCode:0,output:'passed'};};await a.setVerification('first check\nsecond check');await a.verifyChanges();assert.deepEqual(runs,['first check','second check']);assert.equal(a.task.status,'verified');
 await fs.writeFile(path.join(root,'alpha.txt'),'external');assert.equal(await a.evidenceCurrent(a.task.checks.at(-1)),false);await assert.rejects(a.rewind(group.id),/changed/);await fs.writeFile(path.join(root,'alpha.txt'),'1 2');
 // Reloading the document is needed after an external file write before rewind.
 const doc=await vscode.workspace.openTextDocument(vscode.Uri.file(path.join(root,'alpha.txt')));for(let i=0;i<50&&doc.getText()!=='1 2';i++)await new Promise(r=>setTimeout(r,50));
 await a.rewind(group.id);assert.equal(await fs.readFile(path.join(root,'alpha.txt'),'utf8'),'one two');assert.equal(await fs.readFile(path.join(root,'old.txt'),'utf8'),'rename me');assert.equal(await fs.readFile(path.join(root,'delete.txt'),'utf8'),'keep snapshot');await assert.rejects(fs.stat(path.join(root,'created.txt')),{code:'ENOENT'});
 const uri=vscode.Uri.file(path.join(root,'alpha.txt')),open=await vscode.workspace.openTextDocument(uri),edit=new vscode.WorkspaceEdit();edit.insert(uri,new vscode.Position(0,0),'unsaved ');await vscode.workspace.applyEdit(edit);
 const read=await a.executeTool('local_read_file',{path:'alpha.txt'});assert.equal(read.unsaved,true);assert.match(read.content,/unsaved/);
 const pending=await a.executeTool('local_propose_changes',{summary:'Dirty guard',operations:[{kind:'edit',path:'alpha.txt',edits:[{old_text:'one',new_text:'ONE'}]}]});await assert.rejects(a.apply(pending.id),/unsaved/);await open.save();await a.apply(pending.id);
 // A partial apply is journaled before effects and can be reconciled/rewound.
 await fs.writeFile(path.join(root,'partial-a.txt'),'a');await fs.writeFile(path.join(root,'partial-b.txt'),'b');
 const partial=await a.executeTool('local_propose_changes',{summary:'Partial fixture',operations:[{kind:'edit',path:'partial-a.txt',edits:[{old_text:'a',new_text:'A'}]},{kind:'edit',path:'partial-b.txt',edits:[{old_text:'b',new_text:'B'}]}]});
 const write=a.writeChangeStates.bind(a);a.writeChangeStates=async changes=>{await fs.writeFile(changes[0].target,changes[0].after.text);throw Error('fixture interruption');};
 await assert.rejects(a.apply(partial.id),/interruption/);a.writeChangeStates=write;await a.reconcileEdits();assert.equal(a.edits.at(-1).status,'partial');await a.rewind(partial.id);assert.equal(await fs.readFile(path.join(root,'partial-a.txt'),'utf8'),'a');assert.equal(await fs.readFile(path.join(root,'partial-b.txt'),'utf8'),'b');
 const symbols=vscode.languages.registerDocumentSymbolProvider({scheme:'file',pattern:'**/alpha.txt'},{provideDocumentSymbols:()=>[new vscode.DocumentSymbol('FixtureSymbol','',vscode.SymbolKind.Function,new vscode.Range(0,0,0,1),new vscode.Range(0,0,0,1))]});
 try{const found=await a.executeTool('local_navigation',{path:'alpha.txt',kind:'symbols'});assert.ok(found.items.some(x=>x.name==='FixtureSymbol'));}finally{symbols.dispose();}
 a.runCommand=async()=>{const edit=new vscode.WorkspaceEdit();edit.insert(open.uri,new vscode.Position(0,0),'during-check ');await vscode.workspace.applyEdit(edit);return {exitCode:0,output:'command passed but file changed'};};
 await a.setVerification('check staleness');await a.verifyChanges();assert.equal(a.task.checks.at(-1).status,'stale');assert.notEqual(a.task.status,'verified');await open.save();
 const memory=await a.memoryFile();await fs.mkdir(path.dirname(memory),{recursive:true});await fs.writeFile(memory,'Keep the confirmed public API');await a.loadGuidance(root);assert.ok(a.projectInstructions.some(x=>x.text==='Keep the confirmed public API'));
 await vscode.commands.executeCommand('macstudio.open');for(let i=0;i<50&&!a.webviewReady;i++)await new Promise(r=>setTimeout(r,100));assert.ok(a.webviewReady);
 console.log('M2 grouped apply/rename/delete/rewind, dirty guard, recipe evidence and project memory passed.');
};
