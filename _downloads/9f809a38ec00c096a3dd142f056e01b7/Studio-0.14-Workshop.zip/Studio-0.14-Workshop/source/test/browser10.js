async page=>{
 const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:18795');
 await page.evaluate(()=>{Object.assign(window.fixtureState,{busy:true,run:{phase:'executing',commandId:'one'},inbox:[],commandJobs:[{id:'one',command:'npm test',status:'running',output:'first line',canStop:true}],commandGrants:[{id:'grant',command:'npm test',cwd:'demo-project'}]});window.postMessage({type:'state',state:fixtureState},'*');});
 await page.locator('#prompt').fill('Preserve the public API');await page.locator('#steerMessage').click();
 if(!await page.evaluate(()=>sent.some(x=>x.type==='queueInput'&&x.kind==='steer'&&x.text==='Preserve the public API')))throw Error('Steering event missing');
 await page.locator('#prompt').fill('Then explain the changes');await page.locator('#prompt').press('Enter');
 if(!await page.evaluate(()=>sent.some(x=>x.type==='queueInput'&&x.kind==='next')))throw Error('Queue event missing');
 await page.locator('#pauseTask').click();if(!await page.evaluate(()=>sent.some(x=>x.type==='pause')))throw Error('Pause event');
 await page.locator('#tab-work').click();await page.getByRole('button',{name:'Run in background',exact:true}).click();await page.getByRole('button',{name:'Stop command',exact:true}).click();await page.getByRole('button',{name:'Revoke',exact:true}).click();
 for(const type of ['backgroundCommand','stopCommand','revokeCommand'])if(!await page.evaluate(type=>sent.some(x=>x.type===type),type))throw Error(type);
 await page.getByRole('button',{name:'Stop command',exact:true}).focus();
 await page.evaluate(()=>{fixtureState.commandJobs[0].output='new streamed output';window.postMessage({type:'state',state:fixtureState},'*');});await page.waitForFunction(()=>document.querySelector('.command-job pre').textContent==='new streamed output');
 if(!await page.getByRole('button',{name:'Stop command',exact:true}).evaluate(e=>e===document.activeElement))throw Error('Streaming stole focus');
 for(const theme of ['light','dark']){await page.emulateMedia({colorScheme:theme});for(const width of [280,380,900]){await page.setViewportSize({width,height:900});if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth))throw Error('Horizontal overflow');}}
 await page.setViewportSize({width:380,height:940});await page.screenshot({path:'test-results/studio10-work.png'});
 await page.evaluate(()=>{fixtureState.busy=false;fixtureState.run={phase:'paused'};window.postMessage({type:'state',state:fixtureState},'*');});await page.locator('#resumeTask').click();if(!await page.evaluate(()=>sent.some(x=>x.type==='resume')))throw Error('Resume event');
 if(errors.length)throw Error(errors.join('\n'));
}
