const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { SSEReader, sshRequest } = require('../src/transport');
const { resolvePath, readText, listFiles, editText, hash } = require('../src/files');

test('SSE handles fragmented CRLF, multiple events and comments', () => {
  const events = [], parser = new SSEReader(x => events.push(x));
  for (const piece of [': ping\r\n\r\nda', 'ta: {"v":"中文"}\r', '\n\r\ndata: [DO', 'NE]\n\n']) parser.push(piece);
  assert.deepEqual(events, ['{"v":"中文"}', '[DONE]']);
});

test('workspace access rejects traversal, credentials and escaping symlinks', async t => {
  const temp = await fs.mkdtemp(path.join(os.tmpdir(), 'macstudio-path-'));
  t.after(() => fs.rm(temp, { recursive: true, force: true }));
  const root = path.join(temp, 'project'), outside = path.join(temp, 'outside');
  await fs.mkdir(root); await fs.mkdir(outside);
  await fs.writeFile(path.join(root, 'hello.txt'), 'hello');
  await fs.writeFile(path.join(root, '.env'), 'not-a-real-secret');
  await fs.symlink(outside, path.join(root, 'escape'), process.platform === 'win32' ? 'junction' : 'dir');
  await fs.mkdir(path.join(root, '.ssh'));
  await fs.symlink(path.join(root, '.ssh'), path.join(root, 'hidden-link'), process.platform === 'win32' ? 'junction' : 'dir');
  for (const value of ['../outside/x', '..\\outside\\x', '/etc/passwd', 'C:\\Users\\x', '.env', '.ssh/key', 'a.pem', '.git/config', 'escape/new.txt', 'hidden-link/file']) {
    await assert.rejects(resolvePath(root, value), undefined, value);
  }
  assert.equal(await readText(root, 'hello.txt'), 'hello');
  assert.deepEqual((await listFiles(root)).files, ['hello.txt']);
  await fs.writeFile(path.join(root, 'binary.bin'), Buffer.from([0, 1, 2]));
  await assert.rejects(readText(root, 'binary.bin'));
});

test('edits require unique exact anchors and preserve surrounding content', () => {
  assert.equal(editText('a\nb\nc', 'b', 'B', true), 'a\nB\nc');
  assert.throws(() => editText('a a', 'a', 'b', true));
  assert.throws(() => editText('a', 'x', 'b', true));
  assert.throws(() => editText('a', '', 'b', true));
  assert.equal(editText('', '', 'new', false), 'new');
  assert.notEqual(hash('original'), hash('changed'));
});

test('SSH refuses option-shaped host and pre-cancelled requests', async () => {
  await assert.rejects(sshRequest({ host: '-oProxyCommand=bad' }, {}), /SSH/);
  const controller = new AbortController(); controller.abort();
  await assert.rejects(sshRequest({ host: 'macstudio' }, {}, controller.signal), /停止/);
});
