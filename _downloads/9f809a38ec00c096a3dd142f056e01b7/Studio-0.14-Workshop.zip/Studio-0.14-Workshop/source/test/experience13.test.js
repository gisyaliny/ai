const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs/promises');const path=require('node:path');const os=require('node:os');const crypto=require('node:crypto');
const {ResearchAgents}=require('../src/agents');const {SessionStore}=require('../src/session');const {validateConnection,diagnosis}=require('../src/connection');
async function fixture(t){const dir=await fs.mkdtemp(path.join(os.tmpdir(),'studio-m4-'));t.after(()=>fs.rm(dir,{recursive:true,force:true}));return dir;}
async function finish(manager,id){for(let i=0;i<100;i++){const entry=manager.live.get(id);if(!entry)return manager.jobs.get(id);if(entry.done){await entry.done;return manager.jobs.get(id);}await new Promise(r=>setTimeout(r,10));}throw Error('Agent did not finish');}
const definition=name=>({type:'function',function:{name,description:name,parameters:{type:'object'}}});
test('subagents enforce read-only dispatch and budgets, persist results, and restore without replay',async t=>{
 const dir=await fixture(t),m=new ResearchAgents(dir),taskId=crypto.randomUUID();t.after(()=>m.dispose());let calls=0,executed=[];
 const args={taskId,task:'Inspect fixture',model:'fixture',system:'Pinned: preserve API',tools:[definition('local_read_file'),definition('local_run_command')],complete:async(payload,signal,onMeta)=>{assert.ok(!payload.tools.some(t=>t.function.name==='local_run_command'));onMeta({usage:{total_tokens:40}});if(calls++===0)return {role:'assistant',content:'',tool_calls:[{id:'bad',type:'function',function:{name:'local_run_command',arguments:'{}'}},{id:'read',type:'function',function:{name:'local_read_file',arguments:'{"path":"fixture.txt"}'}}]};return {role:'assistant',content:'Finding: fixture.txt:1'};},execute:async(name)=>{executed.push(name);return {text:'fixture'};}};
 const first=await m.start(args),job=await finish(m,first.id);assert.equal(job.status,'completed');assert.deepEqual(executed,['local_read_file']);assert.deepEqual(job.evidence,['fixture.txt']);assert.equal(job.usage,80);assert.match(job.history.find(x=>x.tool_call_id==='bad').content,/read-only/);
 const restored=new ResearchAgents(dir);await restored.restore([job.id],taskId);assert.equal(restored.summary(job.id,taskId).result,job.result);assert.equal(restored.live.size,0);
 const blocked=await m.start({...args,system:'x'.repeat(17000),contextTokens:4096});assert.equal((await finish(m,blocked.id)).status,'budget_exceeded');assert.equal(calls,2);
 await m.store.save({...job,status:'running',session:job.id});await restored.restore([job.id],taskId);assert.equal(restored.summary(job.id,taskId).status,'interrupted');assert.equal(restored.live.size,0);await assert.rejects(m.start({...args,maxRounds:99}),/Invalid/);
});
test('subagents queue under the configured limit, cancel queued/live jobs, and never persist closures or credentials',async t=>{
 const dir=await fixture(t),m=new ResearchAgents(dir),taskId=crypto.randomUUID();t.after(()=>m.dispose());let entered=0;
 const options={taskId,task:'Slow fixture',model:'fixture',system:'safe',tools:[],complete:(p,signal)=>new Promise((resolve,reject)=>{entered++;signal.addEventListener('abort',()=>reject(Error('cancelled')),{once:true});}),execute:async()=>{throw Error('unused');}};
 const a=await m.start(options),same=await m.start(options),b=await m.start({...options,task:'Another fixture'});assert.equal(a.id,same.id);assert.equal(m.summary(b.id,taskId).status,'queued');await m.cancel(b.id,taskId);assert.equal(m.summary(b.id,taskId).status,'cancelled');await m.cancel(a.id,taskId);assert.equal(m.summary(a.id,taskId).status,'cancelled');assert.equal(entered,1);const record=await m.store.read(a.id);assert.ok(!('complete'in record));assert.ok(!('execute'in record));await assert.rejects(m.cancel(a.id,'other'),/Unknown/);
});
test('history metadata follows all continuations, supports text search/archival and survives later saves',async t=>{
 const store=new SessionStore(await fixture(t),{schema:2}),conversationId=crypto.randomUUID(),one=crypto.randomUUID(),two=crypto.randomUUID();const base={conversationId,root:'/fixture',messages:[{role:'user',text:'Initial title'},{role:'assistant',text:'Unique result needle'}]};await store.save({...base,session:one});await store.save({...base,session:two});assert.equal((await store.list({conversations:true,summaries:true,query:'needle'})).length,1);
 await store.updateMetadata(conversationId,{title:'Named chat',pinned:true});await store.save({...base,session:two});const row=(await store.list({conversations:true,summaries:true}))[0];assert.equal(row.title,'Named chat');assert.equal(row.pinned,true);assert.equal(row.conversationId,conversationId);
 await store.updateMetadata(conversationId,{archived:true});assert.equal((await store.list({conversations:true})).length,0);assert.equal((await store.list({conversations:true,includeArchived:true})).length,1);await store.updateMetadata(conversationId,{archived:false});assert.equal((await store.list({conversations:true})).length,1);await assert.rejects(store.updateMetadata('../escape',{title:'x'}),/Invalid/);await assert.rejects(store.updateMetadata(conversationId,{title:'x'.repeat(161)}),/Invalid/);
 await fs.writeFile(path.join(store.directory,conversationId+'.meta.json'),'broken');assert.equal((await store.list({conversations:true})).length,1);
});
test('connection validation and diagnosis reject unsafe endpoints and preserve SSH trust checks',()=>{
 const good={host:'alias',direct:{baseUrl:'http://127.0.0.1:11436/v1',model:'fixture'}};assert.equal(validateConnection(good),good);for(const host of ['-oProxyCommand=x','user@host;rm','bad host'])assert.throws(()=>validateConnection({...good,host}));for(const baseUrl of ['http://public.example/v1','http://u:p@localhost/v1','http://localhost/v1?key=x'])assert.throws(()=>validateConnection({...good,direct:{...good.direct,baseUrl}}));assert.equal(diagnosis(Error('Host key verification failed')).code,'host_key');assert.equal(diagnosis(Error('HTTP 401 secret')).code,'api_auth');assert.ok(!JSON.stringify(diagnosis(Error('HTTP 401 private-key'))).includes('private-key'));
});

test('subagents stop on storage failure and reject a reply after authorization changes',async t=>{
 const m=new ResearchAgents(await fixture(t)),taskId=crypto.randomUUID();t.after(()=>m.dispose());let calls=0,saves=0;const save=m.store.save.bind(m.store);m.store.save=v=>++saves===1?save(v):Promise.reject(Error('disk full'));
 const args={taskId,task:'Inspect',model:'fixture',system:'safe',tools:[],complete:async()=>{calls++;return {role:'assistant',content:'reply'};},execute:async()=>{}};const first=await m.start(args);await finish(m,first.id);assert.equal(calls,0);assert.equal(m.summary(first.id,taskId).status,'failed');assert.match(m.summary(first.id,taskId).error,/could not be saved/);
 m.store.save=save;let authorized=true;const next=await m.start({...args,task:'Next',authorize:()=>{if(!authorized)throw Error('connection changed');},complete:async()=>{authorized=false;return {role:'assistant',content:'stale reply'};}});await finish(m,next.id);assert.equal(m.summary(next.id,taskId).status,'failed');assert.equal(m.summary(next.id,taskId).result,undefined);
});


test('agent status waits for findings, times out without replay, honors abort and task isolation',async t=>{
 const m=new ResearchAgents(await fixture(t)),taskId=crypto.randomUUID();t.after(()=>m.dispose());
 let release,calls=0;const started=await m.start({taskId,task:'Wait fixture',model:'fixture',system:'Read only',tools:[],complete:async()=>{calls++;return new Promise(r=>{release=r;});},execute:async()=>{throw Error('unused');}});
 while(!release)await new Promise(r=>setTimeout(r,5));
 await assert.rejects(m.wait(started.id,'other'),/Unknown/);
 const pending=await m.wait(started.id,taskId,{timeoutMs:20});assert.equal(pending.status,'running');assert.equal(calls,1);
 const stop=new AbortController();const aborted=m.wait(started.id,taskId,{signal:stop.signal});stop.abort();await assert.rejects(aborted,{name:'AbortError'});
 const waiting=m.wait(started.id,taskId);release({role:'assistant',content:'Completed finding'});const result=await waiting;assert.equal(result.status,'completed');assert.equal(result.result,'Completed finding');assert.equal(calls,1);
});


test('subagents measure tokens before trimming, use reported usage, and reserve a final report round',async t=>{
 const m=new ResearchAgents(await fixture(t)),taskId=crypto.randomUUID();t.after(()=>m.dispose());let calls=0,measures=0;
 const large='Evidence stays available. '.repeat(800);
 const job=await m.start({taskId,task:'Inspect named file',model:'fixture',system:'Read only',tools:[definition('local_read_file')],maxRounds:2,
  measure:async(messages)=>{measures++;return {count:2000,source:'Server tokenizer'};},
  complete:async(p,signal,meta)=>{calls++;meta({usage:{total_tokens:2500}});if(calls===1)return {role:'assistant',content:'',tool_calls:[{id:'read',type:'function',function:{name:'local_read_file',arguments:'{"path":"target.txt"}'}}]};assert.equal(p.tool_choice,'none');assert.equal(p.tools.length,0);assert.ok(p.messages.at(-1).content.includes(large));return {role:'assistant',content:'Evidence summary'};},execute:async()=>({content:large})});
 const result=await finish(m,job.id);assert.equal(result.status,'completed');assert.equal(measures,2);assert.equal(result.inputTokens,2000);assert.equal(result.countSource,'Server tokenizer');assert.equal(result.budgetUsed,5000);assert.equal(result.compacted,undefined);
});

test('subagents trim overflowing tool output without changing saved history and cannot dispatch final-round tools',async t=>{
 const m=new ResearchAgents(await fixture(t)),taskId=crypto.randomUUID();t.after(()=>m.dispose());let calls=0,executed=0;
 const large='x'.repeat(23000),args={taskId,task:'Read fixture',model:'fixture',system:'Read only',contextTokens:16384,maxRounds:2,tools:[definition('local_read_file')],
 complete:async p=>{calls++;if(calls===2){assert.equal(p.tool_choice,'none');assert.ok(!p.messages.at(-1).content.includes(large));}return {role:'assistant',content:'Partial evidence',tool_calls:[{id:'r'+calls,type:'function',function:{name:'local_read_file',arguments:'{"path":"fixture.txt"}'}}]};},execute:async()=>{executed++;return {content:large};}};
 const job=await m.start(args),result=await finish(m,job.id);assert.equal(result.status,'round_limit');assert.equal(result.compacted,true);assert.equal(executed,1);assert.ok(result.history.some(x=>x.role==='tool'&&x.content.includes(large)));
});

test('subagents turn overlapping JSON re-reads into a final findings response',async t=>{
 const m=new ResearchAgents(await fixture(t)),taskId=crypto.randomUUID();t.after(()=>m.dispose());let calls=0,reads=0;
 const job=await m.start({taskId,task:'Review records',model:'fixture',system:'Read only',tools:[definition('local_read_json')],maxRounds:8,
 complete:async p=>{calls++;if(calls===3){assert.equal(p.tool_choice,'none');return {role:'assistant',content:'Reviewed the two records; findings and remaining coverage.'};}return {role:'assistant',content:'',tool_calls:[{id:'r'+calls,type:'function',function:{name:'local_read_json',arguments:JSON.stringify({path:'packet.json',pointer:'/items',offset:calls-1,limit:calls===1?2:1})}}]};},
 execute:async(name,args)=>{reads++;return {offset:args.offset,items:args.offset?[2]:[1,2],revision:'same'};}});
 const result=await finish(m,job.id);assert.equal(result.status,'completed');assert.equal(result.repeatedReads,true);assert.equal(reads,2);assert.equal(calls,3);
});

test('tool-template text is rejected as findings and never dispatched',async t=>{
 const m=new ResearchAgents(await fixture(t)),taskId=crypto.randomUUID();t.after(()=>m.dispose());let dispatched=0;
 const job=await m.start({taskId,task:'Read and report',model:'fixture',system:'Read only',tools:[],complete:async()=>({role:'assistant',content:'<tool_call>\n<function=local_read_json>\n</function>\n</tool_call>'}),execute:async()=>{dispatched++;}});
 const result=await finish(m,job.id);assert.equal(result.status,'failed');assert.match(result.error,/tool markup/);assert.equal(dispatched,0);assert.equal(result.result,undefined);
});
