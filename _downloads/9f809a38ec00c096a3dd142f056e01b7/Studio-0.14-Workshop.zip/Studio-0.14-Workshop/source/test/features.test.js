const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const os=require('node:os');
const path=require('node:path');
const crypto=require('node:crypto');
const {SessionStore,repairHistory}=require('../src/session');
const {prepareContext,allowed}=require('../src/context');
const project=require('../src/project');
async function fixture(t){const dir=await fs.mkdtemp(path.join(os.tmpdir(),'macagent-'));t.after(()=>fs.rm(dir,{recursive:true,force:true}));return dir;}
test('atomic session writes retain results and proposals; corrupt files are left intact',async t=>{
  const dir=await fixture(t),store=new SessionStore(dir),session=crypto.randomUUID();
  await Promise.all([store.save({session,history:[1]}),store.save({session,history:[1,2],pending:[{updated:'review me'}],journal:[{result:'done'}]})]);
  const corrupt=path.join(dir,crypto.randomUUID()+'.json');await fs.writeFile(corrupt,'broken');
  const rows=await store.list();assert.equal(rows.length,1);assert.deepEqual(rows[0].history,[1,2]);assert.equal(rows[0].pending[0].updated,'review me');assert.equal(rows[0].journal[0].result,'done');
  assert.equal(await fs.readFile(corrupt,'utf8'),'broken');assert.equal((await fs.readdir(dir)).filter(x=>x.endsWith('.tmp')).length,0);
  await assert.rejects(store.save({session:'../../escape'}));
});
test('recovery pairs every tool call, distinguishes unknown from unstarted, and isolates reused IDs',()=>{
  const history=[{role:'user',content:'task'},{role:'assistant',content:'',tool_calls:[{id:'same'},{id:'next'}]}];
  const repaired=repairHistory(history,[{id:'same',messageIndex:1,status:'started'}]);
  assert.equal(JSON.parse(repaired[2].content).status,'interrupted_unknown');assert.equal(JSON.parse(repaired[3].content).status,'not_executed');assert.equal(history.length,2);
  const again=[...repaired,{role:'user',content:'new'},{role:'assistant',tool_calls:[{id:'same'}]}];
  assert.equal(JSON.parse(repairHistory(again,[{id:'same',messageIndex:1,result:{status:'old'}}]).at(-1).content).status,'not_executed');
  assert.deepEqual(repairHistory(repaired),repaired);
});

test('global history imports legacy files without overwriting and groups resumed conversations without a 100-file cutoff',async t=>{
  const dir=await fixture(t),legacy=new SessionStore(path.join(dir,'legacy')),store=new SessionStore(path.join(dir,'global'));
  const session=crypto.randomUUID(),other=crypto.randomUUID();
  await legacy.save({session,root:'project-a',messages:[{role:'user',text:'Original question'}],history:[]});
  await store.importLegacy([legacy.directory]);
  await store.save({session,root:'project-a',messages:[{role:'user',text:'Updated question'}],history:[]});
  await store.importLegacy([legacy.directory]);
  assert.equal((await store.read(session)).messages[0].text,'Updated question');
  assert.equal((await legacy.read(session)).messages[0].text,'Original question');
  await store.save({session:other,conversationId:session,root:'project-a',messages:[{role:'user',text:'Updated question'},{role:'assistant',text:'Resumed'}],history:['retained']});
  await fs.utimes(path.join(store.directory,session+'.json'),new Date(0),new Date(0));
  for(let i=0;i<101;i++)await store.save({session:crypto.randomUUID(),root:'project-b',messages:[{role:'user',text:'Other project'}]});
  const rows=await store.list({roots:['project-a'],conversations:true,summaries:true});
  assert.equal(rows.length,1);assert.equal(rows[0].session,other);assert.equal(rows[0].history,undefined);
  assert.deepEqual((await store.read(rows[0].session)).history,['retained']);
  assert.equal((await store.list({conversations:true})).length,102);
  await assert.rejects(store.read('../escape'));
});
test('context compaction preserves canonical history and complete tool pairs',()=>{
  const history=[{role:'user',content:'old '.repeat(3000)},{role:'assistant',content:'',tool_calls:[{id:'x'}]},{role:'tool',tool_call_id:'x',content:'data '.repeat(2000)},{role:'assistant',content:'done'},{role:'user',content:'current request'}];
  const original=JSON.stringify(history),result=prepareContext('system',history,[],4000);
  assert.equal(JSON.stringify(history),original);assert.ok(result.compacted);assert.equal(result.omittedTurns,1);assert.ok(result.estimatedTokens<=4000);assert.equal(result.messages.at(-1).content,'current request');assert.ok(!result.messages.some(m=>m.role==='tool'));
  assert.ok(prepareContext('s',[{role:'user',content:'x'.repeat(10000)}],[],4000).estimatedTokens>4000);
});
test('permission allowlist denies local effects in both read-only modes',()=>{
  for(const mode of ['readonly','plan']){assert.equal(allowed('local_run_command',mode),false);assert.equal(allowed('local_propose_edit',mode),false);assert.equal(allowed('local_diagnostics',mode),true);assert.equal(allowed('unknown',mode),false);}
  assert.equal(allowed('local_run_command','review'),true);assert.equal(allowed('mcp_x','plan',new Set(['mcp_x'])),true);
});
test('search finds files beyond 400, respects ignores, reports pages, and supports narrowing',async t=>{
  const dir=await fixture(t);await fs.mkdir(path.join(dir,'sub'));
  await fs.writeFile(path.join(dir,'.gitignore'),'ignored.txt\nsub/hidden.txt\n');
  await Promise.all(Array.from({length:430},(_,i)=>fs.writeFile(path.join(dir,`${String(i).padStart(3,'0')}.txt`),i===429?'needle':'nothing')));
  await fs.writeFile(path.join(dir,'ignored.txt'),'needle');await fs.writeFile(path.join(dir,'sub','hidden.txt'),'needle');
  const result=await project.search(dir,'needle');assert.equal(result.matches.length,1);assert.equal(result.matches[0].path,'429.txt');assert.ok(result.scanned>400);
  assert.equal((await project.search(dir,'needle',{directory:'sub'})).matches.length,0);
  await fs.writeFile(path.join(dir,'sub','page.txt'),Array(35).fill('paged').join('\n'));
  const first=await project.search(dir,'paged'),second=await project.search(dir,'paged',{offset:first.nextOffset});assert.equal(first.matches.length,30);assert.equal(second.matches.length,5);assert.equal(second.nextOffset,null);
});
test('project guidance follows root-to-file scope; skill discovery is bounded',async t=>{
  const dir=await fixture(t);await fs.mkdir(path.join(dir,'sub'));await fs.mkdir(path.join(dir,'skills','testing'),{recursive:true});
  await fs.writeFile(path.join(dir,'AGENTS.md'),'Root guidance');await fs.writeFile(path.join(dir,'sub','CLAUDE.md'),'Nested guidance');await fs.writeFile(path.join(dir,'skills','testing','SKILL.md'),'Skill content');
  const guide=await project.instructions(dir,path.join(dir,'sub','file.js'));assert.deepEqual(guide.map(x=>x.text),['Root guidance','Nested guidance']);
  assert.equal((await project.instructions(dir,path.join(os.tmpdir(),'outside.js'))).length,1);assert.equal((await project.skills(dir))[0].text,'Skill content');
});

test('search canonicalizes an aliased project root without following escaping links',async t=>{
  const dir=await fixture(t),real=path.join(dir,'real'),alias=path.join(dir,'alias'),outside=path.join(dir,'outside');
  await fs.mkdir(real);await fs.mkdir(outside);await fs.writeFile(path.join(real,'found.txt'),'needle');
  await fs.writeFile(path.join(outside,'private.txt'),'needle');
  await fs.symlink(real,alias,process.platform==='win32'?'junction':'dir');
  await fs.symlink(outside,path.join(real,'escape'),process.platform==='win32'?'junction':'dir');
  const result=await project.search(alias,'needle');
  assert.deepEqual(result.matches.map(x=>x.path),['found.txt']);
  await assert.rejects(project.search(alias,'needle',{directory:'escape'}));
});
