"""Offline regression: direct mode works without OpenClaw and rejects nonlocal URLs."""
import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import subprocess
import sys
import threading
import unittest


class BridgeTest(unittest.TestCase):
    def test_health_needs_no_credentials_or_model_config(self):
        result = subprocess.run([sys.executable, str(Path(__file__).parents[1] / 'src' / 'bridge.py')], input=json.dumps({'operation': 'health'}), text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue(json.loads(result.stdout)['ok'])

    def test_direct_transport(self):
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                if self.headers.get('Authorization') != 'Bearer fixture-key':
                    self.send_response(401)
                    self.end_headers()
                    self.wfile.write(b'Invalid fixture-key')
                    return
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b'{"data":[{"id":"fixture-model"}]}')

            def log_message(self, *args):
                pass

        server = HTTPServer(('127.0.0.1', 0), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        request = {'mode': 'direct', 'operation': 'probe', 'config': 'does-not-exist.json',
                   'direct': {'baseUrl': f'http://127.0.0.1:{server.server_port}/v1',
                              'model': 'fixture-model', 'apiKey': 'fixture-key'}}

        def run():
            return subprocess.run([sys.executable, str(Path(__file__).resolve().parents[1] / 'src/bridge.py')],
                                  input=json.dumps(request), text=True, capture_output=True, timeout=5)

        result = run()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['models'], ['fixture-model'])
        for url in ['http://example.com/v1', 'file:///etc/passwd', 'http://user:pass@127.0.0.1/v1']:
            request['direct']['baseUrl'] = url
            result = run()
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('loopback', result.stderr)


if __name__ == '__main__':
    unittest.main()
