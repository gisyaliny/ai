const vscode=require('vscode');
const fs=require('node:fs/promises');
const path=require('node:path');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const {SessionStore}=require('../src/session');
exports.run=async()=>{
 const ext=vscode.extensions.getExtension('yyang-local.macstudio-assistant');
 assert.equal(ext.packageJSON.version,require('../package.json').version);
 const a=await ext.activate();await a.ready;
 const root=await fs.realpath(vscode.workspace.workspaceFolders[0].uri.fsPath);
 assert.equal(a.store.directory,path.join(a.context.globalStorageUri.fsPath,'sessions'));
 const marker=path.join(root,'history-test.json');
 if(process.env.STUDIO082_PHASE==='save'){
  const legacy=new SessionStore(path.join(a.context.storageUri.fsPath,'sessions'));
  const session=crypto.randomUUID();
  await legacy.save({session,root,messages:[{id:'u',role:'user',text:'Resume this saved coding task'}],history:[{role:'user',content:'Resume this saved coding task'},{role:'assistant',content:'',tool_calls:[{id:'interrupted',type:'function',function:{name:'local_run_command',arguments:'{"command":"must not run"}'}}]}],journal:[{id:'interrupted',messageIndex:1,name:'local_run_command',status:'started'}],pending:[{id:'proposal',relative:'fixture.txt',summary:'Needs review',status:'pending'}],task:{constraints:['Preserve the API'],status:'running'}});
  await a.initialize();
  assert.equal(a.messages[0].text,'Resume this saved coding task');
  assert.equal(a.pending.size,1);assert.equal(a.task.status,'interrupted');
  assert.equal(a.journal[0].status,'interrupted_unknown');
  assert.equal((await legacy.read(session)).journal[0].status,'started');
  await fs.writeFile(marker,JSON.stringify({conversationId:session,session:a.session}));
 }else{
  const previous=JSON.parse(await fs.readFile(marker,'utf8'));
  assert.equal(a.conversationId,previous.conversationId);
  assert.notEqual(a.session,previous.session);
  assert.equal(a.pending.size,1);assert.deepEqual(a.task.constraints,['Preserve the API']);
  assert.equal(JSON.parse(a.history.at(-1).content).status,'interrupted_unknown');
  const rows=await a.store.list({conversations:true,summaries:true});
  assert.equal(rows.filter(r=>r.title==='Resume this saved coding task').length,1);
  const originalPicker=vscode.window.showQuickPick;let executions=0;
  a.executeTool=async()=>{executions++;};
  vscode.window.showQuickPick=async(items)=>{const rows=await items;assert.ok(rows[0].description);return rows[0];};
  try{await a.restoreSession();}finally{vscode.window.showQuickPick=originalPicker;}
  assert.equal(executions,0);assert.equal(a.pending.size,1);
  await a.newChat();assert.notEqual(a.conversationId,previous.conversationId);
 }
 await vscode.commands.executeCommand('macstudio.open');
 console.log('Local history migration/restart/load passed: '+process.env.STUDIO082_PHASE);
};
