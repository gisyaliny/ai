const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const Module=require('node:module');
const settings={mode:'direct',modelId:'fixture-model',contextTokens:32768,maxOutputTokens:1024,maxToolRounds:6,includeUsage:true};
let completionImpl,callCount=0,sshImpl=async()=>JSON.stringify({model:'fixture-model',mode:'direct'});
const mock={EventEmitter:class{dispose(){}},ConfigurationTarget:{Global:1},Uri:{file:p=>({scheme:'file',fsPath:p,toString:()=>p})},workspace:{isTrusted:true,workspaceFolders:[],textDocuments:[],getConfiguration:()=>({get:(k,d)=>settings[k]??d,update:async(k,v)=>{settings[k]=v;}})},window:{},languages:{getDiagnostics:()=>[]}};
const original=Module._load;
Module._load=function(name,...args){if(name==='vscode')return mock;if(name==='./transport'&&/[\\/]src[\\/]/.test(args[0]?.filename||''))return {sshRequest:(...args)=>sshImpl(...args),completion:async(...p)=>{callCount++;return completionImpl(...p);}};return original.call(this,name,...args);};
const {Assistant}=require('../src/extension');Module._load=original;
async function setup(t){const dir=await fs.mkdtemp(path.join(os.tmpdir(),'agent-controller-'));t.after(()=>fs.rm(dir,{recursive:true,force:true}));mock.workspace.workspaceFolders=[{uri:mock.Uri.file(dir)}];mock.workspace.isTrusted=true;settings.contextTokens=32768;settings.mode='direct';settings.skillRouting='integrated';callCount=0;sshImpl=async()=>JSON.stringify({model:'fixture-model',mode:'direct'});const a=new Assistant({storageUri:{fsPath:path.join(dir,'storage')},secrets:{get:async()=> 'fixture-not-a-real-key'},subscriptions:[]});a.root=await fs.realpath(dir);return a;}
test('server token count precedes compaction and preserves a large current file result',async t=>{
 const a=await setup(t);const content='项目用途与检查要求。'.repeat(4000);let counts=0;
 sshImpl=async(o,r)=>{if(r.operation==='count_tokens'){counts++;return JSON.stringify({tokens:12000});}return JSON.stringify({model:'fixture-model',mode:'direct'});};
 a.executeTool=async()=>({content});
 a.compactInternal=async()=>{throw Error('Unnecessary compaction');};
 completionImpl=async(o,p)=>{
  if(callCount===1)return {role:'assistant',content:'',tool_calls:[{id:'read',type:'function',function:{name:'local_read_file',arguments:'{"path":"README.md"}'}}]};
  assert.equal(JSON.parse(p.messages.at(-1).content).content,content);
  return {role:'assistant',content:'Read successfully'};
 };
 await a.send('Read the current project');assert.equal(callCount,2);assert.equal(counts,2);
 assert.equal(a.metrics.inputTokens,12000);assert.equal(a.metrics.countSource,'服务端 tokenizer');assert.equal(a.metrics.compacted,false);
});
test('unavailable tokenizer falls back, caches failures per endpoint/model and honors cancellation',async t=>{
 const a=await setup(t);let probes=0;sshImpl=async()=>{probes++;return '{"tokens":null}';};
 const options={mode:'direct',host:'fixture',direct:{baseUrl:'http://127.0.0.1:1/v1'},resolvedModel:'one'};
 const one=await a.measureContext([{role:'user',content:'中文'}],[],options);
 await a.measureContext([{role:'user',content:'again'}],[],options);assert.equal(probes,1);assert.match(one.source,/保守/);
 await a.measureContext([],[],{...options,resolvedModel:'two'});assert.equal(probes,2);
 a.tokenizerUnavailable=undefined;a.controller=new AbortController();sshImpl=async()=>{a.controller.abort();throw Error('cancelled');};
 await assert.rejects(a.measureContext([],[],options),/cancelled/);
});
test('real token overflow blocks completion, duplicate surfaced errors render once',async t=>{
 const a=await setup(t);sshImpl=async(o,r)=>JSON.stringify(r.operation==='count_tokens'?{tokens:40000}:{model:'fixture-model',mode:'direct'});
 await assert.rejects(a.send('Read the project'),/预算/);assert.equal(callCount,0);
 const previous=a.messages.at(-1);a.add('error',previous.text);assert.equal(a.messages.at(-1),previous);assert.equal(a.messages.filter(m=>m.role==='error').length,1);
});
test('controller denies effect tools, apply, and command entry points in readonly and plan',async t=>{
  const a=await setup(t);
  for(const mode of ['readonly','plan']){a.permission=mode;await assert.rejects(a.executeTool('local_propose_edit',{}),/权限/);await assert.rejects(a.executeTool('local_propose_changes',{}),/权限/);await assert.rejects(a.executeTool('local_run_command',{}),/权限/);await assert.rejects(a.apply('forged'),/禁止/);await assert.rejects(a.runCommand('echo impossible',a.root),/禁止/);}
});
test('failed model continuation preserves proposals and results; restore never dispatches',async t=>{
  const a=await setup(t);await fs.writeFile(path.join(a.root,'fixture.txt'),'old');
  completionImpl=async(o,p,s,text,meta)=>{if(callCount>1)throw new Error('simulated disconnect');meta({model:'fixture-model',usage:{prompt_tokens:10,completion_tokens:5,total_tokens:15}});return {role:'assistant',content:'proposal',tool_calls:[{id:'call1',type:'function',function:{name:'local_propose_edit',arguments:JSON.stringify({path:'fixture.txt',old_text:'old',new_text:'new',summary:'test'})}}]};};
  await assert.rejects(a.send('edit fixture'),/disconnect/);assert.equal(callCount,2);assert.equal(a.pending.size,1);assert.equal(a.history.at(-1).role,'tool');assert.equal(a.journal[0].status,'completed');assert.equal(a.metrics.totalTokens,15);assert.equal(a.resolved.model,'fixture-model');
  const [saved]=await a.store.list();assert.equal(JSON.stringify(saved).includes('fixture-not-a-real-key'),false);
  const restored=new Assistant(a.context);let executed=0;restored.executeTool=()=>{executed++;};await restored.loadSession(saved);assert.equal(executed,0);assert.equal(restored.pending.size,1);assert.notEqual(restored.session,saved.session);
  await fs.writeFile(path.join(a.root,'fixture.txt'),'user edit');await assert.rejects(restored.apply([...restored.pending.keys()][0]),/变化/);
  await assert.rejects(restored.loadSession({...saved,root:path.dirname(a.root)}),/其他工作区/);
});
test('verification failure requests bounded repair, persists evidence, and never replays on load',async t=>{
  const a=await setup(t);await a.setVerification('fixture test');let repairs=0,runs=0;
  a.runCommand=async()=>{runs++;const saved=(await a.store.list()).find(s=>s.session===a.session);assert.equal(saved.task.checks.at(-1).status,'started');return {exitCode:1,output:'failure'};};
  a.send=async()=>{repairs++;};
  await a.verifyChanges();await a.verifyChanges();await a.verifyChanges();assert.equal(repairs,2);assert.equal(runs,3);assert.equal(a.task.repairAttempts,2);assert.equal(a.task.checks.at(-1).status,'failed');
  await a.checkpoint();const saved=(await a.store.list()).find(s=>s.session===a.session);await a.loadSession(saved);assert.equal(runs,3);assert.equal(a.task.verificationCommand,'fixture test');
  a.runCommand=async()=>({status:'denied'});await a.verifyChanges();assert.equal(repairs,2);assert.equal(a.task.status,'blocked');
  a.permission='plan';await assert.rejects(a.verifyChanges(),/禁止/);
});
test('unapproved plan blocks tools and model call pauses; approval enables continuation',async t=>{
  const a=await setup(t);a.permission='plan';
  completionImpl=async()=>({role:'assistant',content:'plan',tool_calls:[{id:'plan1',type:'function',function:{name:'local_update_plan',arguments:JSON.stringify({steps:[{title:'Read files'},{title:'Verify'}]})}}]});
  await a.send('plan task');assert.equal(callCount,1);assert.equal(a.task.status,'awaiting_plan');assert.equal(a.task.approved,false);
  await assert.rejects(a.executeTool('local_run_command',{command:'never'}),/权限/);
  let continuation=false;a.send=async()=>{continuation=true;};await a.approvePlan();assert.equal(a.task.approved,true);assert.equal(continuation,true);
});
test('Review plans continue into read-only subagents; edits and commands still require review',async t=>{
 const a=await setup(t);await fs.writeFile(path.join(a.root,'fixture.txt'),'old');
 t.after(()=>a.agents.dispose());let main=0,child=0,agentId;
 const call=(name,args)=>({role:'assistant',content:'',tool_calls:[{id:'call-'+callCount,type:'function',function:{name,arguments:JSON.stringify(args)}}]});
 completionImpl=async(o,p)=>{
  if(p.messages[0].content.startsWith('You are a read-only')){child++;return child===1?call('local_read_file',{path:'fixture.txt'}):{role:'assistant',content:'fixture.txt contains old'};}
  main++;
  if(main===1)return call('local_update_plan',{steps:[{title:'Review project independently'}]});
  if(main===2){assert.equal(a.state().planApprovalRequired,false);return call('local_delegate',{task:'Inspect fixture.txt',role:'review'});}
  if(main===3){agentId=JSON.parse(p.messages.at(-1).content).id;return call('local_agent_status',{id:agentId});}
  assert.equal(JSON.parse(p.messages.at(-1).content).status,'completed');return {role:'assistant',content:'Review finished'};
 };
 await a.send('Review the project');assert.equal(main,4);assert.equal(child,2);assert.equal(a.task.status,'responded');assert.equal(a.task.approved,false);assert.equal(a.runState.phase,'idle');
 const old=mock.window.showWarningMessage;let approvals=0;mock.window.showWarningMessage=async()=>{approvals++;return undefined;};t.after(()=>{mock.window.showWarningMessage=old;});
 const denied=await a.executeTool('local_run_command',{command:'echo forbidden'});assert.equal(denied.status,'denied');assert.equal(approvals,1);assert.equal(a.commandRunner.jobs.size,0);
 await a.executeTool('local_propose_edit',{path:'fixture.txt',old_text:'old',new_text:'new',summary:'Proposed only'});assert.equal(a.pending.size,1);assert.equal(await fs.readFile(path.join(a.root,'fixture.txt'),'utf8'),'old');
});

test('default allows more than twelve rounds; explicit limits save progress and Continue resets the count',async t=>{
 const a=await setup(t);delete settings.maxToolRounds;t.after(()=>{settings.maxToolRounds=6;});
 a.executeTool=async(name,args)=>({path:args.path,content:'Evidence'});
 completionImpl=async()=>callCount===14?{role:'assistant',content:'Finished evidence review'}:{role:'assistant',content:'',tool_calls:[{id:'r'+callCount,type:'function',function:{name:'local_read_file',arguments:JSON.stringify({path:'part'+callCount+'.md'})}}]};
 await a.send('Read the project');assert.equal(callCount,14);assert.equal(a.metrics.maxToolRounds,48);assert.equal(a.task.status,'responded');
 settings.maxToolRounds=2;await assert.rejects(a.send('Inspect more'),/required final report/);assert.equal(a.metrics.toolRound,2);assert.equal(a.task.status,'blocked');assert.match(a.runState.reason,/required final report/);assert.equal(a.history.at(-1).role,'tool');
 const saved=await a.store.read(a.session);assert.equal(saved.history.at(-1).role,'tool');
 completionImpl=async()=>({role:'assistant',content:'Summary from saved findings'});await a.resumeTask();assert.equal(a.metrics.toolRound,1);assert.equal(a.task.status,'responded');
});

test('auxiliary compaction disables Qwen thinking without changing the main setting',async t=>{
 const a=await setup(t);settings.thinkingProtocol='qwen';settings.thinkingLevel='on';t.after(()=>{settings.thinkingLevel='default';});
 a.history=[{role:'user',content:'Keep all source data unchanged.'},{role:'assistant',content:'Read only findings.'},{role:'user',content:'Continue'}];
 completionImpl=async(o,p)=>{assert.equal(p.chat_template_kwargs.enable_thinking,false);assert.equal(p.tool_choice,'none');assert.ok(p.messages[0].content.includes('600 characters'));return {content:JSON.stringify({overview:'Read-only task.',decisions:[],nextSteps:['Report findings'],constraintCandidates:[]})};};
 await a.compact();assert.equal(a.compaction.method,'semantic');assert.equal(settings.thinkingLevel,'on');assert.equal(a.history.length,3);
});
test('thinking is included in actual completion payload; compaction leaves canonical history intact',async t=>{
  const a=await setup(t);settings.thinkingProtocol='reasoning_effort';settings.thinkingLevel='high';
  completionImpl=async(o,p,s,delta,meta)=>{assert.equal(p.reasoning_effort,'high');assert.equal(p.max_tokens,1024);meta({thinking:true});return {role:'assistant',content:'answer'};};
  await a.send('a request');assert.equal(a.metrics.reasoningObserved,true);a.history.push({role:'user',content:'continue'});const before=JSON.stringify(a.history);await a.compact('extract');assert.equal(JSON.stringify(a.history),before);assert.ok(a.compaction.summary.goal);
  settings.thinkingProtocol='qwen';settings.thinkingLevel='default';
});
test('collects multi-file proposals over multiple rounds while withholding commands until review',async t=>{
  const a=await setup(t);await fs.writeFile(path.join(a.root,'a.txt'),'old');await fs.writeFile(path.join(a.root,'b.txt'),'old');let commands=0;a.runCommand=async()=>{commands++;};
  const proposal=(id,file)=>({id,type:'function',function:{name:'local_propose_edit',arguments:JSON.stringify({path:file,old_text:'old',new_text:'new',summary:'fixture'})}});
  completionImpl=async(o,p)=>{
    if(callCount===1)return {role:'assistant',content:'',tool_calls:[proposal('a','a.txt')]};
    assert.ok(!p.tools.some(t=>t.function.name==='local_run_command'));
    if(callCount===2)return {role:'assistant',content:'',tool_calls:[proposal('b','b.txt'),{id:'bad',type:'function',function:{name:'local_run_command',arguments:'{"command":"must not execute"}'}}]};
    return {role:'assistant',content:'Review both files'};
  };
  await a.send('two files');assert.equal(a.pending.size,2);assert.equal(commands,0);assert.equal(a.task.status,'awaiting_review');assert.equal(callCount,3);
});
test('dispatch journal is durable BEFORE command; subsequent model failure does not remove it',async t=>{
  const a=await setup(t);let executions=0;
  a.runCommand=async()=>{executions++;const [saved]=await a.store.list();assert.equal(saved.journal[0].status,'started');return {exitCode:0,output:'effect completed'};};
  completionImpl=async()=>{if(callCount>1)throw new Error('network');return {role:'assistant',content:'',tool_calls:[{id:'cmd',type:'function',function:{name:'local_run_command',arguments:'{"command":"fixture"}'}}]};};
  await assert.rejects(a.send('fixture'),/network/);assert.equal(executions,1);const [saved]=await a.store.list();assert.equal(saved.journal[0].result.output,'effect completed');
  await a.loadSession(saved);assert.equal(executions,1);assert.equal(a.history.at(-1).tool_call_id,'cmd');
});
test('budget failure prevents model request; persistence failure prevents tool dispatch',async t=>{
  const a=await setup(t);settings.contextTokens=8192;completionImpl=()=>{throw new Error('must not call');};await assert.rejects(a.send('x'.repeat(15000)),/预算/);assert.equal(callCount,0);
  a.store.save=async()=>{throw new Error('disk full');};await assert.rejects(a.send('small task'),/disk full/);assert.equal(callCount,0);assert.match(a.storageError,/保存失败/);
});
test('diagnostics are scoped to project; untrusted workspace cannot use local tools',async t=>{
  const a=await setup(t);mock.languages.getDiagnostics=()=>[[mock.Uri.file(path.join(a.root,'a.js')),[{range:{start:{line:2}},severity:0,message:'syntax'}]],[mock.Uri.file(path.join(path.dirname(a.root),'outside.js')),[{range:{start:{line:0}},message:'outside'}]]];
  const result=await a.executeTool('local_diagnostics',{});assert.equal(result.diagnostics.length,1);assert.equal(result.diagnostics[0].line,3);
  mock.workspace.isTrusted=false;await assert.rejects(a.executeTool('local_read_file',{path:'a.js'}),/信任/);
});

test('semantic compaction persists fixed constraints, invalidates plan approval, and retains prior summary on failure',async t=>{
  const a=await setup(t);a.task.steps=[{title:'repair',status:'pending'}];a.task.approved=true;
  await a.saveConstraints('Keep public API unchanged\n不要新增依赖');assert.equal(a.task.approved,false);
  a.history=[{role:'user',content:'Keep public API unchanged'},{role:'assistant',content:'Inspection complete; no edits applied.'},{role:'user',content:'Continue'}];
  const before=JSON.stringify(a.history);
  completionImpl=async(o,p)=>{assert.equal(p.tool_choice,'none');return {content:JSON.stringify({overview:'Inspection only',decisions:['Preserve API'],nextSteps:['Review'],constraintCandidates:[{quote:'Keep public API unchanged',sourceIndex:0}]})};};
  await a.compact();assert.equal(a.compaction.method,'semantic');assert.equal(a.compaction.through,2);assert.equal(JSON.stringify(a.history),before);
  const [saved]=await a.store.list();assert.deepEqual(saved.task.constraints,a.task.constraints);
  const old=JSON.stringify(a.compaction);a.history.push({role:'assistant',content:'Waiting'},{role:'user',content:'New context'});
  completionImpl=async()=>{throw new Error('offline');};await assert.rejects(a.compact(),/offline/);assert.equal(JSON.stringify(a.compaction),old);
  await a.loadSession(saved);assert.deepEqual(a.task.constraints,['Keep public API unchanged','不要新增依赖']);
  completionImpl=async(o,p)=>{assert.ok(p.messages[0].content.includes('不要新增依赖'));return {role:'assistant',content:'OK'};};
  await a.send('Continue carefully');
});

test('path completion respects project scope, ignore rules and sensitive paths',async t=>{
 const a=await setup(t);await fs.mkdir(path.join(a.root,'src'));await fs.writeFile(path.join(a.root,'src','app.js'),'fixture');await fs.writeFile(path.join(a.root,'.env'),'secret');await fs.writeFile(path.join(a.root,'.gitignore'),'ignored.txt');await fs.writeFile(path.join(a.root,'ignored.txt'),'hidden');
 const messages=[];a.view={webview:{postMessage:m=>messages.push(m)}};
 await a.suggestPaths('src/',1);assert.deepEqual(messages.at(-1).items,['src/app.js']);
 await a.suggestPaths('.env',2);assert.deepEqual(messages.at(-1).items,[]);
 await a.suggestPaths('ignored',3);assert.deepEqual(messages.at(-1).items,[]);
 await a.suggestPaths('../',4);assert.deepEqual(messages.at(-1).items,[]);
});

test('over-budget history compresses before coding and still sends exact constraints',async t=>{
 const a=await setup(t);await a.saveConstraints('Keep all public API names');
 a.history=[{role:'user',content:'Old discussion '.repeat(1800)},{role:'assistant',content:'No effects executed.'}];
 let summaries=0,coding=0;
 completionImpl=async(o,p)=>{
  if(p.tool_choice==='none'){summaries++;return {content:JSON.stringify({overview:'Discussed repair without effects',decisions:[],nextSteps:['Inspect files'],constraintCandidates:[]})};}
  coding++;assert.ok(p.messages[0].content.includes('Keep all public API names'));assert.ok(p.messages.some(x=>x.content.includes('Discussed repair without effects')));return {role:'assistant',content:'Ready'};
 };
 await a.send('Continue');assert.ok(summaries>0);assert.equal(coding,1);assert.equal(a.history[0].content,'Old discussion '.repeat(1800));assert.equal(a.compaction.method,'semantic');
});

test('model selector validates discovery, resets thinking, retains conversation and rejects busy/stale changes',async t=>{
 const a=await setup(t);settings.modelId='first';settings.thinkingLevel='on';settings.thinkingProtocol='qwen';
 sshImpl=async()=>JSON.stringify({models:['first','second','second',null]});
 a.history=[{role:'user',content:'Keep this task'}];await a.listModels();assert.deepEqual(a.modelCatalog.items,['first','second']);
 await assert.rejects(a.selectModel('invented'),/Refresh/);await a.selectModel('second');assert.equal(settings.modelId,'second');assert.equal(settings.thinkingLevel,'default');assert.equal(a.history[0].content,'Keep this task');
 a.busy=true;await assert.rejects(a.selectModel('first'));a.busy=false;
 settings.mode='qwen';await assert.rejects(a.selectModel('first'),/Refresh/);settings.mode='direct';
 settings.baseUrl='changed';await assert.rejects(a.selectModel('first'),/Refresh/);delete settings.baseUrl;
});

test('current file and selected code attach independently and missing selection is rejected',async t=>{
 const a=await setup(t);await fs.writeFile(path.join(a.root,'file.js'),'full file');mock.commands={executeCommand:async()=>{}};
 mock.window.activeTextEditor={document:{uri:mock.Uri.file(path.join(a.root,'file.js')),getText:selection=>selection?'selected code':'full file'},selection:{isEmpty:false,start:{line:1},end:{line:2}}};
 await a.attach('file');assert.equal(a.attachments[0].text,'full file');assert.equal(a.attachments[0].label,'file.js');
 await a.attach('selection');assert.equal(a.attachments[1].text,'selected code');assert.equal(a.attachments[1].label,'file.js:2-3');
 mock.window.activeTextEditor.selection.isEmpty=true;await assert.rejects(a.attach('selection'),/Select code/);delete mock.window.activeTextEditor;
});


test('automatic skill routing loads instructions and supporting resources, survives restore by revalidation, and honors manual-only policy',async t=>{
 const a=await setup(t),dir=path.join(a.root,'.agents/skills/demo');await fs.mkdir(path.join(dir,'references'),{recursive:true});
 await fs.writeFile(path.join(dir,'SKILL.md'),'---\nname: demo\ndescription: Review fixture API\n---\nAlways consult references/rules.md.');await fs.writeFile(path.join(dir,'references/rules.md'),'Preserve the public API.');a.permission='readonly';
 completionImpl=async(o,p)=>{
  const skill=a.skillLibrary.items.find(s=>s.name==='demo');if(p.tool_choice==='none')return {role:'assistant',content:JSON.stringify({skills:[]})};assert.ok(p.messages[0].content.includes('Review fixture API'));
  if(callCount===1)return {role:'assistant',content:'',tool_calls:[{id:'skill',type:'function',function:{name:'local_use_skill',arguments:JSON.stringify({id:skill.id,reason:'API review'})}}]};
  assert.ok(p.messages[0].content.includes('Always consult references/rules.md.'));
  if(callCount===2)return {role:'assistant',content:'',tool_calls:[{id:'ref',type:'function',function:{name:'local_read_skill_resource',arguments:JSON.stringify({id:skill.id,path:'references/rules.md'})}}]};
  return {role:'assistant',content:'Reviewed the API.'};
 };
 let resolutions=0;sshImpl=async(o,r)=>{if(r.operation==='count_tokens')return '{"tokens":null}';resolutions++;throw Error('Redundant direct resolution');};await a.send('Review fixture API');assert.equal(resolutions,0);assert.equal(a.metrics.skillRoutingCalls,undefined);assert.equal(callCount,3);assert.equal(a.state().activeSkills[0].name,'demo');assert.equal(a.journal[1].result.content,'Preserve the public API.');assert.equal(a.pending.size,0);
 const id=a.skillLibrary.items[0].id;a.selectedSkills=[id];await a.checkpoint();const [saved]=await a.store.list();await a.loadSession(saved);await fs.writeFile(path.join(dir,'SKILL.md'),'---\nname: demo\ndescription: Review fixture API\ndisable-model-invocation: true\n---\nManual updated');await a.prepareSkills('Continue');assert.ok(a.skillLibrary.active.has(id));
 a.selectedSkills=[];await a.prepareSkills('Continue');await assert.rejects(a.useSkill(id,'automatic'),/explicit/);await a.prepareSkills('$demo Review API');assert.ok(a.skillLibrary.active.has(id));
});


test('skill classifier rejects invented IDs and tool calls without executing them; checks its own budget',async t=>{
 const a=await setup(t),dir=path.join(a.root,'skills/router');await fs.mkdir(dir,{recursive:true});await fs.writeFile(path.join(dir,'SKILL.md'),'---\nname: router\ndescription: Fixture task\n---\nRead only');await a.prepareSkills('Fixture');settings.skillRouting='preflight';let executed=0;a.executeTool=async()=>{executed++;};
 completionImpl=async()=>({content:'{}',tool_calls:[{function:{name:'local_run_command',arguments:'{}'}}]});await a.routeSkills({}, {}, 'Fixture');assert.equal(executed,0);assert.equal(a.skillLibrary.active.size,0);assert.ok(a.skillLibrary.warnings.length);
 completionImpl=async()=>({content:JSON.stringify({skills:[{id:'forged'}]})});await a.routeSkills({}, {}, 'Fixture');assert.equal(a.skillLibrary.active.size,0);
 const calls=callCount;settings.contextTokens=8192;a.skillCatalog.text='x'.repeat(9000);await a.routeSkills({}, {}, 'Fixture');assert.equal(callCount,calls);settings.contextTokens=32768;
});


test('steering supersedes undispatched tool calls and preserves tool-result pairing',async t=>{
 const a=await setup(t);let executed=0;const execute=a.executeTool.bind(a);a.executeTool=(...args)=>{executed++;return execute(...args);};
 completionImpl=async()=>{if(callCount===1){await a.queueInput('Only explain; do not execute','steer');return {role:'assistant',content:'',tool_calls:[{id:'obsolete',type:'function',function:{name:'local_run_command',arguments:'{"command":"must not run"}'}}]};}assert.equal(a.history.at(-1).content,'Only explain; do not execute');return {role:'assistant',content:'Explanation'};};
 await a.send('Start');assert.equal(executed,0);assert.equal(a.history[2].role,'tool');assert.match(a.history[2].content,/not_executed/);assert.equal(a.inbox.length,0);
});
test('paused task retains queued input; restored task never automatically resumes it',async t=>{
 const a=await setup(t);a.busy=true;a.controller=new AbortController();await a.queueInput('Follow up','next');await a.pauseTask();assert.ok(a.controller.signal.aborted);a.busy=false;await a.drainInbox();assert.equal(a.inbox.length,1);
 const saved=await a.store.read(a.session);await a.loadSession(saved);assert.equal(a.runState.phase,'interrupted');assert.equal(a.inbox[0].text,'Follow up');assert.equal(callCount,0);
});
test('repeated identical tool calls pause without executing the fourth call',async t=>{
 const a=await setup(t);let runs=0;a.executeTool=async()=>{runs++;return {same:'no progress'};};
 completionImpl=async()=>({role:'assistant',content:'',tool_calls:[{id:'repeat'+callCount,type:'function',function:{name:'local_list_files',arguments:'{}'}}]});
 await assert.rejects(a.send('inspect'),/required final report/);assert.equal(runs,3);assert.equal(a.runState.phase,'blocked');assert.equal(a.history.at(-1).role,'tool');
});


test('background verification is pending, then completes from evidence without a duplicate repair',async t=>{
 const a=await setup(t);let repairs=0;a.send=async()=>repairs++;a.runCommand=async()=>({id:'job',status:'running',output:'starting'});await a.setVerification('fixture check');await a.verifyChanges();assert.equal(a.task.checks.at(-1).status,'running');assert.equal(repairs,0);
 a.commandRunner.result=()=>({id:'job',status:'completed',exitCode:0,output:'passed'});await a.commandChanged({id:'job',status:'completed',finishedAt:new Date().toISOString()});assert.equal(a.task.checks.at(-1).status,'passed');assert.equal(a.task.status,'verified');assert.equal(repairs,0);
});

test('M3 hooks require explicit per-project enablement and command approval; failures block before-tool and changed config revokes enablement',async t=>{
 const a=await setup(t),state=new Map();a.context.globalState={get:(k,d)=>state.get(k)??d,update:async(k,v)=>state.set(k,v)};
 const old=mock.window.showWarningMessage;let approvals=0;mock.window.showWarningMessage=async()=>{approvals++;return '运行一次';};
 t.after(async()=>{settings.hooks=[];mock.window.showWarningMessage=old;await a.commandRunner.dispose();});
 const command='node -e "process.stdout.write(\'hook ran\')"';settings.hooks=[{id:'check',event:'before-tool',command,timeoutSeconds:5}];
 await a.runHooks('before-tool');assert.equal(a.commandRunner.jobs.size,0);const row=require('../src/hooks').definitions(settings.hooks)[0];state.set('studio.hooks',{[require('../src/files').hash(a.root)]:[row.fingerprint]});
 for(const permission of ['plan','readonly']){a.permission=permission;await a.runHooks('before-tool');}assert.equal(a.commandRunner.jobs.size,0);a.permission='review';
 await a.executeTool('local_list_files',{});assert.equal(approvals,1);assert.equal(a.task.hookRuns.at(-1).status,'completed');assert.match(a.task.hookRuns.at(-1).output,/hook ran/);
 settings.hooks[0].command='node -e "process.exit(2)"';await a.runHooks('before-tool');assert.equal(approvals,1);const changed=require('../src/hooks').definitions(settings.hooks)[0];state.set('studio.hooks',{[require('../src/files').hash(a.root)]:[changed.fingerprint]});await assert.rejects(a.executeTool('local_list_files',{}),/hook did not pass/);assert.equal(a.task.hookRuns.at(-1).status,'failed');
 a.inHook=true;await a.runHooks('before-tool');a.inHook=false;assert.equal(approvals,2);
 a.task.hookRuns.push({hook:'check',event:'before-tool',status:'interrupted_unknown'});await assert.rejects(a.runHooks('before-tool'),/outcome unknown/);assert.equal(approvals,2);
 a.hookCount=8;await assert.rejects(a.runHooks('before-tool'),/limit reached/);assert.equal(approvals,2);
});
test('M3 MCP effects are denied in read modes and journaled before explicit dispatch',async t=>{
 const a=await setup(t),name='mcp_fixture_effect';a.mcp.routes.set(name,{name,write:true,original:'effect',config:{id:'fixture'}});let calls=0;
 const old=mock.window.showWarningMessage;mock.window.showWarningMessage=async()=> 'Run once';t.after(()=>{mock.window.showWarningMessage=old;settings.allowMcpWrites=true;});
 a.mcp.call=async(n,args,signal,{authorizeWrite})=>{if(!await authorizeWrite())throw Error('denied');const saved=await a.store.read(a.session);assert.ok(saved.journal.some(r=>r.name===name&&r.effect==='mcp'&&r.status==='started'));calls++;return {status:'interrupted_unknown'};};
 for(const mode of ['plan','readonly']){a.permission=mode;await assert.rejects(a.executeTool(name,{}),/权限/);}a.permission='review';settings.allowMcpWrites=false;await assert.rejects(a.executeTool(name,{}),/disabled/);settings.allowMcpWrites=true;
 const result=await a.executeTool(name,{target:'fixture'});assert.equal(result.status,'interrupted_unknown');assert.equal(calls,1);assert.ok(a.journal.some(r=>r.effect==='mcp'&&r.status==='interrupted_unknown'));
});
test('M3 slash skill commands choose duplicate sources and pass literal arguments without granting permissions',async t=>{
 const a=await setup(t),base=path.join(a.root,'skills'),state=new Map();a.context.globalState={get:(k,d)=>state.get(k)??d,update:async(k,v)=>state.set(k,v)};for(const folder of ['one','two']){await fs.mkdir(path.join(base,folder),{recursive:true});await fs.writeFile(path.join(base,folder,'SKILL.md'),'---\nname: duplicate\nallowed-tools: Read\n---\nInspect $ARGUMENTS');}
 const old=mock.window.showQuickPick;let choices=0;mock.window.showQuickPick=async rows=>{choices++;return rows[1];};t.after(()=>{mock.window.showQuickPick=old;});
 let sent;a.send=async text=>{sent=text;await a.prepareSkills(text);};await a.handleInput('/duplicate literal $(never-run)');assert.equal(choices,1);assert.equal(sent,'/duplicate literal $(never-run)');assert.equal(a.skillLibrary.active.size,1);assert.match(a.skillLibrary.guidance()[0].text,/literal \$\(never-run\)/);assert.equal(a.skillLibrary.toolAllowed('local_run_command'),false);
});

test('unknown MCP outcome stops the rest of the model tool batch and preserves paired results',async t=>{
 const a=await setup(t),name='mcp_fixture_write';a.mcp.routes.set(name,{name,write:true,original:'write',config:{id:'fixture'},definition:{type:'function',function:{name,description:'fixture',parameters:{type:'object'}}}});let writes=0,commands=0;a.callMcp=async()=>{writes++;return {status:'interrupted_unknown'};};a.runCommand=async()=>{commands++;return {exitCode:0};};
 completionImpl=async()=>({role:'assistant',content:'',tool_calls:[{id:'unknown',type:'function',function:{name,arguments:'{}'}},{id:'later',type:'function',function:{name:'local_run_command',arguments:JSON.stringify({command:'echo must-not-run'})}}]});
 await a.send('Fixture external update');assert.equal(writes,1);assert.equal(commands,0);assert.equal(a.task.status,'blocked');assert.equal(a.history.filter(m=>m.role==='tool').length,2);assert.equal(JSON.parse(a.history.at(-1).content).status,'not_executed');
});

test('M4 delegation stays read-only in Plan, survives restore and cannot execute model-invented writes',async t=>{
 const a=await setup(t);settings.sshHost='fixture-host';settings.baseUrl='http://127.0.0.1:11436/v1';await fs.writeFile(path.join(a.root,'fixture.txt'),'original');a.permission='plan';let calls=0;
 t.after(()=>{delete settings.sshHost;delete settings.baseUrl;});
 completionImpl=async()=>++calls===1?{role:'assistant',content:'',tool_calls:[{id:'read',type:'function',function:{name:'local_read_file',arguments:'{"path":"fixture.txt"}'}},{id:'write',type:'function',function:{name:'local_propose_edit',arguments:'{}'}}]}:{role:'assistant',content:'fixture.txt:1 contains original; no changes made.'};
 const result=await a.executeTool('local_delegate',{task:'Inspect fixture',role:'review'});assert.ok(a.activeAgents());await a.agents.live.get(result.id)?.done;const job=await a.agentStatus(result.id);assert.equal(job.status,'completed');assert.equal(await fs.readFile(path.join(a.root,'fixture.txt'),'utf8'),'original');assert.equal(a.pending.size,0);assert.equal(a.commandRunner.jobs.size,0);await a.useAgentResult(result.id);assert.ok(a.history.at(-1).content.includes('Read-only subagent report'));await a.useAgentResult(result.id);assert.equal(a.task.agentResults.length,1);
 await a.checkpoint();const saved=await a.store.read(a.session);await a.loadSession(saved);assert.equal((await a.agentStatus(result.id)).status,'completed');assert.equal(a.agents.live.size,0);assert.equal(JSON.stringify(saved).includes('fixture-not-a-real-key'),false);
});
test('M4 history page scopes projects, renames, archives and branches without inheriting task effects',async t=>{
 const a=await setup(t);a.add('user','Find history needle');a.history=[{role:'user',content:'Find history needle'}];a.task.constraints=['Preserve API'];await a.checkpoint();const originalId=a.session;
 await a.showHistory('needle','project');assert.equal(a.historyPage.total,1);const old=mock.window.showInputBox;mock.window.showInputBox=async()=> 'Renamed chat';t.after(()=>{mock.window.showInputBox=old;});
 await a.historyAction('rename',originalId);assert.equal(a.historyPage.items[0].title,'Renamed chat');await a.historyAction('archive',originalId);assert.equal(a.historyPage.total,0);await a.showHistory('','project',true);assert.equal(a.historyPage.total,1);await a.historyAction('archive',originalId);
 a.pending.set('pending',{id:'pending'});await a.historyAction('fork',originalId);assert.notEqual(a.conversationId,originalId);assert.equal(a.pending.size,0);assert.equal(a.task.approved,false);assert.deepEqual(a.task.constraints,['Preserve API']);assert.equal((await a.store.metadata(a.conversationId)).parent,originalId);await a.showHistory('','all');assert.equal(a.historyPage.total,2);
});
test('M4 setup probes draft credentials before saving and cancellation leaves existing configuration intact',async t=>{
 const a=await setup(t),saved={...settings},values=new Map([['macstudio.apiKey','old-key']]);a.context.secrets={get:async k=>values.get(k),store:async(k,v)=>values.set(k,v),delete:async k=>values.delete(k)};const oldInput=mock.window.showInputBox,oldPick=mock.window.showQuickPick;
 t.after(()=>{for(const k of Object.keys(settings))delete settings[k];Object.assign(settings,saved);mock.window.showInputBox=oldInput;mock.window.showQuickPick=oldPick;});
 mock.window.showInputBox=async()=>undefined;await a.setupConnection();assert.deepEqual(settings,saved);
 let inputs=['alias','','python3','http://127.0.0.1:11436/v1','new-key'];mock.window.showInputBox=async()=>inputs.shift();mock.window.showQuickPick=async rows=>rows[0];sshImpl=async(options,request)=>{assert.equal(options.direct.apiKey,'new-key');assert.equal(values.get('macstudio.apiKey'),'old-key');assert.equal(request.operation,'probe');return JSON.stringify({models:['available-model']});};
 await a.setupConnection();assert.equal(settings.modelId,'available-model');assert.equal(settings.sshHost,'alias');assert.equal(values.get('macstudio.apiKey'),'new-key');assert.equal(a.connectionStatus,'configured');assert.ok(!JSON.stringify(a.state()).includes('new-key'));
 const configured={...settings};let saveFailed=false;inputs=['another-alias','','python3','http://127.0.0.1:11436/v1','bad-key'];sshImpl=async()=>JSON.stringify({models:['another-model']});a.context.secrets.store=async(k,v)=>{if(!saveFailed){saveFailed=true;throw Error('secret save failed');}values.set(k,v);};await assert.rejects(a.setupConnection(),/secret save failed/);assert.deepEqual(settings,configured);assert.equal(values.get('macstudio.apiKey'),'new-key');

});
test('M4 diagnostics distinguish SSH, API, model and optional capabilities; smoke request has no tools',async t=>{
 const a=await setup(t);settings.sshHost='alias';settings.baseUrl='http://127.0.0.1:11436/v1';t.after(()=>{delete settings.sshHost;delete settings.baseUrl;});
 sshImpl=async(options,request)=>{if(request.operation==='health'){assert.equal(options.direct,undefined);return '{"ok":true}';}if(request.operation==='probe')return '{"models":["fixture-model"]}';if(request.operation==='resolve')return '{"model":"fixture-model","mode":"direct"}';return '{}';};completionImpl=async(options,payload)=>{assert.equal(payload.tool_choice,'none');assert.equal(payload.max_tokens,64);return {role:'assistant',content:'OK'};};
 await a.diagnoseConnection(true);assert.equal(a.connectionStatus,'connected');assert.equal(a.connectionChecks.find(x=>x.name==='Model capabilities').status,'unreported');assert.equal(a.connectionChecks.at(-1).status,'passed');
 const originalSsh=sshImpl;sshImpl=async(o,r)=>{const value=await originalSsh(o,r);if(r.operation==='capabilities')settings.sshHost='changed-alias';return value;};await assert.rejects(a.diagnoseConnection());assert.equal(a.connectionStatus,'failed');settings.sshHost='alias';

 sshImpl=async()=>{throw Error('Host key verification failed private fixture');};await assert.rejects(a.diagnoseConnection(),/fingerprint/);assert.equal(a.connectionChecks[0].code,'host_key');assert.ok(!JSON.stringify(a.state()).includes('private fixture'));
});


test('Auto is default, preserves effect review and Full access requires an ephemeral task grant',async t=>{
 const a=await setup(t);assert.equal(a.permission,'auto');await fs.writeFile(path.join(a.root,'a.txt'),'original');
 const proposal=await a.executeTool('local_propose_edit',{path:'a.txt',old_text:'original',new_text:'updated',summary:'fixture'});
 assert.equal(proposal.status,'proposed_only');assert.equal(await fs.readFile(path.join(a.root,'a.txt'),'utf8'),'original');
 const old=mock.window.showWarningMessage;let approvals=0;mock.window.showWarningMessage=async()=>{approvals++;return undefined;};t.after(()=>{mock.window.showWarningMessage=old;});
 await assert.rejects(a.runCommand('echo fixture',a.root),/修改尚未应用/);a.pending.clear();assert.equal((await a.runCommand('echo fixture',a.root)).status,'denied');assert.equal(approvals,1);assert.equal(a.commandRunner.jobs.size,0);
 await a.setPermission('full');assert.equal(a.permission,'auto');assert.equal(a.hasFullAccess(),false);
 mock.window.showWarningMessage=async()=> 'Enable Full access';await a.setPermission('full');assert.equal(a.hasFullAccess(),true);
 a.pending.clear();let applied=0;a.applyChange=async id=>{applied++;a.pending.delete(id);a.edits.push({id,status:'applied'});};
 assert.equal((await a.executeTool('local_propose_edit',{path:'a.txt',old_text:'original',new_text:'updated',summary:'fixture'})).status,'applied');assert.equal(applied,1);
 settings.allowCommands=false;await assert.rejects(a.runCommand('echo fixture',a.root),/disabled/);delete settings.allowCommands;
 const fullTask=a.task.id;a.task.id='different-task';assert.equal(a.hasFullAccess(),false);assert.throws(()=>a.guardEffect('files'),/expired/);a.task.id=fullTask;
 await a.checkpoint();const saved=await a.store.read(a.session);await a.loadSession(saved);assert.equal(a.permission,'auto');assert.equal(a.hasFullAccess(),false);
 await a.setPermission('readonly');assert.throws(()=>a.guardEffect('commands'),/禁止/);
});

test('resume and compaction keep latest user intent and steering, not the first project overview',async t=>{
 const a=await setup(t);a.history=[{role:'user',content:'Read the project'},{role:'assistant',content:'Overview'},{role:'user',content:'Delegate two independent reviews of parser.js'}];a.task.goal='Read the project';
 completionImpl=async(o,p)=>{assert.ok(p.messages[0].content.includes('Delegate two independent reviews of parser.js'));return {role:'assistant',content:'Review findings'};};
 await a.resumeTask();assert.equal(a.task.currentRequest,'Delegate two independent reviews of parser.js');
 a.inbox.push({id:'steer',kind:'steer',text:'Also check the parser boundary cases'});await a.consumeSteering();assert.equal(a.task.currentRequest,'Also check the parser boundary cases');
 await a.compact('extract');assert.equal(a.compaction.summary.currentRequest,'Also check the parser boundary cases');
 a.runState={phase:'blocked',reason:'Specific failure'};await a.checkpoint();const saved=await a.store.read(a.session);await a.loadSession(saved);assert.equal(a.runState.reason,'Specific failure');
});

test('output-limit recovery retries only once, lowers thinking and does not dispatch partial tools',async t=>{
 const a=await setup(t);settings.thinkingProtocol='qwen';settings.thinkingLevel='on';let dispatched=0;a.executeTool=async()=>{dispatched++;};
 t.after(()=>{settings.thinkingLevel='default';});
 completionImpl=async(o,p)=>{if(callCount===1)throw Object.assign(Error('truncated'),{code:'OUTPUT_LIMIT'});assert.equal(p.chat_template_kwargs.enable_thinking,false);return {role:'assistant',content:'Concise report'};};
 await a.send('Inspect the project');assert.equal(callCount,2);assert.equal(dispatched,0);assert.equal(a.task.status,'responded');
 callCount=0;completionImpl=async()=>{throw Object.assign(Error('truncated again'),{code:'OUTPUT_LIMIT'});};await assert.rejects(a.send('Inspect another file'),/truncated again/);assert.equal(callCount,2);assert.equal(a.runState.phase,'blocked');
});

test('early compaction triggers before hard capacity and retains constraints and transcript',async t=>{
 const a=await setup(t);a.task.constraints=['Keep exact requirement'];a.history=[{role:'user',content:'previous task'},{role:'assistant',content:'prior evidence'}];
 let compacted=0;a.compactInternal=async({through})=>{compacted++;a.compaction={through,summary:{overview:'preserved'}};};
 sshImpl=async(o,r)=>JSON.stringify(r.operation==='count_tokens'?{tokens:compacted?7000:25000}:{model:'fixture-model'});
 completionImpl=async()=>({role:'assistant',content:'Findings delivered'});
 await a.send('Continue the audit');assert.equal(compacted,1);assert.equal(a.history[0].content,'previous task');assert.deepEqual(a.task.constraints,['Keep exact requirement']);
});
test('idle compaction skips active work, cancels for input, and does not retry a frontier',async t=>{
 const a=await setup(t);t.after(()=>a.dispose());a.resolved={model:'fixture-model'};a.history=[{role:'user',content:'a'},{role:'assistant',content:'b'},{role:'user',content:'c'}];a.metrics={budget:20000,inputTokens:14000};a.lastActivity=0;
 let calls=0,aborted=false;a.compactInternal=async({signal})=>{calls++;await new Promise(resolve=>signal.addEventListener('abort',()=>{aborted=true;resolve();},{once:true}));};
 a.busy=true;await a.tryIdleCompact(600000);assert.equal(calls,0);a.busy=false;
 a.activeAgents=()=>true;await a.tryIdleCompact(600000);assert.equal(calls,0);a.activeAgents=()=>false;
 const pending=a.tryIdleCompact(600000);await new Promise(r=>setImmediate(r));assert.equal(calls,1);await a.cancelIdleCompact();await pending;assert.equal(aborted,true);assert.equal(a.busy,false);assert.equal(a.history.length,3);
 a.lastActivity=0;await a.tryIdleCompact(600000);assert.equal(calls,1);
});
test('repeated overlapping reads produce a report without exhausting tool rounds',async t=>{
 const a=await setup(t);t.after(()=>a.dispose());let final=false;
 a.executeTool=async(name,args)=>({startLine:args.startLine,endLine:10,content:'range'+args.startLine});
 completionImpl=async(o,p)=>{if(p.tool_choice==='none'){final=true;return {role:'assistant',content:'Evidence found; audit remains incomplete with coverage 1/10.'};}return {role:'assistant',content:'',tool_calls:[{id:'t'+callCount,type:'function',function:{name:'local_read_file',arguments:JSON.stringify({path:'fixture.txt',startLine:callCount})}}]};};
 const answer=await a.send('Audit the records');assert.equal(final,true);assert.match(answer,/coverage 1\/10/);assert.ok(callCount<=5);
});

test('JSON project tool follows path policy and reads unsaved structured records',async t=>{
 const a=await setup(t);t.after(()=>a.dispose());await fs.writeFile(path.join(a.root,'packet.json'),JSON.stringify({packet:[{id:1,text:'original'}]}));
 a.permission='readonly';assert.equal((await a.executeTool('local_read_json',{path:'packet.json',pointer:'/packet'})).items[0].text,'original');
 mock.workspace.textDocuments=[{uri:mock.Uri.file(path.join(a.root,'packet.json')),getText:()=>'{"packet":[{"id":1,"text":"unsaved"}]}',isDirty:true}];t.after(()=>{mock.workspace.textDocuments=[];});
 const result=await a.executeTool('local_read_json',{path:'packet.json',pointer:'/packet'});assert.equal(result.items[0].text,'unsaved');assert.equal(result.unsaved,true);
 await assert.rejects(a.executeTool('local_read_json',{path:'../outside.json'}));await assert.rejects(a.executeTool('local_read_json',{path:'.env'}));
});

test('main controller recovers a tool-template-only response without executing it',async t=>{
 const a=await setup(t);t.after(()=>a.dispose());let dispatched=0;a.executeTool=async()=>{dispatched++;};
 completionImpl=async(o,p)=>callCount===1?{role:'assistant',content:'<tool_call>\n<function=local_read_json></function>\n</tool_call>'}:{role:'assistant',content:'A substantive report with the remaining work explicitly identified.'};
 const result=await a.send('Report findings');assert.match(result,/substantive report/);assert.equal(callCount,2);assert.equal(dispatched,0);
});
