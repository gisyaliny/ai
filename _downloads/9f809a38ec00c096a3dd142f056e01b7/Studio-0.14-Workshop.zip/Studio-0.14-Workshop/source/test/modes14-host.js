'use strict';
const vscode=require('vscode'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),path=require('node:path');
exports.run=async()=>{
 await require('./workflow-host').run();
 const a=await vscode.extensions.getExtension('yyang-local.macstudio-assistant').activate();
 await a.newChat();assert.equal(a.permission,'auto');const root=await a.project();
 await fs.writeFile(path.join(root,'full-fixture.txt'),'before');
 // UI consent is separately tested in controller.test. Simulate its ephemeral
 // grant here to exercise REAL WorkspaceEdit/checkpoints/terminal dispatch.
 a.permission='full';a.fullGrant={root,taskId:a.task.id};
 const before=a.history.length;
 const result=await a.executeTool('local_propose_edit',{path:'full-fixture.txt',old_text:'before',new_text:'after',summary:'Synthetic full-access fixture'});
 assert.equal(result.status,'applied');assert.equal(a.pending.size,0);assert.equal(a.history.length,before);
 assert.equal(await fs.readFile(path.join(root,'full-fixture.txt'),'utf8'),'after');assert.equal(a.edits.at(-1).status,'applied');
 const group=await a.executeTool('local_propose_changes',{summary:'Group fixture',operations:[{kind:'create',path:'full-created.txt',content:'created'},{kind:'edit',path:'full-fixture.txt',edits:[{old_text:'after',new_text:'grouped'}]}]});
 assert.equal(group.status,'applied');assert.equal(await fs.readFile(path.join(root,'full-fixture.txt'),'utf8'),'grouped');assert.equal(a.history.length,before);
 // workflow-host overrides runCommand; restore the actual implementation.
 delete a.runCommand;
 const command=await a.runCommand('echo studio-full-fixture',root,undefined,{waitForExit:true});assert.equal(command.exitCode,0);assert.match(command.output,/studio-full-fixture/);
 a.fullGrant=undefined;await assert.rejects(a.runCommand('echo should-not-run',root),/expired/);
 await a.checkpoint();const saved=await a.store.read(a.session);await a.loadSession(saved);assert.equal(a.permission,'auto');assert.equal(a.hasFullAccess(),false);
 const pending=await a.executeTool('local_propose_edit',{path:'full-fixture.txt',old_text:'grouped',new_text:'needs review',summary:'Auto retains review'});assert.equal(pending.status,'proposed_only');assert.equal(await fs.readFile(path.join(root,'full-fixture.txt'),'utf8'),'grouped');
 await fs.writeFile(path.join(__dirname,'../test-results/modes14-host.json'),JSON.stringify({version:require('../package.json').version,realSingleAndGroupWrites:true,checkpointSaved:true,fullCommandCompleted:true,revokedGrantBlocked:true,reloadDowngradesToAuto:true,autoRetainsReview:true,protocolHistoryValid:true},null,2));
};
