'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const {SkillLibrary,locations,scan}=require('../src/skill-library');
const discovery=require('../src/config-discovery');
const {ReadonlyMcp}=require('../src/mcp');
async function fixture(t){const dir=await fs.mkdtemp(path.join(os.tmpdir(),'studio-library-'));t.after(()=>fs.rm(dir,{recursive:true,force:true}));return dir;}
async function write(file,text){await fs.mkdir(path.dirname(file),{recursive:true});await fs.writeFile(file,text);}
test('discovers personal, nested plugin and project skills; lazy loading, manual policy, source isolation and turn snapshots',async t=>{
 const home=await fixture(t),root=path.join(home,'project');await fs.mkdir(root);
 const base=path.join(home,'.codex/skills'),plugin=path.join(home,'.codex/plugins/cache/p/tool/1/skills/nested');
 await write(path.join(base,'design/SKILL.md'),'---\nname: design\ndescription: |\n  Design interfaces\n  with deliberate typography.\n---\nUse references/rules.md.');
 await write(path.join(base,'design/references/rules.md'),'Original reference');
 await write(path.join(base,'design/.env'),'never read');
 await write(path.join(base,'manual/SKILL.md'),'---\nname: manual\ndescription: Only explicit\ndisable-model-invocation: true\n---\nManual');
 await write(path.join(plugin,'SKILL.md'),'---\nname: design\ndescription: Nested plugin\n---\nOther version');
 const sources=locations(root,{home}),library=new SkillLibrary();await library.refresh(sources.filter(s=>!s.external));assert.equal(library.items.length,0);
 await library.refresh(sources);assert.equal(library.items.length,3);assert.equal(library.items.filter(s=>s.name==='design').length,2);assert.equal(library.catalog().text.includes('Manual'),false);assert.equal(library.cache.size,0);
 const design=library.items.find(s=>s.source==='Codex · personal'&&s.name==='design'),manual=library.items.find(s=>s.name==='manual');
 await assert.rejects(library.resource(design.id,'references/rules.md'),/Activate/);
 await library.use(design.id,{reason:'UI task'});assert.equal(library.active.get(design.id).reason,'UI task');
 assert.equal((await library.resource(design.id,'references/rules.md')).content,'Original reference');
 await write(path.join(base,'design/references/rules.md'),'Updated');assert.equal((await library.resource(design.id,'references/rules.md')).content,'Original reference');
 for(const p of ['../manual/SKILL.md','.env','C:/secret','references/../../secret'])await assert.rejects(library.resource(design.id,p));
 await assert.rejects(library.use(manual.id),/explicit/);await library.use(manual.id,{manual:true});
 await library.refresh(sources);await library.use(design.id);assert.equal((await library.resource(design.id,'references/rules.md')).content,'Updated');
 await library.refresh(sources);await write(path.join(base,'design/SKILL.md'),'changed');await assert.rejects(library.use(design.id),/changed/);
});
test('MCP import is read-only, scope-aware, secret-free in summaries; expands environment only at connection and detects changes',async t=>{
 const home=await fixture(t),root=path.join(home,'project');await fs.mkdir(root);
 const codex=path.join(home,'.codex/config.toml');
 await write(codex,'[mcp_servers.local]\ncommand="node"\nargs=["server.js"]\nenv_vars=["NEEDED"]\n[mcp_servers.local.env]\nKEY="fixture-secret"\n[mcp_servers.off]\nurl="https://example.com"\nenabled=false\n');
 await write(path.join(home,'.claude.json'),JSON.stringify({oauthAccount:{token:'never-export'},mcpServers:{web:{type:'http',url:'https://example.com/mcp',headers:{Authorization:'Bearer ${TOKEN}'}}},projects:{[root]:{mcpServers:{local:{command:'node',args:[]}}},[path.join(home,'other')]:{mcpServers:{foreign:{command:'bad'}}}}}));
 await write(path.join(root,'.mcp.json'),JSON.stringify({mcpServers:{disabled:{type:'http',url:'https://example.com'}}}));
 await write(path.join(root,'.claude/settings.local.json'),JSON.stringify({disabledMcpjsonServers:['disabled']}));
 const before=await fs.readFile(codex,'utf8'),{entries}=await discovery.discover(root,{home});assert.equal(entries.length,5);assert.ok(!entries.some(e=>e.name==='foreign'));assert.ok(!entries.find(e=>e.name==='disabled').enabled);
 const safe=JSON.stringify(entries.map(discovery.safeEntry));assert.ok(!safe.includes('fixture-secret'));assert.ok(!safe.includes('never-export'));
 const local=entries.find(e=>e.source==='Codex'&&e.name==='local');assert.throws(()=>discovery.resolve(local,[],{}),/environment/);
 const resolved=discovery.resolve(local,[],{NEEDED:'test'});assert.equal(resolved.env.KEY,'fixture-secret');assert.equal(resolved.env.NEEDED,'test');
 const web=entries.find(e=>e.name==='web');assert.equal(discovery.resolve(web,[],{TOKEN:'test-token'}).headers.Authorization,'Bearer test-token');
 assert.throws(()=>discovery.resolve(entries.find(e=>e.name==='off')),/disabled/);
 assert.equal(await fs.readFile(codex,'utf8'),before);await fs.appendFile(codex,'\n[mcp_servers.local2]\ncommand="node"\n');
 await write(codex,before.replace('server.js','changed.js'));const updated=(await discovery.discover(root,{home})).entries.find(e=>e.key===local.key);assert.notEqual(updated.fingerprint,local.fingerprint);
});
test('real stdio MCP requires launch approval, gates tools, rejects source changes and closes the child',async t=>{
 const dir=await fixture(t),serverFile=path.join(dir,'server.cjs');const sdk=path.dirname(require.resolve('@modelcontextprotocol/sdk/server/index.js'));
 await write(serverFile,`const {Server}=require(${JSON.stringify(path.join(sdk,'index.js'))});const {StdioServerTransport}=require(${JSON.stringify(path.join(sdk,'stdio.js'))});const {ListToolsRequestSchema,CallToolRequestSchema}=require(${JSON.stringify(require.resolve('@modelcontextprotocol/sdk/types.js'))});const server=new Server({name:'fixture',version:'1'},{capabilities:{tools:{}}});server.setRequestHandler(ListToolsRequestSchema,()=>({tools:[{name:'read',inputSchema:{type:'object'},annotations:{readOnlyHint:true}},{name:'write',inputSchema:{type:'object'},annotations:{readOnlyHint:false}}]}));server.setRequestHandler(CallToolRequestSchema,()=>({content:[{type:'text',text:process.env.FIXTURE}]}));server.connect(new StdioServerTransport());`);
 let current=true;const client=new ReadonlyMcp();t.after(()=>client.close());const config={id:'stdio_fixture',transport:'stdio',command:process.execPath,args:[serverFile],cwd:dir,env:{FIXTURE:'stdio worked'},allowedTools:[],validateCurrent:async()=>{if(!current)throw Error('Source changed');}};
 await client.connect([config],{});assert.equal(client.catalog.size,0);
 await client.connect([config],{},{approveStdio:async()=>true});assert.equal(client.catalog.size,1,JSON.stringify(client.status));assert.equal(client.definitions().length,0);
 client.selectTools(config.id,['read','write']);assert.equal(client.definitions().length,1);const name=client.definitions()[0].function.name;assert.equal((await client.call(name,{})).content[0].text,'stdio worked');
 current=false;await assert.rejects(client.call(name,{}),/Source changed/);await client.close();assert.equal(client.definitions().length,0);assert.equal(client.catalog.size,0);
});


test('skill search ranks partial multiword matches and excludes manual-only skills',()=>{
 const {SkillLibrary}=require('../src/skill-library');const library=new SkillLibrary();
 library.items=[{id:'design',name:'frontend-design',description:'Design web interfaces',auto:true},{id:'other',name:'slides',description:'Design slide decks',auto:true},{id:'manual',name:'frontend',description:'UI design composer interface',auto:false}];
 assert.equal(library.search('frontend UI design composer interface')[0].id,'design');
 assert.ok(!library.search('frontend').some(s=>s.id==='manual'));
 assert.equal(library.search('unrelatedXYZ').length,0);
});
