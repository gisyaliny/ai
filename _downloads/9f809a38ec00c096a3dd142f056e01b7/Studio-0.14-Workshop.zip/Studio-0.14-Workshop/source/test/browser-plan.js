async page=>{
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 for(const port of [18776,18777]){
  await page.goto('http://127.0.0.1:'+port);
  await page.evaluate(()=>{fixtureState.permission='plan';fixtureState.planApprovalRequired=true;fixtureState.busy=false;fixtureState.pending=[];fixtureState.run={phase:'waiting'};fixtureState.task.approved=false;fixtureState.task.status='awaiting_plan';fixtureState.task.steps=[{title:'Review source evidence independently',status:'pending'},{title:'Compare the audit findings',status:'pending'}];window.postMessage({type:'state',state:fixtureState},'*');});
  await page.locator('#planApprovalNotice').waitFor({state:'visible'});
  if(await page.evaluate(()=>sent.some(x=>x.type==='approvePlan')))throw Error('Plan was auto-approved');
  for(const width of [280,380,900]){
   await page.setViewportSize({width,height:940});
   await page.waitForFunction(()=>document.querySelector('#approveWaitingPlan').getBoundingClientRect().right<=innerWidth);
   if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth))throw Error('Overflow');
   if(!await page.locator('#approveWaitingPlan').isVisible())throw Error('Missing inline approval');
  }
  await page.setViewportSize({width:380,height:940});await page.screenshot({path:'test-results/plan-0133-'+port+'.png'});
  await page.locator('#reviewWaitingPlan').click();if(!await page.locator('#planSection').isVisible())throw Error('Plan not reachable');
  await page.locator('#taskToggle').click();await page.locator('#approveWaitingPlan').click();
  if(!await page.evaluate(()=>sent.filter(x=>x.type==='approvePlan').length===1))throw Error('Approval event missing or duplicated');
  await page.evaluate(()=>{fixtureState.permission='review';fixtureState.planApprovalRequired=false;fixtureState.task.approved=false;fixtureState.metrics.toolRound=13;fixtureState.metrics.maxToolRounds=48;fixtureState.run={phase:'running'};window.postMessage({type:'state',state:fixtureState},'*');});
  await page.locator('#planApprovalNotice').waitFor({state:'hidden'});
  if(!await page.locator('#runtimeStatus').textContent().then(x=>x.includes('13 / 48')))throw Error('Round counter missing');
  await page.locator('#tab-work').click();if(await page.locator('#approvePlan').isVisible())throw Error('Review mode still asks for plan approval');
  await page.locator('#taskToggle').click();await page.screenshot({path:'test-results/review-0133-'+port+'.png'});
 }
 if(errors.length)throw Error(errors.join('\n'));return {locales:2,widths:[280,380,900],explicitApprovalOnly:true,errors};
}
