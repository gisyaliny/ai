const vscode=require('vscode');const assert=require('node:assert/strict');const fs=require('node:fs/promises');const path=require('node:path');
exports.run=async()=>{
 const ext=vscode.extensions.getExtension('yyang-local.macstudio-assistant'),a=await ext.activate();await a.ready;await a.newChat();const root=await a.project(),config=vscode.workspace.getConfiguration('macstudio');
 const base=path.join(root,'skills/fixture');await fs.mkdir(base,{recursive:true});await fs.writeFile(path.join(base,'SKILL.md'),'---\nname: inspect\nargument-hint: "[file]"\nallowed-tools: Read, Glob\n---\nInspect $ARGUMENTS');
 await a.refreshSkillLibrary(true);const item=a.skillLibrary.items.find(s=>s.name==='inspect');assert.ok(item);await a.skillLibrary.use(item.id,{manual:true,arguments:'fixture.txt'});assert.match(a.skillLibrary.guidance()[0].text,/Inspect fixture.txt/);await assert.rejects(a.executeTool('local_run_command',{command:'echo forbidden'}),/restrictions/);assert.ok((await a.executeTool('local_list_files',{})).files);
 a.skillLibrary.active.clear();const command=process.platform==='win32'?"Write-Output 'hook fixture'":"printf 'hook fixture\\n'";
 await config.update('hooks',['after-apply','after-verification','task-end'].map((event,i)=>({id:'fixture'+i,event,command,timeoutSeconds:5})),vscode.ConfigurationTarget.Global);
 const enabled=require('../src/hooks').definitions(vscode.workspace.getConfiguration('macstudio').get('hooks'));await a.context.globalState.update('studio.hooks',{[require('../src/files').hash(root)]:enabled.map(x=>x.fingerprint)});
 const old=vscode.window.showWarningMessage;vscode.window.showWarningMessage=async()=> 'Allow exact command for this task';
 try{
  const proposal=await a.executeTool('local_propose_changes',{summary:'hook fixture',operations:[{kind:'create',path:'hooked.txt',content:'fixture'}]});await a.apply(proposal.id);assert.equal(a.task.hookRuns.at(-1).event,'after-apply');assert.equal(a.task.hookRuns.at(-1).status,'completed');
  await a.setVerification(command);await a.verifyChanges();assert.equal(a.task.hookRuns.at(-1).event,'after-verification');assert.equal(a.task.checks.at(-1).status,'passed');
  await a.runHooks('task-end',{status:'verified'});assert.equal(a.task.hookRuns.at(-1).event,'task-end');
  a.task.hookRuns.push({id:'interrupted-fixture',event:'task-end',status:'started'});await a.checkpoint();const saved=await a.store.read(a.session),count=a.commandRunner.jobs.size;await a.loadSession(saved);assert.equal(a.task.hookRuns.at(-1).status,'interrupted_unknown');assert.equal(a.commandRunner.jobs.size,count);assert.equal(a.commandGrants.list(a.task.id).length,0);
  await vscode.commands.executeCommand('macstudio.open');for(let i=0;i<50&&!a.webviewReady;i++)await new Promise(r=>setTimeout(r,100));assert.ok(a.webviewReady);
  await fs.writeFile(path.resolve(__dirname,'../test-results/ecosystem12-host.json'),JSON.stringify({version:ext.packageJSON.version,skillArguments:true,skillRestriction:true,hooks:['after-apply','after-verification','task-end'],unknownHookPreserved:true,noReplay:true,webviewReady:true},null,2));
 }finally{vscode.window.showWarningMessage=old;await a.commandRunner.dispose();}
};
