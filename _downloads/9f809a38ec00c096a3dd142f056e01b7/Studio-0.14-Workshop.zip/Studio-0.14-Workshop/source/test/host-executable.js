const fs=require('node:fs');
const path=require('node:path');
const {execFileSync}=require('node:child_process');
const {downloadAndUnzipVSCode}=require('@vscode/test-electron');
async function hostExecutable(){
 const executable=process.env.VSCODE_EXECUTABLE||await downloadAndUnzipVSCode('1.139.1');
 if(fs.existsSync(executable))return executable;
 // New macOS bundles can rename the executable; use the signed bundle metadata.
 if(process.platform==='darwin'&&!process.env.VSCODE_EXECUTABLE){
  const root=path.resolve(__dirname,'../.vscode-test/vscode-darwin-'+process.arch+'-1.139.1');
  function* bundles(dir,depth=0){
   if(depth>3)return;
   for(const item of fs.readdirSync(dir,{withFileTypes:true}))if(item.isDirectory()){
    const full=path.join(dir,item.name);
    if(item.name.endsWith('.app'))yield full;else yield* bundles(full,depth+1);
   }
  }
  for(const app of bundles(root)){
   const info=path.join(app,'Contents/Info.plist');if(!fs.existsSync(info))continue;
   const name=execFileSync('/usr/bin/plutil',['-extract','CFBundleExecutable','raw','-o','-',info],{encoding:'utf8'}).trim();
   if(path.basename(name)!==name)continue;
   const candidate=path.join(app,'Contents/MacOS',name);if(fs.existsSync(candidate))return candidate;
  }
 }
 throw Error('VS Code test executable was not found: '+executable);
}
module.exports={hostExecutable};
