from concurrent.futures import ThreadPoolExecutor
import importlib.util
import json
import pathlib
import tempfile
import threading
import unittest
import urllib.error
import uuid
import os
import sys
import types
if os.name == "nt":
    # Protocol tests on Windows; real flock behavior is tested on the SSH host.
    sys.modules["fcntl"] = types.SimpleNamespace(LOCK_EX=2, flock=lambda *args: None)
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch

module = importlib.util.spec_from_file_location('comfy_bridge', pathlib.Path(__file__).parents[1] / 'src/comfy-bridge.py')
bridge = importlib.util.module_from_spec(module)
module.loader.exec_module(bridge)


class BridgeTest(unittest.TestCase):
    def test_idempotency_and_cancel_isolation(self):
        jobs = {}
        submissions = []
        cancelled = []

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def respond(self, value, status=200):
                self.send_response(status)
                self.end_headers()
                self.wfile.write(json.dumps(value).encode())

            def do_GET(self):
                if self.path == '/object_info':
                    self.respond({kind: {'input': {'required': {field: [[value]]}}} for kind, field, value in [('UNETLoader', 'unet_name', 'flux-2-klein.safetensors'), ('CLIPLoader', 'clip_name', 'klein.safetensors'), ('VAELoader', 'vae_name', 'flux2.safetensors')]})
                elif self.path.startswith('/api/jobs/'):
                    self.respond(jobs.get(self.path.split('/')[-1], {}), 200 if self.path.split('/')[-1] in jobs else 404)
                else:
                    self.respond({}, 404)

            def do_POST(self):
                data = json.loads(self.rfile.read(int(self.headers.get('Content-Length', '0'))) or b'{}')
                if self.path == '/prompt':
                    submissions.append(data)
                    jobs[data['prompt_id']] = {'status': 'pending'}
                    self.respond({'prompt_id': data['prompt_id']})
                elif self.path.startswith('/api/jobs/') and self.path.endswith('/cancel'):
                    cancelled.append(self.path.split('/')[-2])
                    self.respond({'cancelled': True})
                else:
                    raise AssertionError('Unexpected effect route: ' + self.path)

        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        try:
            with tempfile.TemporaryDirectory() as directory, patch.object(bridge.os.path, 'expanduser', return_value=directory):
                target = 'http://127.0.0.1:' + str(server.server_port)
                job = str(uuid.uuid4())
                request = {'baseUrl': target, 'operation': 'submit', 'id': job, 'spec': {'workflow': 'text-to-image', 'prompt': 'Test', 'width': 512, 'height': 512, 'count': 1, 'steps': 4, 'seed': 1, 'model': 'flux-2-klein.safetensors', 'encoder': 'klein.safetensors', 'vae': 'flux2.safetensors'}}
                if os.name != 'nt':
                    with ThreadPoolExecutor(max_workers=4) as pool:
                        self.assertTrue(all(r['status'] in ('queued', 'pending') for r in pool.map(bridge.run, [request] * 4)))
                else:
                    self.assertEqual(bridge.run(request)['status'], 'queued')
                bridge.run(request)
                self.assertEqual(len(submissions), 1)
                self.assertEqual(submissions[0]['prompt']['13']['class_type'], 'SaveImage')
                bridge.run({**request, 'operation': 'cancel'})
                self.assertEqual(cancelled, [job])
                with self.assertRaises(FileNotFoundError):
                    bridge.run({**request, 'id': str(uuid.uuid4()), 'operation': 'cancel'})
                jobs.clear()
                self.assertEqual(bridge.run(request)['status'], 'unknown')
                self.assertEqual(len(submissions), 1, 'Lost server history must never replay a saved submission')
                with self.assertRaises(ValueError):
                    bridge.run({**request, 'baseUrl': 'http://example.com'})
        finally:
            server.shutdown()
            server.server_close()


if __name__ == '__main__':
    unittest.main()
