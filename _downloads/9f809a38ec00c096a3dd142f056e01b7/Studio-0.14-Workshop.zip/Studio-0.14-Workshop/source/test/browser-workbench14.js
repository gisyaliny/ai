async page=>{
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 const check=(value,note)=>{if(!value)throw Error(note);};
 for(const port of [18776,18777]){
  await page.goto('http://127.0.0.1:'+port);
  await page.locator('#taskToggle').waitFor();
  await page.evaluate(()=>{fixtureState.permission='auto';fixtureState.messages=[{id:'u',role:'user',text:'Inspect the parser and propose a fix.'},{id:'call',role:'tool',text:'Calling local_read_file'},{id:'result',role:'tool',text:'Tool result local_read_file\n{"content":"fixture"}'},{id:'a',role:'assistant',text:'**Found the boundary case.**\n\nThe proposed fix is ready for review.'}];window.postMessage({type:'state',state:fixtureState},'*');});
  check(await page.locator('.activity-group').count()===1,'Tool activity not grouped');
  check(await page.locator('.markdown strong').textContent()==='Found the boundary case.','Markdown missing');
  for(const width of [280,320,400,900]){
   await page.setViewportSize({width,height:900});
   check(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Page overflow '+width);
   for(const id of ['connect','headerSettings','permissionMenu','modelMenu','send'])check(await page.locator('#'+id).isVisible(),'Invisible control '+id);
   await page.locator('#taskToggle').click();
   check(await page.locator('#changesPanel').isVisible(),'Changes not reachable');
   check(await page.locator('#messages').isVisible()===(width>=720),'Wrong split layout');
   await page.locator('#detail-tab-plan').click();check(await page.locator('#constraintsSection').isVisible(),'Plan constraints hidden');
   await page.locator('#detail-tab-agents').click();check(await page.locator('#startAgent').isVisible(),'Agent control hidden');
   await page.locator('#detail-tab-changes').click();
   await page.locator('#taskToggle').click();
  }
  await page.setViewportSize({width:400,height:900});
  await page.locator('#permissionMenu').click();check(await page.locator('#permissionOptions button').count()===5,'Missing modes');
  await page.locator('#permissionOptions button').nth(1).click();
  check(await page.evaluate(()=>sent.at(-1).type==='permission'&&sent.at(-1).value==='full'),'Full mode action missing');
  await page.evaluate(()=>{fixtureState.permission='full';window.postMessage({type:'state',state:fixtureState},'*');});
  await page.locator('#fullAccessNotice').waitFor({state:'visible'});
  await page.locator('#modelMenu').click();check(await page.locator('#thinkingOptions button').count()===3,'Unsupported thinking levels shown');await page.keyboard.press('Escape');
  await page.locator('#headerSettings').click();check(await page.locator('#toolsPanel').isVisible(),'Settings panel unavailable');await page.locator('.panel-back').click();
  await page.locator('.message-actions button').first().click();check(await page.evaluate(()=>sent.at(-1).type==='copyCode'),'Message copy not dispatched');
  await page.evaluate(()=>{fixtureState.permission='auto';fixtureState.busy=true;fixtureState.pending=[];fixtureState.run={phase:'running'};fixtureState.metrics.requestState='waiting';fixtureState.metrics.requestStartedAt=Date.now()-80000;window.postMessage({type:'state',state:fixtureState},'*');});
  await page.locator('#prompt').fill('Focus on the parser boundary');await page.locator('#send').click();
  check(await page.evaluate(()=>sent.at(-1).type==='queueInput'&&sent.at(-1).kind==='steer'),'Running input does not steer');
  check(await page.locator('#pauseTask').isVisible(),'Pause unavailable');check((await page.locator('#phaseDetail').textContent()).includes('80'),'Elapsed stage missing');
  await page.evaluate(()=>{fixtureState.busy=false;fixtureState.run={phase:'blocked',reason:'Model/tool round limit: 48 / 48'};window.postMessage({type:'state',state:fixtureState},'*');});
  await page.locator('#resumeTask').waitFor({state:'visible'});check((await page.locator('#phaseDetail').textContent()).includes('48 / 48'),'Stop reason hidden');
  await page.locator('#resumeTask').click();check(await page.evaluate(()=>sent.at(-1).type==='resume'),'Resume not dispatched');
  await page.evaluate(()=>{fixtureState.run={phase:'idle'};fixtureState.task.status='awaiting_review';fixtureState.pending=[{id:'fixture',path:'demo.js',summary:'Fix the parser boundary without changing the public API.'}];window.postMessage({type:'state',state:fixtureState},'*');});
  await page.locator('#reviewChanges').waitFor({state:'visible'});await page.emulateMedia({colorScheme:'light'});await page.screenshot({path:'output/playwright/studio-014-'+port+'-light.png'});
  await page.emulateMedia({colorScheme:'dark'});await page.screenshot({path:'output/playwright/studio-014-'+port+'-dark.png'});
  await page.setViewportSize({width:900,height:900});await page.locator('#taskToggle').click();await page.screenshot({path:'output/playwright/studio-014-'+port+'-wide.png'});
 }
 check(!errors.length,errors.join('\n'));console.log('PASS workbench: en/zh, 280–900px, modes, thinking, grouped activity, Markdown, settings, steering, pause/resume, split details.');
}
