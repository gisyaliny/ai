'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs/promises');const path=require('node:path');const os=require('node:os');
const access=require('../src/project-access'),groups=require('../src/change-groups'),files=require('../src/files');
async function fixture(t){const dir=await fs.mkdtemp(path.join(os.tmpdir(),'studio-project-'));t.after(()=>fs.rm(dir,{recursive:true,force:true}));return dir;}
test('large reads are bounded by line/range, preserve Unicode and expose truncated long lines',async t=>{
 const dir=await fixture(t),text=Array.from({length:50000},(_,i)=>'行 '+(i+1)).join('\n');await fs.writeFile(path.join(dir,'large.txt'),text);
 const page=await access.readRange(dir,'large.txt',{startLine:45000,endLine:45002});assert.equal(page.content,'行 45000\n行 45001\n行 45002');assert.equal(page.nextLine,45003);assert.ok(page.scannedBytes<Buffer.byteLength(text));
 await fs.writeFile(path.join(dir,'long.txt'),'x'.repeat(1000000)+'\nlast');const long=await access.readRange(dir,'long.txt',{endLine:1});assert.equal(long.content.length,24000);assert.deepEqual(long.longLines,[1]);assert.equal(long.nextLine,2);
 await assert.rejects(access.readRange(dir,'large.txt',{startLine:0}));await assert.rejects(access.readRange(dir,'../escape'));
 await fs.writeFile(path.join(dir,'binary.txt'),Buffer.from([1,0,2]));await assert.rejects(access.readRange(dir,'binary.txt'),/Binary/);
 const document={lineCount:2,version:7,isDirty:true,lineAt:i=>({text:['unsaved','second'][i]})};assert.equal(access.readDocument(document,'large.txt').content,'unsaved\nsecond');
});
test('listing pages beyond 400 and both search engines share scope, ignores and unsaved precedence',async t=>{
 const dir=await fixture(t);await fs.writeFile(path.join(dir,'.gitignore'),'ignored.txt\n');
 await Promise.all(Array.from({length:430},(_,i)=>fs.writeFile(path.join(dir,String(i).padStart(3,'0')+'.txt'),i>420?'needle':'plain')));
 await fs.writeFile(path.join(dir,'ignored.txt'),'needle');await fs.writeFile(path.join(dir,'.env'),'needle');
 const list=await access.list(dir,{offset:400,limit:100});assert.ok(list.files.includes('429.txt'));assert.equal(list.nextOffset,null);assert.ok(!list.files.includes('.env'));
 const fallback=await access.search(dir,'needle',{rg:false}),preferred=await access.search(dir,'needle');assert.deepEqual(preferred.matches,fallback.matches);assert.equal(fallback.matches.length,9);
 const docs=new Map([['429.txt',{lineCount:1,lineAt:()=>({text:'unsaved unique'})}]]);const result=await access.search(dir,'needle',{documents:docs,rg:false});assert.equal(result.matches.length,8);
 const first=await access.search(dir,'needle',{limit:3,rg:false}),second=await access.search(dir,'needle',{offset:first.nextOffset,limit:10,rg:false});assert.equal(second.matches.length,6);
});
test('group snapshots compose replacements, rename and delete and rewind without hiding conflicts',async t=>{
 const dir=await fixture(t);await fs.writeFile(path.join(dir,'a.txt'),'one two');await fs.writeFile(path.join(dir,'remove.txt'),'gone');
 const snapshot=async relative=>{const target=await files.resolvePath(dir,relative);try{return {target,exists:true,text:await fs.readFile(target,'utf8')};}catch(e){if(e.code!=='ENOENT')throw e;return {target,exists:false,text:''};}};
 const first=await groups.propose([{kind:'edit',path:'a.txt',edits:[{old_text:'one',new_text:'1'},{old_text:'two',new_text:'2'}]},{kind:'delete',path:'remove.txt'},{kind:'create',path:'new.txt',content:'new'}],'group',snapshot);
 assert.equal(first.changes[0].after.text,'1 2');assert.equal(first.changes[1].after.exists,false);first.status='applied';
 const rewind=groups.rewindPlan([first],first.id);assert.equal(rewind.changes[0].after.text,'one two');assert.equal(rewind.changes[2].after.exists,false);
 const rename=await groups.propose([{kind:'rename',path:'a.txt',to:'b.txt'}],'rename',snapshot);assert.equal(rename.changes[1].after.text,'one two');await assert.rejects(groups.propose([{kind:'rename',path:'a.txt',to:'remove.txt'}],'bad',snapshot),/already exists/);
 await assert.rejects(groups.propose([{kind:'edit',path:'a.txt',edits:[{old_text:'one',new_text:'other'}]}],'overlap',snapshot,[first]),/pending/);
 const next=structuredClone(first);next.id='next';next.changes[0].before=groups.state(true,'external edit');assert.throws(()=>groups.rewindPlan([first,next],first.id),/External/);
 first.status='partial';first.observed=Object.fromEntries(first.changes.map((c,i)=>[c.relative,i?'before':'after']));const partial=groups.rewindPlan([first],first.id);assert.equal(partial.changes[1].before.exists,true);
});


test('search accepts a single file and never reports missing scopes as complete zero matches',async t=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'search-file-'));t.after(()=>fs.rm(dir,{recursive:true,force:true}));
 await fs.writeFile(path.join(dir,'target.txt'),'needle one\nneedle two');await fs.writeFile(path.join(dir,'other.txt'),'needle elsewhere');
 for(const rg of [false,'rg']){const result=await access.search(dir,'needle',{directory:'target.txt',rg});assert.equal(result.scanned,1);assert.equal(result.matches.length,2);assert.equal(result.matches[0].path,'target.txt');}
 const documents=new Map([['target.txt',{lineCount:1,lineAt:()=>({text:'unsaved needle'})}]]);const edited=await access.search(dir,'needle',{directory:'target.txt',documents,rg:false});assert.equal(edited.matches[0].text,'unsaved needle');
 await assert.rejects(access.search(dir,'needle',{directory:'missing.txt'}),/ENOENT/);
 await assert.rejects(access.search(dir,'needle',{directory:'../outside.txt'}));
 await fs.writeFile(path.join(dir,'.env'),'needle secret');await assert.rejects(access.search(dir,'needle',{directory:'.env'}));
});


test('search finds matches after huge embedded HTML data and returns a bounded snippet around the hit',async t=>{
 const root=await fixture(t);await fs.writeFile(path.join(root,'embedded.html'),'a'.repeat(1100000)+' needle tail\nsecond needle');
 const result=await access.search(root,'needle',{directory:'embedded.html',rg:false});
 assert.equal(result.matches.length,2);assert.equal(result.truncated,false);assert.ok(result.matches[0].text.includes('needle'));assert.ok(result.matches[0].text.length<=500);assert.ok(result.matches[0].column>1000000);
 const preferred=await access.search(root,'needle',{directory:'embedded.html'});assert.deepEqual(preferred.matches,result.matches);
});
