// Opt-in native VS Code + live model regression. Only synthetic fixture data.
const vscode=require('vscode');
const fs=require('node:fs/promises');
const path=require('node:path');
const assert=require('node:assert/strict');
exports.run=async()=>{
 assert.ok(process.env.STUDIO_FIX_HOST&&process.env.STUDIO_FIX_KEY,'Provide fixture host and credential through environment variables.');
 const extension=vscode.extensions.getExtension('yyang-local.macstudio-assistant');
 const a=await extension.activate();await a.ready;await a.newChat();const root=await a.project();
 const config=vscode.workspace.getConfiguration('macstudio');
 for(const [key,value] of Object.entries({mode:'direct',useServerTokenizer:true,contextTokens:32768,maxOutputTokens:1024,maxToolRounds:4,thinkingLevel:'off',thinkingProtocol:'qwen'}))await config.update(key,value,vscode.ConfigurationTarget.Global);
 const text='This is a synthetic workshop project. Keep the public API unchanged.\n项目用于只读测试，检查目录和文件内容，禁止执行命令或修改任何文件。\n'.repeat(150);
 const file=path.join(root,'context-read.md');await fs.writeFile(file,text);
 const options={host:process.env.STUDIO_FIX_HOST,python:process.env.STUDIO_FIX_PYTHON||'/usr/bin/python3',mode:'direct',includeUsage:true,timeout:120,direct:{baseUrl:process.env.STUDIO_FIX_URL||'http://127.0.0.1:11436/v1',model:process.env.STUDIO_FIX_MODEL,apiKey:process.env.STUDIO_FIX_KEY}};
 assert.ok(options.direct.model,'Provide STUDIO_FIX_MODEL');a.connectionOptions=async()=>options;a.permission='readonly';
 await a.send('Read only: use local_list_files once, then local_read_file to read context-read.md lines 1–200. Briefly report the project purpose and its restriction. Do not execute commands, delegate, or change files.');
 assert.equal(a.task.status,'responded');assert.equal(await fs.readFile(file,'utf8'),text);
 const read=a.journal.find(j=>j.name==='local_read_file'&&j.args.path==='context-read.md');assert.ok(read?.result?.content?.length>6000);
 assert.equal(a.metrics.countSource,'服务端 tokenizer');assert.ok(a.metrics.inputTokens<=a.metrics.budget);
 assert.equal(a.journal.some(j=>j.name==='local_run_command'),false);
 console.log(JSON.stringify({nativeContextRegression:'passed',inputTokens:a.metrics.inputTokens,budget:a.metrics.budget,toolCalls:a.journal.map(j=>j.name),fixtureUnchanged:true}));
};
