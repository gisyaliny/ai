const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const Module=require('node:module');
const {locale,t,zh}=require('../media/i18n');
test('VS Code language maps Chinese locales and falls back to English without changing inserted content',()=>{
 assert.equal(locale('zh-cn'),'zh-CN');assert.equal(locale('zh-TW'),'zh-CN');assert.equal(locale('de'),'en');assert.equal(t('Model',[],'zh-cn'),'模型');assert.equal(t('Model',[],'fr'),'Model');assert.equal(t('Remove {0}',['保留原文件名.js'],'en'),'Remove 保留原文件名.js');
 const source=['media/composer.js','media/experience13.js'].map(f=>fs.readFileSync(f,'utf8')).join('\n');for(const [,key] of source.matchAll(/\bt\('([^']+)'/g))assert.ok(zh[key]||['','Skills','Qwen','OpenClaw'].includes(key),'Missing Chinese UI key: '+key);
});
test('extension manifest localization references have matching English and Chinese resources',()=>{
 const pkg=require('../package.json'),en=require('../package.nls.json'),cn=require('../package.nls.zh-cn.json');
 for(const [,key] of JSON.stringify(pkg).matchAll(/%([^%]+)%/g)){assert.ok(en[key],key);assert.ok(cn[key],key);}
});
test('translated command approval preserves the original action identity and user-entered values',async()=>{
 let captured;const mock={env:{language:'en'},window:{showWarningMessage:async(...args)=>{captured=args;return 'Run once';},showInputBox:async options=>{captured=options;return '用户输入';},showQuickPick:async items=>items[0]}};
 const original=Module._load;Module._load=function(name,...args){return name==='vscode'?mock:original.call(this,name,...args);};const ui=require('../src/host-ui');Module._load=original;
 const selected=await ui.showWarningMessage('允许在本机运行此命令？\n目录：demo\n\nnpm test',{modal:true,detail:'命令将拥有你的系统用户权限，并可能修改文件。仅批准你理解的命令。'},'运行一次');
 assert.match(captured[0],/^Run this command/);assert.equal(selected,'运行一次');assert.equal(captured[2],'Run once');
 const value=await ui.showInputBox({prompt:'计划步骤用 | 分隔；保存后需重新批准',value:'保持原始计划'});assert.equal(value,'用户输入');assert.equal(captured.value,'保持原始计划');assert.match(captured.prompt,/Separate plan/);
 const item={label:'Qwen 模板：开 / 关',value:'qwen'};assert.equal(await ui.showQuickPick([item]),item);
 mock.env.language='zh-cn';assert.equal(ui.translate('请先批准计划'),'请先批准计划');assert.equal(ui.translate('Select code in the editor first.'),'请先在编辑器中选中代码。');
});
