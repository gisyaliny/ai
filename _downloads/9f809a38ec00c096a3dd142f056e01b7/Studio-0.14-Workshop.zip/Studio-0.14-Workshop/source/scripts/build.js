const fs=require('node:fs');
const path=require('node:path');
fs.mkdirSync('dist',{recursive:true});
const result=require('esbuild').buildSync({entryPoints:['src/extension.js'],bundle:true,platform:'node',format:'cjs',target:'node20',external:['vscode'],outfile:'dist/extension.cjs',metafile:true});
fs.copyFileSync('src/bridge.py','dist/bridge.py');
fs.copyFileSync('src/comfy-bridge.py','dist/comfy-bridge.py');
const packages=new Set(),notices=[];
for(const input of Object.keys(result.metafile.inputs)){
  if(!input.startsWith('node_modules/'))continue;
  let dir=path.dirname(input);
  while(dir!=='.'&&!fs.existsSync(path.join(dir,'package.json')))dir=path.dirname(dir);
  if(dir==='.'||packages.has(dir))continue;packages.add(dir);
  const info=JSON.parse(fs.readFileSync(path.join(dir,'package.json'),'utf8'));
  const license=fs.readdirSync(dir).filter(name=>/^licen[sc]e/i.test(name)&&fs.statSync(path.join(dir,name)).isFile()).map(name=>fs.readFileSync(path.join(dir,name),'utf8')).join('\n');
  notices.push(`${info.name} ${info.version}\nLicense: ${info.license||'see upstream'}\n${license}`);
}
fs.writeFileSync('dist/THIRD_PARTY_NOTICES.txt',notices.join('\n\n----------------------------------------\n\n'));
