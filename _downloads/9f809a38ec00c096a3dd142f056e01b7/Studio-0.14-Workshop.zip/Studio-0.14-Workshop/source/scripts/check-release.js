const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const pkg=require('../package.json');
assert.equal(pkg.version,require('../package-lock.json').version);
assert.equal(pkg.version,require('../package-lock.json').packages[''].version);
// Runtime artifacts must not embed machine-specific paths, private-network endpoints or keys.
const patterns=[/\b(?:C|E):[\\/](?:Users|2026)[\\/]/i,/\b100\.(?:6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.\d{1,3}\.\d{1,3}\b/,/ssh\w+@\d{1,3}\.\d{1,3}\./,/Bearer\s+sk-[A-Za-z0-9_-]{12}/,/apiKey\s*:\s*[\x22\x27](?!fixture|test)[a-z0-9-]{12,}[\x22\x27]/i];
for(const base of ['dist','media'])for(const file of walk(base)){
 if(!/\.(?:js|cjs|py|json|css|txt)$/.test(file))continue;
 const text=fs.readFileSync(file,'utf8');for(const pattern of patterns)assert.ok(!pattern.test(text),'Private runtime literal: '+file);
}
function* walk(dir){for(const item of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,item.name);if(item.isDirectory())yield* walk(p);else yield p;}}
console.log('Version and runtime privacy checks passed.');
