'use strict';
const fs=require('node:fs/promises');
const path=require('node:path');
const crypto=require('node:crypto');
const {spawn}=require('node:child_process');
const {SessionStore}=require('./session');
const ACTIVE=new Set(['starting','running','stopping']);
class CommandRunner{
 constructor(directory,onChange=()=>{}){this.directory=directory;this.store=new SessionStore(directory);this.jobs=new Map();this.live=new Map();this.onChange=onChange;}
 async restore(ids=[]){
  for(const id of ids)if(!this.jobs.has(id))try{const job=await this.store.read(id);if(ACTIVE.has(job.status))job.status='interrupted_unknown';this.jobs.set(id,job);}catch{/* Keep inaccessible records for recovery. */}
 }
 result(id){const j=this.jobs.get(id);if(!j)throw Error('Unknown command job');return {id:j.id,status:j.status,exitCode:j.exitCode,reason:j.reason,output:j.output||'',logTruncated:!!j.logTruncated,error:j.error};}
 list(taskId){return [...this.jobs.values()].filter(j=>j.taskId===taskId).map(j=>({...this.result(j.id),command:j.command,startedAt:j.startedAt,finishedAt:j.finishedAt,canStop:this.live.has(j.id)}));}
 async persist(job){await this.store.save({...job,session:job.id});}
 async start({command,cwd,taskId,timeoutMs=600000,signal,authorize=()=>{}}){
  if(!this.directory)throw Error('Command storage unavailable');
  if(signal?.aborted)throw Error('已停止');
  if(typeof command!=='string'||!command.trim()||command.length>4000||!Number.isFinite(timeoutMs)||timeoutMs<100||timeoutMs>86400000)throw Error('Invalid command or timeout');
  const job={id:crypto.randomUUID(),taskId,command,cwd,status:'starting',output:'',startedAt:new Date().toISOString()};
  await this.persist(job);if(signal?.aborted) {job.status='cancelled';await this.persist(job);throw Error('已停止');}
  const log=await fs.open(path.join(this.directory,job.id+'.log'),'wx',0o600);
  try{if(signal?.aborted)throw Error('已停止');authorize();}catch(error){await log.close();job.status='cancelled';await this.persist(job);throw error;}
  this.jobs.set(job.id,job);
  let child;try{child=spawn(process.platform==='win32'?'powershell.exe':'/bin/sh',process.platform==='win32'?['-NoLogo','-NoProfile','-NonInteractive','-Command',command]:['-c',command],{cwd,windowsHide:true,detached:process.platform!=='win32',stdio:['ignore','pipe','pipe']});}
  catch(e){await log.close();job.status='failed';job.error=e.message;await this.persist(job);throw e;}
  let complete;const done=new Promise(r=>complete=r),entry={child,done,background:false};this.live.set(job.id,entry);
  job.status='running';let logQueue=Promise.resolve(),bytes=0,lastNotice=0,finished=false;
  const notify=()=>{try{this.onChange(job);}catch{}};
  const collect=data=>{
   job.output=(job.output+data.toString('utf8')).slice(-24000);
   const keep=data.subarray(0,Math.max(0,8_000_000-bytes));bytes+=keep.length;if(keep.length<data.length)job.logTruncated=true;
   logQueue=logQueue.then(()=>keep.length?log.write(keep):undefined).catch(e=>{job.error='Log write failed: '+e.message;void this.stop(job.id,'storage_error');});
   if(Date.now()-lastNotice>150){lastNotice=Date.now();notify();}
  };
  child.stdout.on('data',collect);child.stderr.on('data',collect);
  const finish=async(code,error)=>{
   if(finished)return;finished=true;clearTimeout(entry.timer);await logQueue;await log.close().catch(()=>{});
   job.exitCode=code;job.status=job.reason==='timeout'?'timed_out':job.reason?'cancelled':code===0?'completed':'failed';if(error)job.error=error.message;
   job.finishedAt=new Date().toISOString();this.live.delete(job.id);
   try{await this.persist(job);}catch(e){job.status='interrupted_unknown';job.error='Result could not be saved: '+e.message;}
   notify();complete(this.result(job.id));
  };
  child.once('error',e=>void finish(-1,e));child.once('close',code=>void finish(code));
  entry.timer=setTimeout(()=>void this.stop(job.id,'timeout'),timeoutMs);
  try{await this.persist(job);}catch(e){await this.stop(job.id,'storage_error');throw e;}
  notify();return job.id;
 }
 async wait(id,{signal,backgroundAfterMs=10000}={}){
  const entry=this.live.get(id);if(!entry)return this.result(id);
  let timer,wake;const background=new Promise(r=>wake=r);entry.detach=()=>{entry.background=true;wake();};
  const abort=()=>{void this.stop(id,'stopped');};signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();
  if(Number.isFinite(backgroundAfterMs))timer=setTimeout(entry.detach,backgroundAfterMs);
  try{await Promise.race([entry.done,background]);return this.result(id);}finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);delete entry.detach;}
 }
 background(id){const entry=this.live.get(id);entry?.detach?.();}
 async stop(id,reason='stopped'){
  const entry=this.live.get(id);if(!entry)return this.result(id);if(entry.stopping)return entry.stopping;
  const job=this.jobs.get(id);job.status='stopping';job.reason=reason;
  entry.stopping=(async()=>{
   try{this.onChange(job);}catch{}
   // Never kill a recovered PID: only process handles owned by this runner are used.
   if(entry.child.pid){
    if(process.platform==='win32')await new Promise(resolve=>{const killer=spawn('taskkill.exe',['/PID',String(entry.child.pid),'/T','/F'],{windowsHide:true});killer.on('error',e=>{job.error=e.message;resolve();});killer.on('close',()=>resolve());});
    else try{process.kill(-entry.child.pid,'SIGKILL');}catch(e){if(e.code!=='ESRCH')job.error=e.message;}
   }
   return this.result(id);
  })();return entry.stopping;
 }
 async stopTask(taskId){await Promise.all([...this.live.keys()].filter(id=>this.jobs.get(id).taskId===taskId).map(id=>this.stop(id)));}
 async dispose(){await Promise.all([...this.live.keys()].map(id=>this.stop(id,'extension_closed')));await Promise.all([...this.live.values()].map(e=>e.done));}
}
module.exports={CommandRunner,ACTIVE};
