'use strict';
const vscode=require('vscode');const fs=require('node:fs/promises');const path=require('node:path');const ui=require('./host-ui');const {sshRequest,completion}=require('./transport');const {validateConnection,diagnosis}=require('./connection');
module.exports={
 async showHistory(query='',scope='project',archived=false,offset=0,requestId=0){
  await this.ready;this.trusted();if(typeof query!=='string'||query.length>500||!['project','all'].includes(scope)||typeof archived!=='boolean'||!Number.isInteger(offset)||offset<0||offset>100000)return;
  const request=Symbol();this.historyRequest=request;
  const roots=scope==='project'?await Promise.all((vscode.workspace.workspaceFolders||[]).map(x=>fs.realpath(x.uri.fsPath).catch(()=>''))):undefined;
  const rows=(await this.store.list({roots,conversations:true,summaries:true,query,includeArchived:true})).filter(s=>!!s.archived===archived).sort((a,b)=>Number(b.pinned)-Number(a.pinned)||String(b.updatedAt).localeCompare(String(a.updatedAt)));
  if(this.historyRequest!==request)return;
  this.historyPage={query,scope,archived,offset,total:rows.length,requestId,items:rows.slice(offset,offset+30).map(s=>({...s,title:(s.title||ui.translate('Untitled chat')).slice(0,160),project:s.root?path.basename(s.root):ui.translate('No project')}))};
  this.publish();if(!requestId)this.view?.webview.postMessage({type:'tab',tab:'history'});
 },
 async historyAction(action,id){
  await this.ready;this.trusted();if(this.busy)throw Error('Wait for the current operation');
  if(!['resume','fork','rename','archive','pin','export'].includes(action))throw Error('Unknown history action');
  return this.exclusive(async()=>{
  const data=await this.store.read(id),conversation=data.conversationId||data.session,meta=await this.store.metadata(conversation);
  if(action==='rename'){const title=await ui.showInputBox({prompt:'Chat title',value:meta.title||data.messages?.find(m=>m.role==='user')?.text?.slice(0,160)||'',validateInput:v=>v.length>160?'Use at most 160 characters':undefined});if(title===undefined)return;await this.store.updateMetadata(conversation,{title:title.trim()});}
  if(action==='archive'){if(conversation===(this.conversationId||this.session)&&this.activeAgents())throw Error('Stop subagents before archiving');await this.store.updateMetadata(conversation,{archived:!meta.archived});}
  if(action==='pin')await this.store.updateMetadata(conversation,{pinned:!meta.pinned});
  if(action==='export'){
   const uri=await vscode.window.showSaveDialog({title:ui.translate('Export chat transcript'),defaultUri:vscode.Uri.file(path.join(require('node:os').homedir(),'studio-chat.md')),filters:{Markdown:['md']}});if(!uri)return;
   const body='# '+String(meta.title||'Studio chat').replace(/\r?\n/g,' ')+'\n\n'+(data.messages||[]).filter(m=>['user','assistant'].includes(m.role)).map(m=>'## '+(m.role==='user'?'User':'Assistant')+'\n\n'+String(m.text||'')).join('\n\n');await vscode.workspace.fs.writeFile(uri,Buffer.from(body));
  }
  if(action==='resume'||action==='fork'){
   if(this.activeAgents())throw Error('Stop subagents before changing chats');await this.checkpoint();
   const roots=await Promise.all((vscode.workspace.workspaceFolders||[]).map(x=>fs.realpath(x.uri.fsPath).catch(()=>'')));
   if(data.root&&!roots.includes(data.root)){
    if(action==='fork')throw Error('Open the original project before branching this chat');const root=await fs.realpath(data.root);await this.context.globalState.update('studio.restore.'+root,id);await vscode.commands.executeCommand('vscode.openFolder',vscode.Uri.file(root),true);return;
   }
   await this.loadSession(data,{locked:true});
   if(action==='fork'){this.conversationId=this.session;this.task={...require('./workflow').newTask(data.task?.goal||''),constraints:structuredClone(data.task?.constraints||[]),steps:structuredClone(data.task?.steps||[]),approved:false};this.pending.clear();this.edits=[];this.inbox=[];this.runState={phase:'idle'};await this.store.updateMetadata(this.conversationId,{title:ui.translate('Branch')+': '+(meta.title||data.messages?.find(m=>m.role==='user')?.text||'Chat').slice(0,130),parent:conversation});await this.checkpoint();}
   this.view?.webview.postMessage({type:'tab',tab:'chat'});this.publish();return;
  }
  const p=this.historyPage||{};return this.showHistory(p.query||'',p.scope||'project',p.archived||false,p.offset||0);
  });
 },
 async setupConnection(){
  return this.exclusive(async()=>{
   if(this.activeAgents())throw Error('Stop subagents before changing the connection');const before=this.options(),draft={...before,mode:'direct',direct:{...before.direct}};
   const fields=[['host','SSH alias or user@host','server-alias'],['identity','SSH identity file (optional)','~/.ssh/id_ed25519'],['python','Remote Python executable','/usr/bin/python3'],['baseUrl','Model API URL on the SSH server','http://127.0.0.1:11436/v1']];
   for(let i=0;i<fields.length;i++){const [key,prompt,placeHolder]=fields[i];const value=await ui.showInputBox({title:ui.translate('Set up connection')+` (${i+1}/5)`,prompt,value:key==='baseUrl'?draft.direct.baseUrl||'':draft[key]||'',placeHolder,ignoreFocusOut:true});if(value===undefined)return;if(key==='baseUrl')draft.direct.baseUrl=value.trim();else draft[key]=value.trim();}
   draft.direct.model=draft.direct.model||'probe';validateConnection(draft);const previousKey=await this.context.secrets.get('macstudio.apiKey');
   const key=await ui.showInputBox({title:ui.translate('Set up connection')+' (5/5)',prompt:previousKey?'API key (leave empty to keep the saved key)':'API key stored in SecretStorage',password:true,ignoreFocusOut:true});if(key===undefined)return;draft.direct.apiKey=key.trim()||previousKey;if(!draft.direct.apiKey)throw Error('API key is required');
   this.connectionChecks=[{name:'Model API',status:'running'}];this.publish();
   let probe;try{probe=JSON.parse(await sshRequest(draft,{mode:'direct',operation:'probe',timeout:30},this.controller.signal));}catch(error){this.connectionChecks=[{name:'Model API',status:'failed',...diagnosis(error)}];this.publish();throw Error(ui.translate(diagnosis(error).hint));}
   const models=[...new Set((probe.models||[]).filter(x=>typeof x==='string'&&x.length>0&&x.length<=500))].slice(0,200);if(!models.length)throw Error('The server reported no models');
   const selected=await ui.showQuickPick(models.map(model=>({label:model,model})),{placeHolder:'Select a model reported by the server'});if(!selected||this.controller.signal.aborted)return;draft.direct.model=selected.model;
   if(JSON.stringify(this.options())!==JSON.stringify(before))throw Error('Connection settings changed; restart setup');
   const c=vscode.workspace.getConfiguration('macstudio'),updates={sshHost:draft.host,sshIdentityFile:draft.identity,remotePython:draft.python,baseUrl:draft.direct.baseUrl,modelId:draft.direct.model,mode:'direct',thinkingLevel:'default'},old={};
   for(const k of Object.keys(updates))old[k]=c.inspect?c.inspect(k)?.globalValue:c.get(k);
   try{for(const [k,v]of Object.entries(updates))await c.update(k,v,vscode.ConfigurationTarget.Global);await this.context.secrets.store('macstudio.apiKey',draft.direct.apiKey);}
   catch(error){const restored=await Promise.allSettled([...Object.entries(old).map(([k,v])=>c.update(k,v,vscode.ConfigurationTarget.Global)),previousKey?this.context.secrets.store('macstudio.apiKey',previousKey):this.context.secrets.delete('macstudio.apiKey')]);if(restored.some(x=>x.status==='rejected'))throw Error('Connection save failed and some previous settings could not be restored. Review Settings before reconnecting.');throw error;}
   this.modelCatalog={items:models};this.connectionStatus='configured';this.connectionChecks=[{name:'Model API',status:'passed'},{name:'Model selection',status:'passed',detail:draft.direct.model}];this.add('tool','Connection saved. Run diagnostics before your first task.');
  });
 },
 async diagnoseConnection(smoke=false){
  if(!this.options().host)return this.setupConnection();
  return this.exclusive(async()=>{
   const before=JSON.stringify(this.options()),options=await this.connectionOptions();this.connectionStatus='connecting';this.connectionChecks=[];const signal=this.controller.signal;
   const step=async(name,operation,optional=false)=>{const row={name,status:'running'};this.connectionChecks.push(row);this.publish();const start=Date.now();try{const result=await operation();row.status='passed';row.elapsedMs=Date.now()-start;return result;}catch(error){row.status=optional?'unreported':'failed';Object.assign(row,diagnosis(error));if(!optional)throw error;}finally{this.publish();}};
   try{
    await step('SSH and Python',()=>sshRequest({...options,direct:undefined},{operation:'health',timeout:15},signal));
    const api=await step('Model API',async()=>JSON.parse(await sshRequest(options,{mode:options.mode,operation:'probe',timeout:30},signal)));
    const resolved=await step('Model selection',async()=>{const value=JSON.parse(await sshRequest(options,{mode:options.mode,operation:'resolve',timeout:15},signal));if(!api.models.includes(value.model))throw Error('Model is not listed by the server');return value;});
    this.resolved={...resolved,transport:'SSH Python bridge',host:options.host};options.resolvedModel=resolved.model;
    this.thinkingCaps=await step('Model capabilities',async()=>{const caps=JSON.parse(await sshRequest(options,{mode:options.mode,operation:'capabilities',timeout:15},signal));if(!caps.contextTokens&&!caps.vision&&!caps.enableThinking&&!caps.effortLevels?.length)throw Error('Capabilities unreported');return caps;},true)||{};this.thinkingCapsModel=resolved.model;
    if(smoke)await step('Model response',async()=>{const response=await completion(options,{messages:[{role:'user',content:'Reply with OK only.'}],max_tokens:64,tool_choice:'none'},signal);if(response.tool_calls?.length)throw Error('Unexpected tools in diagnostic response');return response;});
    if(signal.aborted||JSON.stringify(this.options())!==before)throw Error('Connection settings changed or diagnosis cancelled');
    this.services.model={state:'reachable',model:resolved.model,checkedAt:Date.now()};this.modelCatalog={items:api.models};this.connectionStatus='connected';this.connection='已连接';this.add('tool','Connection diagnostics finished.');return api;
   }catch(error){this.services.model={state:'offline',error:diagnosis(error).hint};this.connectionStatus='failed';this.connection='连接失败';throw Error(ui.translate(diagnosis(error).hint));}finally{this.publish();}
  });
 }
};
