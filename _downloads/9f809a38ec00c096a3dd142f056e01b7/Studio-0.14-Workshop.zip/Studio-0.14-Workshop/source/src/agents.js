'use strict';
const crypto=require('node:crypto');
const {setTimeout:delay}=require('node:timers/promises');
const {SessionStore,repairHistory}=require('./session');
const {estimate,prepareContext}=require('./context');
const READ_TOOLS=new Set(['local_list_files','local_read_json','local_read_file','local_search','local_diagnostics','local_navigation']);
const ACTIVE=new Set(['queued','running']);
class ResearchAgents{
 constructor(directory,onChange=async()=>{}){this.store=new SessionStore(directory);this.jobs=new Map();this.live=new Map();this.onChange=onChange;this.disposed=false;}
 list(taskId){return [...this.jobs.values()].filter(j=>j.taskId===taskId).map(({history,...j})=>({...j}));}
 async publish(job){try{await this.store.save({...job,session:job.id});}catch(error){job.status='failed';job.error='Agent record could not be saved; no further requests will run.';await this.onChange(job).catch(()=>{});throw error;}await this.onChange(job);}
 async start({taskId,task,role='explore',model,contextTokens=16384,maxOutputTokens=2048,maxRounds=6,maxTotalTokens=64000,concurrency=1,system,tools,complete,execute,measure=async(messages,tools)=>({count:estimate(messages,tools),source:'Conservative estimate'}),authorize=()=>{}}){
  if(this.disposed||!this.store.directory)throw Error('Agent storage unavailable');
  if(typeof task!=='string'||!task.trim()||task.length>6000||!['explore','review'].includes(role)||!Number.isInteger(maxRounds)||maxRounds<1||maxRounds>8||!Number.isInteger(concurrency)||concurrency<1||concurrency>2||!Number.isFinite(contextTokens)||contextTokens<4096||contextTokens>65536||!Number.isFinite(maxTotalTokens)||maxTotalTokens<4096||maxTotalTokens>262144)throw Error('Invalid subagent task or budget');
  const existing=[...this.live.values()].find(e=>e.job.taskId===taskId&&e.job.task===task&&e.job.role===role);if(existing)return this.summary(existing.job.id,taskId);
  if(this.list(taskId).length>=12||this.live.size>=4)throw Error('Subagent limit reached (12 per task, 4 queued/running)');
  authorize();const id=crypto.randomUUID(),controller=new AbortController();
  const job={id,taskId,task,role,model,status:'queued',createdAt:new Date().toISOString(),rounds:0,usage:0,budgetUsed:0,contextTokens,maxTotalTokens,history:[{role:'system',content:system},{role:'user',content:task}],evidence:[]};
  this.jobs.set(id,job);const entry={controller,job,concurrency,run:()=>this.run(job,{tools:tools.filter(t=>READ_TOOLS.has(t.function.name)),complete,execute,measure,authorize,maxRounds,maxOutputTokens:Math.min(maxOutputTokens,2048)},controller.signal)};this.live.set(id,entry);
  try{await this.publish(job);}catch(error){this.live.delete(id);this.jobs.delete(id);throw error;}
  this.pump();return this.summary(id,taskId);
 }
 pump(){if(this.disposed)return;for(const entry of this.live.values()){if(entry.job.status!=='queued')continue;const running=[...this.live.values()].filter(e=>e.job.status==='running').length;if(running>=entry.concurrency)break;entry.job.status='running';entry.done=entry.run().catch(()=>{}).finally(()=>{this.live.delete(entry.job.id);this.pump();});}}
 summary(id,taskId){const j=this.jobs.get(id);if(!j||j.taskId!==taskId)throw Error('Unknown subagent in this task');const {history,...result}=j;return {...result};}
 async wait(id,taskId,{signal,timeoutMs=30000}={}){
  const deadline=Date.now()+Math.max(0,Math.min(30000,timeoutMs));
  for(;;){
   signal?.throwIfAborted();const result=this.summary(id,taskId);
   if(!ACTIVE.has(result.status)||Date.now()>=deadline)return result;
   await delay(Math.min(250,deadline-Date.now()),undefined,{signal});
  }
 }
 async run(job,{tools,complete,execute,measure,authorize,maxRounds,maxOutputTokens},signal){
  const timer=setTimeout(()=>{const entry=this.live.get(job.id);if(entry){job.error='Subagent time limit reached';entry.controller.abort();}},180000);timer.unref();
  try{
   const progress=new (require('./read-progress').ReadProgress)();let forceSummary=false;
   for(let round=0;round<maxRounds;round++){
    if(signal.aborted)throw Error('Cancelled');authorize();job.rounds=round+1;
    const finalRound=forceSummary||round===maxRounds-1,requestTools=finalRound?[]:tools;
    let messages=structuredClone(job.history);
    messages[0].content+=`\nInvestigation round ${round+1}/${maxRounds}. Stay within the delegated paths. Reuse evidence already read. ${finalRound?'Return your findings now, including uncertainties and unfinished checks. No further tools.':'Prefer focused searches over listing the entire repository. Stop investigating when you have enough evidence to answer.'}`;
    let measured=await measure(messages,requestTools,signal);
    if(measured.count+maxOutputTokens>job.contextTokens){
     const prepared=prepareContext(messages[0].content,messages.slice(1),requestTools,job.contextTokens-maxOutputTokens);
     messages=prepared.messages;job.compacted=prepared.compacted;measured=await measure(messages,requestTools,signal);
    }
    signal.throwIfAborted();authorize();
    job.inputTokens=measured.count;job.countSource=measured.source;
    if(!Number.isSafeInteger(measured.count)||measured.count<0)throw Error('Invalid subagent token measurement');
    const cost=measured.count+maxOutputTokens;
    if(cost>job.contextTokens||job.budgetUsed+cost>job.maxTotalTokens){job.status='budget_exceeded';job.error=cost>job.contextTokens?'Subagent input still exceeds context budget after trimming.':'Subagent cumulative token budget reached.';break;}
    job.budgetUsed+=cost;await this.publish(job);let usage=0;
    const response=await complete({messages,tools:requestTools,tool_choice:finalRound?'none':'auto',max_tokens:maxOutputTokens},signal,meta=>{if(meta.usage)usage=Number(meta.usage.total_tokens)||0;});
    if(signal.aborted)throw Error('Cancelled');authorize();job.usage+=Math.max(0,usage);if(usage>0)job.budgetUsed=job.budgetUsed-cost+usage;
    job.history.push(response);
    if(!response.tool_calls?.length){if(require('./report').invalidReport(response.content))throw Error('Model returned no findings or tool markup instead of a report; no tool was executed.');job.result=String(response.content||'').slice(0,16000);job.status='completed';break;}
    if(finalRound){job.result=String(response.content||'').slice(0,16000);job.error='Model requested tools during the final report round; tools were not dispatched.';job.status='round_limit';break;}
    for(const call of response.tool_calls){
     if(signal.aborted)throw Error('Cancelled');authorize();let result;
     try{if(!READ_TOOLS.has(call.function.name))throw Error('Subagents are read-only; commands, edits, MCP effects, hooks and nested delegation are unavailable');const args=JSON.parse(call.function.arguments);result=await execute(call.function.name,args,signal);if(progress.observe(call.function.name,args,result)){forceSummary=true;job.repeatedReads=true;}if(args.path)job.evidence=[...new Set([...job.evidence,args.path])].slice(0,100);}
     catch(error){result={error:error.message};}
     const content=JSON.stringify(result);job.history.push({role:'tool',tool_call_id:call.id,content:content.length>24000?JSON.stringify({truncated:true,preview:content.slice(0,23000)}):content});await this.publish(job);
    }
   }
   if(job.status==='running')job.status='round_limit';
  }catch(error){job.status=signal.aborted?'cancelled':'failed';job.error=job.error||String(error.message).slice(0,1000);}
  finally{clearTimeout(timer);job.history=repairHistory(job.history);job.finishedAt=new Date().toISOString();await this.publish(job);}
 }
 async cancel(id,taskId){const job=this.jobs.get(id);if(!job||job.taskId!==taskId)throw Error('Unknown subagent in this task');const live=this.live.get(id);if(!live)return;live.controller.abort();if(job.status==='queued'){job.status='cancelled';job.finishedAt=new Date().toISOString();this.live.delete(id);await this.publish(job);}else await live.done;}
 async cancelTask(taskId){await Promise.allSettled(this.list(taskId).filter(j=>ACTIVE.has(j.status)).map(j=>this.cancel(j.id,taskId)));}
 async restore(ids,taskId){for(const id of (ids||[]).slice(0,12))try{const data=await this.store.read(id);if(data.taskId!==taskId)continue;delete data.schema;delete data.session;this.jobs.set(id,{...data,history:repairHistory(data.history||[]),status:ACTIVE.has(data.status)?'interrupted':data.status});}catch{/* Missing files remain recoverable on disk; never replay. */}}
 async dispose(){this.disposed=true;for(const entry of this.live.values())entry.controller.abort();await Promise.allSettled([...this.live.values()].map(e=>e.done));}
}
module.exports={ResearchAgents,READ_TOOLS,ACTIVE};
