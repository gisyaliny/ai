'use strict';
function validateConnection(options){
 if(!/^[a-zA-Z0-9_][a-zA-Z0-9_.@:\-]*$/.test(options.host||''))throw Error('Enter an SSH alias or user@host without shell options');
 const url=new URL(options.direct.baseUrl);if(!['http:','https:'].includes(url.protocol)||!['localhost','127.0.0.1','[::1]'].includes(url.hostname)||url.username||url.password||url.search||url.hash)throw Error('Use the model service loopback URL on the SSH server');
 if(!options.direct.model||options.direct.model.length>500)throw Error('Model ID is required');return options;
}
function diagnosis(error){const text=String(error?.message||error);
 if(/host key|REMOTE HOST IDENTIFICATION/i.test(text))return {code:'host_key',hint:'Verify the server fingerprint in your terminal, then reconnect. Studio never bypasses SSH host-key checks.'};
 if(/Permission denied|publickey|authentication failed/i.test(text))return {code:'ssh_auth',hint:'Check SSH username, key and agent. Confirm a terminal SSH connection first.'};
 if(/401|403|credential/i.test(text))return {code:'api_auth',hint:'Check the API key and server authorization. Save the key in SecretStorage.'};
 if(/python|No such file|ENOENT|ssh.*not found/i.test(text))return {code:'runtime',hint:'Check local SSH and the remote Python executable in Settings.'};
 if(/model|模型/i.test(text))return {code:'model',hint:'Refresh the model list and select an ID reported by the server.'};
 if(/refused|resolve|timed out|timeout|超时/i.test(text))return {code:'network',hint:'Check the SSH address, network and running model service.'};
 return {code:'connection',hint:'Check the SSH connection and model endpoint in Settings.'};
}
module.exports={validateConnection,diagnosis};
