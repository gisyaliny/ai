'use strict';
// A tool-only template leak is not a completed findings report. Never execute it.
function invalidReport(content){
 const text=String(content||'').trim();
 return /^(?:thinking[.\s…]*|正在思考[.\s…]*)?$/i.test(text)||/^<tool_call>[\s\S]*<\/tool_call>$/i.test(text);
}
module.exports={invalidReport};
