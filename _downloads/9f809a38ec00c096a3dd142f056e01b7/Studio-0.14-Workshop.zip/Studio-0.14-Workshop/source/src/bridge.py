"""Ephemeral SSH bridge. Credentials stay on the Mac; stdout is protocol only."""
import json
import os
import sys
import platform
import subprocess
import urllib.request
import urllib.error
from urllib.parse import urlparse, urlencode


def main():
    request = json.load(sys.stdin)
    if request.get('operation') == 'health':
        print(json.dumps({'ok': True, 'python': platform.python_version(), 'platform': platform.system()}), flush=True)
        return
    mode = request.get('mode', 'openclaw')
    payload = request.get('payload', {})
    if mode != 'direct':
        with open(os.path.expanduser(request['config']), encoding='utf-8') as f:
            config = json.load(f)
    if mode == 'direct':
        direct = request.get('direct', {})
        base = direct.get('baseUrl', '').rstrip('/')
        parsed = urlparse(base)
        if parsed.scheme not in ('http', 'https') or parsed.hostname not in ('localhost', '127.0.0.1', '::1') or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError('Direct endpoint must be a loopback HTTP(S) URL on the Mac')
        key = direct.get('apiKey')
        payload['model'] = direct.get('model')
        if not isinstance(payload['model'], str) or not payload['model'].strip():
            raise ValueError('Model ID is required')
    elif mode == 'openclaw':
        gateway = config.get('gateway', {})
        base = 'http://127.0.0.1:' + str(int(gateway.get('port', 18789))) + '/v1'
        auth = gateway.get('auth', {})
        key = auth.get('token') if auth.get('mode', 'token') == 'token' else auth.get('password')
        payload['model'] = 'openclaw/main'
    elif mode == 'qwen':
        primary = config['agents']['defaults']['model']['primary']
        provider_id, model_id = primary.split('/', 1)
        provider = config['models']['providers'][provider_id]
        base, key = provider['baseUrl'].rstrip('/'), provider.get('apiKey')
        parsed = urlparse(base)
        if parsed.scheme not in ('http', 'https') or parsed.hostname not in ('localhost', '127.0.0.1', '::1') or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError('Direct model must run on the remote Mac loopback interface')
        payload['model'] = model_id
        payload.update(temperature=0.7, top_p=0.8, presence_penalty=1.5)
    else:
        raise ValueError('Unknown mode')
    if not isinstance(key, str) or not key:
        raise ValueError('Remote credential is missing or uses an unsupported SecretRef')
    if request.get('expectedModel') and payload['model'] != request['expectedModel']:
        raise ValueError('Server model changed during this task. Start a new turn to resolve it deliberately.')
    operation = request.get('operation')
    if operation == 'service_status':
        req = urllib.request.Request(base + '/models', headers={'Authorization': 'Bearer ' + key})
        with urllib.request.urlopen(req, timeout=12) as response:
            models = json.load(response).get('data', [])
        selected = next((m for m in models if m.get('id') == payload['model']), {})
        status = selected.get('status') or {}
        state = status.get('value', 'reachable') if isinstance(status, dict) else str(status)
        hardware = platform.machine()
        if platform.system() == 'Darwin':
            try:
                hardware = subprocess.check_output(['sysctl', '-n', 'machdep.cpu.brand_string'], text=True, timeout=2).strip()
            except Exception:
                pass
        print(json.dumps({'model': payload['model'], 'state': state, 'hardware': hardware, 'contextTokens': selected.get('context_length'), 'mode': mode}), flush=True)
        return
    if operation == 'capabilities':
        result = {'effortLevels': [], 'enableThinking': False}
        if mode != 'openclaw':
            try:
                # Router mode exposes its own empty capabilities unless a model is selected.
                req = urllib.request.Request(base.rsplit('/v1', 1)[0] + '/props?' + urlencode({'model': payload['model']}), headers={'Authorization': 'Bearer ' + key})
                with urllib.request.urlopen(req, timeout=10) as response:
                    props = json.load(response)
                caps = props.get('chat_template_caps') or {}
                result['effortLevels'] = [x for x in caps.get('reasoning_effort_levels', []) if x in ('none', 'low', 'medium', 'high')]
                result['enableThinking'] = 'enable_thinking' in props.get('chat_template', '')
                if isinstance(props.get('modalities'), dict):
                    result['vision'] = bool(props['modalities'].get('vision'))
                capacity = props.get('default_generation_settings', {}).get('n_ctx')
                if isinstance(capacity, int) and capacity > 0:
                    result['contextTokens'] = capacity
            except Exception:
                pass
        print(json.dumps(result), flush=True)
        return
    if operation == 'resolve':
        print(json.dumps({'model': payload['model'], 'baseUrl': base, 'mode': mode}), flush=True)
        return
    if operation == 'count_tokens':
        # Optional llama.cpp routes. Other compatible APIs may not implement these.
        origin = base.rsplit('/v1', 1)[0]
        def post(route, body):
            req = urllib.request.Request(origin + route, data=json.dumps(body).encode(), headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=15) as response:
                return json.load(response)
        try:
            rendered = post('/apply-template', {**payload, 'add_generation_prompt': True})
            tokens = post('/tokenize', {'model': payload['model'], 'content': rendered['prompt'], 'add_special': False})
            print(json.dumps({'tokens': len(tokens['tokens']), 'source': 'server tokenizer'}), flush=True)
        except Exception:
            print(json.dumps({'tokens': None, 'source': 'unavailable'}), flush=True)
        return
    probe = request.get('operation') == 'probe'
    url = base + ('/models' if probe else '/chat/completions')
    headers = {'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'}
    req = urllib.request.Request(url, data=None if probe else json.dumps(payload).encode(), headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=int(request.get('timeout', 600))) as response:
            if probe:
                data = json.load(response)
                print(json.dumps({'ok': True, 'mode': mode, 'models': [x['id'] for x in data.get('data', [])]}), flush=True)
            else:
                for line in response:
                    sys.stdout.buffer.write(line)
                    sys.stdout.buffer.flush()
    except urllib.error.HTTPError as error:
        detail = error.read(4096).decode(errors='replace').replace(key, '[redacted]')
        if error.code == 404 and mode == 'openclaw':
            detail = 'Enable gateway.http.endpoints.chatCompletions.enabled on the Mac.'
        raise RuntimeError('Remote HTTP %s: %s' % (error.code, detail)) from None


try:
    main()
except BrokenPipeError:
    pass
except Exception as error:
    print(str(error), file=sys.stderr)
    sys.exit(1)
