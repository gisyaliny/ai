'use strict';
const vscode=require('vscode');
const {frontier,percent}=require('./compaction-policy');
module.exports={
 setupIdleCompaction(){
  this.lastActivity=Date.now();this.idleTimer=setInterval(()=>this.tryIdleCompact().catch(()=>{}),15000);this.idleTimer.unref();
 },
 noteActivity(){this.lastActivity=Date.now();this.idleController?.abort();},
 async cancelIdleCompact(){this.noteActivity();await this.idleCompacting;},
 async tryIdleCompact(now=Date.now()){
  const c=vscode.workspace.getConfiguration('macstudio'),minutes=c.get('idleCompactMinutes',5);
  if(this.disposed||!minutes||this.busy||this.idleCompacting||!vscode.workspace.isTrusted||!this.resolved||this.options().mode!=='direct'||now-this.lastActivity<minutes*60000||this.activeAgents()||this.commandRunner.list(this.task.id).some(j=>j.canStop))return;
  const through=frontier(this.history,this.compaction?.through||0),key=this.session+':'+through;
  if(!through||through<= (this.compaction?.through||0)||key===this.idleAttempt||!(this.metrics.budget>0)||this.metrics.inputTokens<this.metrics.budget*percent(c.get('idleCompactMinPercent',50),50)/100)return;
  // No key prompts or connection setup while the user is idle.
  this.idleAttempt=key;const controller=new AbortController();this.idleController=controller;
  this.idleCompacting=(async()=>{
   const options=this.options(),key=await this.context.secrets.get('macstudio.apiKey');
   if(!key||controller.signal.aborted)return;
   options.direct.apiKey=key;options.resolvedModel=options.direct.model;
   this.metrics.compactionTrigger='idle';this.publish();
   try{await this.compactInternal({options,through,signal:controller.signal});}
   catch(error){if(!controller.signal.aborted)this.add('tool','Idle compaction deferred: '+error.message);}
   finally{delete this.metrics.compactionTrigger;this.publish();}
  })();
  try{await this.idleCompacting;}finally{this.idleCompacting=undefined;this.idleController=undefined;}
 }
};
