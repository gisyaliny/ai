'use strict';
// Preserve user requests independently of lossy model summaries. Internal resume
// markers must never become the task goal. Older saved sessions are migrated here.
function substantive(text){
 return typeof text==='string'&&text.trim()&&!/^\[(?:Workflow|User applied)/i.test(text)&&!/^Continue the saved task\./.test(text)&&! /^(?:continue|继续|继续吧|好的|好|ok)[.!。！\s]*$/i.test(text.trim());
}
function remember(task,text){
 if(!substantive(text))return;
 if(!task.goal)task.goal=text.slice(0,4000);
 task.currentRequest=text; // Original text, never a model paraphrase.
}
function recover(task,history){
 if(!task.currentRequest){const row=history.findLast(m=>m.role==='user'&&substantive(m.content));if(row)remember(task,row.content.split('\n<attached_file ')[0]);}
}
function excerpt(text){return !text||text.length<=4000?text:text.slice(0,2800)+'\n[Long request excerpt; original retained in local session history]\n'+text.slice(-1200);}
module.exports={substantive,remember,recover,excerpt};
