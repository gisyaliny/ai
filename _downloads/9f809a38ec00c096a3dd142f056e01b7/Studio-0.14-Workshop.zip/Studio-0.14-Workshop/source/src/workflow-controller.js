'use strict';
const vscode=require('vscode');
const ui=require('./host-ui');
const crypto=require('node:crypto');
const files=require('./files');
const workflow=require('./workflow');
const projectTools=require('./project');
const {resolveThinking}=require('./thinking');
module.exports={
  ...require('./context-controller'),
  async exclusive(action) {
    await this.cancelIdleCompact();await this.ready;this.trusted();if(this.busy)throw new Error('请等待当前操作结束');
    this.busy=true;this.hookCount=0;this.controller=new AbortController();this.publish();
    try{return await action();}
    finally{this.busy=false;this.controller=undefined;await this.checkpoint().catch(()=>{});this.publish();}
  },
  async apply(id){return this.exclusive(()=>this.applyChange(id));},
  async applyAllAndVerify(){
    await this.exclusive(async()=>{
      if(!require('./permissions').canEffect(this.permission))throw new Error('只读/计划模式禁止应用修改');
      const changes=[...this.pending.values()];if(!changes.length)throw new Error('没有待审阅修改');
      for(const change of changes){if(change.changes){await this.checkChangeStates(change.changes);continue;}const snap=await this.snapshot(change.relative);if(snap.exists!==change.exists||files.hash(snap.text)!==change.originalHash)throw new Error('文件已变化：'+change.relative);}
      for(const change of changes){if(this.controller.signal.aborted)throw new Error('已停止，已应用的文件保留在检查点中');await this.applyChange(change.id);}
    });
    return this.verifyChanges();
  },
  async setVerification(command){
    await this.cancelIdleCompact();await this.ready;this.trusted();if(this.busy)throw new Error('请等待当前操作');
    if(typeof command!=='string'||command.length>16000)throw new Error('Verification recipe is too long.');
    const commands=command.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);if(commands.length>8||commands.some(x=>x.length>4000))throw Error('Use at most 8 commands, one per line, each under 4000 characters.');
    if(JSON.stringify(commands)!==JSON.stringify(this.task.verificationCommands)){this.task.repairAttempts=0;this.task.recipeRemaining=[];this.invalidateVerification();}
    this.task.verificationCommands=commands;this.task.verificationCommand=commands[0]||'';await this.checkpoint();this.publish();
  },
  async verifyChanges(){
    let repair=false,continuePlan=false;
    await this.exclusive(async()=>{
      this.guardEffect('commands');
      let commands=this.task.verificationCommands?.length?[...this.task.verificationCommands]:this.task.verificationCommand?[this.task.verificationCommand]:[];
      if(this.task.recipeRemaining?.length){const prior=this.task.checks.at(-1);if(prior?.status!=='passed'||!await this.evidenceCurrent(prior))throw Error('Finish/reconcile the prior background check and verify file versions before continuing the recipe.');commands=[...this.task.recipeRemaining];}
      if(!commands.length){const command=await ui.showInputBox({prompt:'输入项目的验证命令；执行前仍会显示命令审批',placeHolder:'npm test'});if(!command?.trim())return;if(command.length>4000)throw Error('Verification command too long');commands=[command.trim()];this.task.verificationCommand=commands[0];}
      const recipeId=crypto.randomUUID();this.task.recipeRemaining=[];
      for(let index=0;index<commands.length;index++){
        const check={id:crypto.randomUUID(),recipeId,command:commands[index],status:'started',startedAt:new Date().toISOString(),editIds:this.edits.filter(x=>x.status==='applied').map(x=>x.id),files:await this.fileEvidence()};
        this.task.checks.push(check);this.task.status='verifying';await this.checkpoint();
        try{check.result=await this.runCommand(check.command,await this.project(),this.controller.signal,{waitForExit:true});}
        catch(error){check.result={status:'unknown_check_actual_state',error:error.message};}
        check.status=['running','starting','stopping'].includes(check.result.status)?'running':check.result.status==='denied'?'denied':check.result.reason||check.result.status==='unknown_check_actual_state'?'unknown':check.result.exitCode===0?'passed':'failed';
        await this.runHooks('after-verification',{checkId:check.id,status:check.status},this.controller.signal);
        if(check.status==='passed'&&!await this.evidenceCurrent(check))check.status='stale';
        check.finishedAt=new Date().toISOString();this.task.status=check.status==='running'?'awaiting_command':check.status==='passed'?'verified':check.status==='failed'?'verification_failed':'blocked';
        this.history.push({role:'user',content:'[Workflow verification result] '+JSON.stringify(check)});
        this.add('tool',`验证 ${check.status}\n${check.command}\n${check.result.output||check.result.error||''}`);
        const limit=vscode.workspace.getConfiguration('macstudio').get('maxRepairAttempts',2);
        if(check.status==='failed'&&this.task.repairAttempts<limit&&!this.controller.signal.aborted){this.task.repairAttempts++;repair=true;}
        if(check.status==='running')this.task.recipeRemaining=commands.slice(index+1);
        await this.checkpoint();if(check.status!=='passed'||this.controller.signal.aborted)break;
        if(index===commands.length-1&&!this.recipePassed())this.task.status='awaiting_verification';
        continuePlan=index===commands.length-1&&this.recipePassed()&&!this.requiresPlanApproval()&&this.task.steps.some(x=>x.status!=='done');
      }
    });
    if(repair)return this.send('[Workflow] Verification failed. Inspect the recorded output and relevant files, then propose the smallest repair. Do not run commands or claim the repair is applied; wait for user review.');
    if(continuePlan)return this.send('[Workflow] The recorded verification passed. Update plan steps justified by that evidence and continue remaining approved work. Do not change the approved scope. If complete, report verified checks and remaining limitations.');
  },
  async editPlan(){
    await this.cancelIdleCompact();await this.ready;this.trusted();if(this.busy)throw new Error('请等待当前操作');
    const input=await ui.showInputBox({prompt:'Plan steps separated by |; only Plan mode requires approval',value:this.task.steps.map(s=>s.title).join(' | ')});
    if(input===undefined)return;
    workflow.updatePlan(this.task,input.split('|').map(title=>({title,status:'pending'})),this.permission);await this.checkpoint();this.publish();
  },
  async approvePlan(){
    await this.exclusive(async()=>{
      if(!this.task.steps.length)throw new Error('请先生成或编辑计划');
      this.task.approved=true;this.task.status='running';this.permission='auto';this.fullGrant=undefined;await this.checkpoint();
    });
    return this.send('[Workflow] The user approved the current plan. Execute it step by step. Update step status based on evidence. Propose changes for review; terminal commands still require individual approval.');
  },
  async rewind(id){
    if(this.edits.some(x=>x.changes))return this.rewindChanges(id);
    return this.exclusive(async()=>{
      if(!vscode.workspace.getConfiguration('macstudio').get('allowFileEdits',true))throw Error('File edits are disabled in Tools.');if(!require('./permissions').canEffect(this.permission))throw new Error('只读/计划模式禁止恢复文件');
      const plan=workflow.rewindPlan(this.edits,id),edit=new vscode.WorkspaceEdit(),documents=[];
      for(const target of plan.files){
        const snap=await this.snapshot(target.relative);
        if(!snap.exists||snap.target!==target.target||files.hash(snap.text)!==target.expectedHash){
          const current=await this.snapshot(target.relative),diffId=crypto.randomUUID();
          const left=vscode.Uri.parse(`macstudio-diff:/${diffId}/current`),right=vscode.Uri.parse(`macstudio-diff:/${diffId}/restore`);
          this.diffDocs.set(left.toString(),current.text);this.diffDocs.set(right.toString(),target.restoreText);
          await vscode.commands.executeCommand('vscode.diff',left,right,`${target.relative} · 恢复冲突（未覆盖）`);
          throw new Error('文件存在后续修改，恢复已阻止：'+target.relative);
        }
        const uri=vscode.Uri.file(target.target),doc=await vscode.workspace.openTextDocument(uri);
        if(files.hash(doc.getText())!==target.expectedHash)throw new Error('编辑器内容已变化，恢复取消');
        if(target.restoreExists){edit.replace(uri,new vscode.Range(doc.positionAt(0),doc.positionAt(doc.getText().length)),target.restoreText);documents.push(doc);}
        else edit.deleteFile(uri,{ignoreIfNotExists:false,recursive:false});
      }
      for(const item of plan.selected){item.status='restoring';item.restoreTarget=plan.files.find(x=>x.relative===item.relative);}await this.checkpoint();
      for(const target of plan.files){const current=await this.snapshot(target.relative);if(!current.exists||files.hash(current.text)!==target.expectedHash)throw new Error('保存恢复记录期间文件发生变化，未覆盖');}
      if(this.controller.signal.aborted)throw new Error('恢复已停止，请核对文件状态');
      if(!await vscode.workspace.applyEdit(edit))throw new Error('恢复未完成，请核对实际文件');
      for(const doc of documents)if(!await doc.save())throw new Error('恢复已进入编辑器但保存失败，请手动核对');
      for(const item of plan.selected)item.status='reverted';
      this.pending.clear();this.task.status='restored';this.task.approved=false;this.task.steps.forEach(s=>s.status='pending');
      this.history.push({role:'user',content:'[Workflow] User restored tracked files: '+plan.files.map(x=>x.relative).join(', ')+'. Prior test results are historical; reread and verify again.'});
      this.add('tool','已恢复 '+plan.files.length+' 个文件；外部命令、数据库和远端操作未回滚。');await this.checkpoint();
    });
  },
  async reconcileEdits(){
    if(this.edits.some(x=>x.changes))return this.reconcileGroups();
    return this.exclusive(async()=>{
      let reconciled=0,unknown=0;
      for(const item of this.edits.filter(x=>['applying','restoring'].includes(x.status))){
        const current=await this.snapshot(item.relative);
        if(item.status==='applying'){
          if(current.exists&&files.hash(current.text)===files.hash(item.updated)){item.status='applied';this.pending.delete(item.id);reconciled++;}
          else if(current.exists===item.exists&&files.hash(current.text)===item.originalHash){item.status='not_applied';reconciled++;}
          else unknown++;
        }else if(item.restoreTarget){
          const target=item.restoreTarget;
          if(current.exists===target.restoreExists&&files.hash(current.text)===files.hash(target.restoreText)){item.status='reverted';this.pending.clear();reconciled++;}
          else if(current.exists&&files.hash(current.text)===target.expectedHash){item.status='applied';reconciled++;}
          else unknown++;
        }else unknown++;
      }
      this.task.status=unknown?'blocked':'awaiting_verification';this.task.approved=false;
      this.history.push({role:'user',content:`[Workflow] User reconciled interrupted snapshots: ${reconciled} resolved, ${unknown} unknown. No files or commands were executed. Reread files before continuing.`});
      this.add('tool',`核对完成：${reconciled} 个状态已确认，${unknown} 个仍需手动检查；未修改文件。`);await this.checkpoint();
    });
  },
  async attachPath(relative){
    await this.ready;if(this.busy)throw new Error('请等待当前操作');
    const snap=await this.snapshot(relative);if(!snap.exists)throw new Error('文件不存在');
    if(snap.text.length>60000||this.attachments.length>=5)throw new Error('附件最多 5 个，每个最多 60,000 字符');
    this.attachments.push({label:relative,text:snap.text});this.publish();
  },
  async pickFile(){
    await this.ready;if(this.busy)throw new Error('请等待当前操作');const root=await this.project(),list=[];
    for await(const relative of projectTools.walk(root)){list.push(relative);if(list.length>=5000)break;}
    const selected=await ui.showQuickPick(list,{placeHolder:'选择 @文件（最多展示 5000 个；可直接输入 @"相对路径"）'});
    if(selected)await this.attachPath(selected);
  },
  async openFile(relative){
    const root=await this.project(),target=await files.resolvePath(root,relative);
    await vscode.window.showTextDocument(await vscode.workspace.openTextDocument(vscode.Uri.file(target)),{preview:true});
  },
  thinkingState(){
    const config=vscode.workspace.getConfiguration('macstudio');
    try{return resolveThinking(config.get('thinkingLevel','default'),config.get('thinkingProtocol','qwen'),this.thinkingCaps||{},config.get('mode','direct'));}
    catch(error){return {level:config.get('thinkingLevel','default'),protocol:config.get('thinkingProtocol','qwen'),error:ui.translate(error.message),supported:['default']};}
  },
  async changeThinking(level){
    await this.cancelIdleCompact();await this.ready;this.trusted();if(this.busy)throw new Error('请等待当前操作');
    const config=vscode.workspace.getConfiguration('macstudio');resolveThinking(level,config.get('thinkingProtocol','qwen'),this.thinkingCaps||{},config.get('mode','direct'));
    await config.update('thinkingLevel',level,vscode.ConfigurationTarget.Global);this.publish();
  },
  async pickThinkingProtocol(){
    await this.cancelIdleCompact();await this.ready;this.trusted();if(this.busy)throw new Error('请等待当前操作');
    const selected=await ui.showQuickPick([
      {label:'Qwen 模板：开 / 关',value:'qwen',description:'chat_template_kwargs.enable_thinking'},
      {label:'分级强度：低 / 中 / 高',value:'reasoning_effort',description:'reasoning_effort；服务可能忽略，需确认兼容性'},
      {label:'自动：仅使用服务报告的能力',value:'auto'},
      {label:'服务默认，不覆盖',value:'none'}
    ],{placeHolder:'选择服务实际支持的协议；切换后思考档位恢复默认'});
    if(selected){const config=vscode.workspace.getConfiguration('macstudio');await config.update('thinkingLevel','default',vscode.ConfigurationTarget.Global);await config.update('thinkingProtocol',selected.value,vscode.ConfigurationTarget.Global);this.publish();}
  },
  async handleInput(text){
    await this.cancelIdleCompact();
    if(typeof text!=='string')return;if(this.busy)return this.queueInput(text,'next');
    const command=/^\/(plan|compact|review|test|help|thinking|init|memory|context|hooks|agents|history|connect)(?:\s+([\s\S]*))?$/.exec(text.trim());
    if(command){
      const [,name,value]=command;
      if(name==='agents'){this.view?.webview.postMessage({type:'tab',tab:'work'});return value?this.exclusive(async()=>{this.add('user',value);this.history.push({role:'user',content:value});if(!this.task.goal)this.task.goal=value;await this.checkpoint();return this.delegateTask({task:value,role:'explore'});}):this.startAgentFromUi();}
      if(name==='history')return this.showHistory(value||'');
      if(name==='connect')return this.diagnoseConnection();
      if(name==='hooks')return this.manageHooks();
      if(name==='init')return this.initProject();
      if(name==='memory')return this.editMemory(value?.trim()==='clear');
      if(name==='context')return this.showContext();
      if(name==='compact')return this.compact(value?.trim()||'semantic');
      if(name==='test')return this.verifyChanges();
      if(name==='review'){this.view?.webview.postMessage({type:'tab',tab:'changes'});return;}
      if(name==='thinking'){if(value)return this.changeThinking(value.trim());this.add('tool',JSON.stringify(this.thinkingState()));return;}
      if(name==='help'){this.add('tool','/plan 任务 · /compact · /review · /test · /thinking default|off|on|low|medium|high\n@"相对路径" 添加文件；@ 按钮可搜索文件。');return;}
      if(name==='plan'){if(this.busy)throw new Error('请等待当前操作');this.permission='plan';this.task.approved=false;return this.send(value||'请根据当前任务生成可审阅的分步计划，调用 local_update_plan。');}
    }
    const skillCommand=/^\/([^\s]+)(?:\s+([\s\S]*))?$/.exec(text.trim());if(skillCommand&&await this.invokeSkill(skillCommand[1],skillCommand[2]))return;
    for(const match of text.matchAll(/(?:^|\s)@(?:"([^"\n]+)"|([^\s]+))/g))await this.attachPath(match[1]||match[2]);
    return this.send(text);
  }
};
