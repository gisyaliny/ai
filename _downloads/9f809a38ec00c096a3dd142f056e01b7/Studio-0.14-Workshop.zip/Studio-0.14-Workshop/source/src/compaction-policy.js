'use strict';
// Only cut at an assistant boundary: never separate a tool call from its result.
function frontier(history, previous=0) {
 const latest=history.findLastIndex(m=>m.role==='user');
 if(latest>previous)return latest;
 for(let i=history.length-8;i>previous;i--)if(history[i].role==='assistant')return i;
 return previous;
}
function percent(value, fallback){return Number.isFinite(value)?Math.min(95,Math.max(25,value)):fallback;}
module.exports={frontier,percent};
