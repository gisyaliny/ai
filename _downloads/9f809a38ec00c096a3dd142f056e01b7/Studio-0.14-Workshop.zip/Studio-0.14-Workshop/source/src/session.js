'use strict';
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');

function repairHistory(history, journal = []) {
  const repaired = [];
  for (let i = 0; i < history.length; i++) {
    const message = history[i];
    const messageIndex = i;
    repaired.push(message);
    if (!message.tool_calls?.length) continue;
    const results = new Map();
    while (history[i + 1]?.role === 'tool') { const next = history[++i]; results.set(next.tool_call_id, next); }
    for (const call of message.tool_calls) {
      const record = journal.find(x => x.id === call.id && x.messageIndex === messageIndex);
      repaired.push(results.get(call.id) || { role: 'tool', tool_call_id: call.id, content: JSON.stringify(record?.result || {
        status: record ? 'interrupted_unknown' : 'not_executed',
        message: record ? 'Execution may have occurred. Inspect actual state before proposing any retry. Never automatically replay.' : 'Interrupted before dispatch. Not executed.'
      }) });
    }
  }
  return repaired;
}
class SessionStore {
  constructor(directory,{schema=1}={}) { this.schema=schema;this.directory = directory; this.queue = Promise.resolve(); }
  async importLegacy(directories) {
    if (!this.directory) return;
    await fs.mkdir(this.directory, { recursive: true, mode: 0o700 });
    for (const directory of new Set(directories.filter(d => d && d !== this.directory))) {
      const names = await fs.readdir(directory).catch(e => { if (e.code === 'ENOENT') return []; throw e; });
      for (const name of names.filter(n => /^[a-f0-9-]{36}\.json$/.test(n))) {
        // Never move or overwrite an original conversation, including corrupt files.
        await fs.copyFile(path.join(directory, name), path.join(this.directory, name), 1).catch(e => { if (e.code !== 'EEXIST') throw e; });
      }
    }
  }
  save(value) {
    if (!this.directory) return Promise.resolve();
    if (!/^[a-f0-9-]{36}$/.test(value.session)) return Promise.reject(new Error('Invalid session ID'));
    const data = JSON.stringify({ ...value, schema: this.schema, updatedAt: new Date().toISOString() });
    if (Buffer.byteLength(data) > 24_000_000) return Promise.reject(new Error('会话超过本地保存上限；已停止新请求，当前内存内容未删除'));
    const target = path.join(this.directory, value.session + '.json');
    const run = async () => {
      await fs.mkdir(this.directory, { recursive: true, mode: 0o700 });
      const temp = target + '.' + crypto.randomUUID() + '.tmp';
      try { await fs.writeFile(temp, data, { mode: 0o600 }); await fs.rename(temp, target); }
      finally { await fs.rm(temp, { force: true }).catch(() => {}); }
    };
    this.queue = this.queue.catch(() => {}).then(run); return this.queue;
  }
  async read(session) {
    if (!/^[a-f0-9-]{36}$/.test(session)) throw new Error('Invalid session ID');
    const file = path.join(this.directory, session + '.json');
    if ((await fs.stat(file)).size > 24_000_000) throw new Error('Session exceeds local storage limit');
    const data = JSON.parse(await fs.readFile(file, 'utf8'));
    if (![1,this.schema].includes(data.schema) || data.session !== session) throw new Error('Invalid saved session');
    return {...data,schema:this.schema};
  }
  async metadata(id){
    if(!/^[a-f0-9-]{36}$/.test(id))throw Error('Invalid conversation ID');
    try{const file=path.join(this.directory,id+'.meta.json');if((await fs.stat(file)).size>16000)throw Error('Invalid conversation metadata');return JSON.parse(await fs.readFile(file,'utf8'));}catch(e){if(e.code==='ENOENT')return {};throw e;}
  }
  updateMetadata(id,patch){
    if(!/^[a-f0-9-]{36}$/.test(id)||!patch||Object.keys(patch).some(k=>!['title','archived','pinned','parent'].includes(k))||patch.title!==undefined&&(typeof patch.title!=='string'||patch.title.length>160)||patch.archived!==undefined&&typeof patch.archived!=='boolean'||patch.pinned!==undefined&&typeof patch.pinned!=='boolean'||patch.parent!==undefined&&!/^[a-f0-9-]{36}$/.test(patch.parent))return Promise.reject(Error('Invalid conversation metadata'));
    const run=async()=>{const data={...await this.metadata(id),...patch};await fs.mkdir(this.directory,{recursive:true});const file=path.join(this.directory,id+'.meta.json'),temp=file+'.'+crypto.randomUUID()+'.tmp';try{await fs.writeFile(temp,JSON.stringify(data),{mode:0o600});await fs.rename(temp,file);}finally{await fs.rm(temp,{force:true}).catch(()=>{});}return data;};this.queue=this.queue.catch(()=>{}).then(run);return this.queue;
  }
  async list({ roots, conversations = false, summaries = false, query='', includeArchived=false } = {}) {
    if (!this.directory) return [];
    const names = await fs.readdir(this.directory).catch(e => { if (e.code === 'ENOENT') return []; throw e; });
    const entries = await Promise.all(names.filter(n => /^[a-f0-9-]{36}\.json$/.test(n)).map(async name => ({name,stat:await fs.stat(path.join(this.directory,name))})));
    const result = [];
    const seen = new Set();
    for (const {name,stat} of entries.sort((a,b)=>b.stat.mtimeMs-a.stat.mtimeMs)) {
      if (stat.size > 24_000_000) continue;
      try {
        const data=JSON.parse(await fs.readFile(path.join(this.directory,name),'utf8'));
        if (![1,this.schema].includes(data.schema) || data.session + '.json' !== name || (roots && data.root && !roots.includes(data.root))) continue;
        const id = data.conversationId || data.session;
        if (conversations && (seen.has(id) || !data.messages?.some(m => m.role === 'user'))) continue;
        seen.add(id);const meta=await this.metadata(id).catch(()=>({}));if(meta.archived&&!includeArchived)continue;
        if(query&&!([meta.title,data.root,...(data.messages||[]).filter(m=>['user','assistant'].includes(m.role)).map(m=>m.text)].join('\n').toLowerCase().includes(String(query).toLowerCase())))continue;
        result.push(summaries ? {session:data.session,conversationId:id,root:data.root,updatedAt:data.updatedAt,title:meta.title||data.messages?.find(m=>m.role==='user')?.text,archived:!!meta.archived,pinned:!!meta.pinned,parent:meta.parent} : data);
      } catch { /* Keep corrupt files for manual recovery; never overwrite them. */ }
    }
    return result;
  }
}
module.exports = { SessionStore, repairHistory };
