// Content/existence snapshots are shared by grouped apply, recovery and rewind.
'use strict';
const crypto=require('node:crypto');
const files=require('./files');
const state=(exists,text='')=>({exists,text,hash:files.hash(text)});
const equal=(a,b)=>a.exists===b.exists&&a.hash===b.hash;
function changes(record){return record.changes||[{relative:record.relative,target:record.target,before:state(record.exists,record.original),after:state(true,record.updated)}];}
async function propose(operations,summary,snapshot,pending=[]){
 if(!Array.isArray(operations)||!operations.length||operations.length>20)throw Error('A change group requires 1–20 operations.');
 const result=[],seen=new Set(),used=new Set(pending.flatMap(x=>changes(x).map(c=>c.target)));
 const take=async relative=>{const snap=await snapshot(relative);if(seen.has(snap.target)||used.has(snap.target))throw Error('Path already belongs to a pending operation: '+relative);seen.add(snap.target);return snap;};
 for(const op of operations){
  if(!['edit','create','delete','rename'].includes(op.kind))throw Error('Unknown change operation.');
  const snap=await take(op.path),before=state(snap.exists,snap.text);
  if(op.kind==='create'){
   if(snap.exists)throw Error('Create target already exists: '+op.path);
   if(typeof op.content!=='string'||op.content.includes('\0')||Buffer.byteLength(op.content)>2_000_000)throw Error('Create needs bounded UTF-8 text.');
   result.push({relative:op.path,target:snap.target,before,after:state(true,op.content)});
  }else{
   if(!snap.exists)throw Error('File does not exist: '+op.path);
   if(op.kind==='edit'){
    if(!Array.isArray(op.edits)||!op.edits.length||op.edits.length>100)throw Error('Provide 1–100 exact replacements.');
    let text=snap.text;for(const edit of op.edits)text=files.editText(text,edit.old_text,edit.new_text,true);
    if(text.includes('\0')||Buffer.byteLength(text)>2_000_000)throw Error('Updated file exceeds the text edit limit.');
    result.push({relative:op.path,target:snap.target,before,after:state(true,text)});
   }else if(op.kind==='delete')result.push({relative:op.path,target:snap.target,before,after:state(false)});
   else{
    const destination=await take(op.to);if(destination.exists)throw Error('Rename target already exists: '+op.to);
    result.push({relative:op.path,target:snap.target,before,after:state(false),renameTo:op.to});
    result.push({relative:op.to,target:destination.target,before:state(false),after:state(true,snap.text),renameFrom:op.path});
   }
  }
 }
 if(result.length>20||result.reduce((n,c)=>n+Buffer.byteLength(c.before.text)+Buffer.byteLength(c.after.text),0)>4_000_000)throw Error('Split this group: at most 20 paths and 4 MB of snapshots.');
 return {id:crypto.randomUUID(),relative:result.map(c=>c.relative).join(' · '),summary:String(summary||'Review grouped changes').slice(0,400),changes:result,status:'Awaiting review'};
}
function rewindPlan(records,id){
 const index=records.findIndex(x=>x.id===id);if(index<0)throw Error('Checkpoint not found');
 if(records.slice(index).some(x=>['applying','restoring'].includes(x.status)))throw Error('Reconcile interrupted changes before rewind.');
 const selected=records.slice(index).filter(x=>['applied','partial'].includes(x.status));if(!selected.length)throw Error('No applied changes to rewind');
 const byPath=new Map();
 for(const record of selected)for(const c of changes(record)){
  let expected=c.after;
  if(record.status==='partial'){
   const observed=record.observed?.[c.relative];if(!['before','after'].includes(observed))throw Error('Resolve external conflicts before rewind: '+c.relative);
   if(observed==='before')expected=c.before;
  }
  const prior=byPath.get(c.relative);if(prior&&!equal(prior.before,c.before))throw Error('External changes between checkpoints: '+c.relative);
  byPath.set(c.relative,{relative:c.relative,target:c.target,before:expected,after:prior?prior.after:c.before});
 }
 return {selected,changes:[...byPath.values()]};
}
module.exports={state,equal,changes,propose,rewindPlan};
