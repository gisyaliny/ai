'use strict';
const vscode=require('vscode');
const fs=require('node:fs/promises');
const path=require('node:path');
const crypto=require('node:crypto');
const ui=require('./host-ui');
const files=require('./files');
const access=require('./project-access');
const project=require('./project');
const groups=require('./change-groups');
module.exports={
 async readProjectJson(args,signal){
  const root=await this.project(),target=await files.resolvePath(root,args.path);
  const doc=vscode.workspace.textDocuments.find(d=>d.uri.toString()===vscode.Uri.file(target).toString());
  let text;
  if(doc){text=doc.getText();if(Buffer.byteLength(text)>32*1024*1024)throw Error('JSON exceeds 32 MiB.');}
  else {const report={},rows=[];for await(const row of access.lines(root,args.path,{signal,report,maxLine:32*1024*1024})){if(row.truncated)throw Error('JSON exceeds scan limit.');rows.push(row.text);}if(report.truncated)throw Error('JSON exceeds 32 MiB.');text=rows.join('\n');}
  signal?.throwIfAborted();this.instructionFocus=target;
  return {...require('./json-page').page(text,args),revision:files.hash(text),unsaved:!!doc?.isDirty,instructions:await project.instructions(root,target)};
 },
 async readProjectFile(args,signal){
  const root=await this.project(),target=await files.resolvePath(root,args.path),uri=vscode.Uri.file(target);
  const doc=vscode.workspace.textDocuments.find(d=>d.uri.toString()===uri.toString());
  const result=doc?access.readDocument(doc,args.path,args):await access.readRange(root,args.path,{...args,signal});
  this.instructionFocus=target;result.instructions=await project.instructions(root,target);return result;
 },
 async searchProject(args,signal){
  const root=await this.project(),documents=new Map();
  for(const doc of vscode.workspace.textDocuments)if(doc.uri.scheme==='file'&&files.within(root,doc.uri.fsPath))documents.set(path.relative(root,doc.uri.fsPath).split(path.sep).join('/'),doc);
  return access.search(root,args.query,{directory:args.directory||'.',offset:args.offset??0,signal,documents});
 },
 async navigateProject(args){
  const root=await this.project(),target=await files.resolvePath(root,args.path),uri=vscode.Uri.file(target);await vscode.workspace.openTextDocument(uri);
  if(!['symbols','definition','references'].includes(args.kind))throw Error('Choose symbols, definition or references.');
  const command={symbols:'vscode.executeDocumentSymbolProvider',definition:'vscode.executeDefinitionProvider',references:'vscode.executeReferenceProvider'}[args.kind];
  const position=new vscode.Position(Math.max(0,(args.line||1)-1),Math.max(0,(args.column||1)-1));
  if(!Number.isSafeInteger(args.line??1)||!Number.isSafeInteger(args.column??1)||(args.line??1)<1||(args.column??1)<1)throw Error('Use positive integer positions.');
  const values=await vscode.commands.executeCommand(command,uri,...(args.kind==='symbols'?[]:[position]));
  if(!Array.isArray(values)||!values.length)return {items:[],note:'No provider results. The language extension may be unavailable; this is not proof that no symbol exists.'};
  const items=[];
  const add=async(value,parent)=>{
   const location=value.location,resource=value.targetUri||location?.uri||value.uri||uri,range=value.targetSelectionRange||location?.range||value.selectionRange||value.range;
   if(resource.scheme!=='file'||!range||!files.within(root,resource.fsPath))return;
   const relative=path.relative(root,resource.fsPath);try{await files.resolvePath(root,relative);}catch{return;}
   items.push({path:relative,line:range.start.line+1,column:range.start.character+1,name:value.name,parent,kind:value.kind});
   for(const child of value.children||[])if(items.length<100)await add(child,value.name);
  };
  for(const value of values){if(items.length>=100)break;await add(value);}
  return {items,truncated:items.length>=100,note:'VS Code language provider results, scoped to this project.'};
 },
 async proposeChanges(args){
  this.guardEffect('files');if(this.pending.size>=20)throw Error('Review pending changes first.');
  const group=await groups.propose(args.operations,args.summary,p=>this.snapshot(p),[...this.pending.values()]);
  this.pending.set(group.id,group);await this.checkpoint();this.publish();
  if(this.hasFullAccess()){await this.applyGroup(group.id);return {id:group.id,status:'applied',checkpointId:this.edits.at(-1)?.id,paths:group.changes.map(c=>c.relative)};}
  return {id:group.id,status:'proposed_only',paths:group.changes.map(c=>({path:c.relative,beforeExists:c.before.exists,afterExists:c.after.exists})),instructions:await Promise.all(group.changes.map(c=>project.instructions(this.root,c.target))),note:'Review the complete group; nothing has been applied.'};
 },
 async previewGroup(id,relative){
  const record=this.pending.get(id);if(!record)throw Error('Change is no longer pending.');
  const changes=groups.changes(record);let change=changes.find(c=>c.relative===relative);
  if(!change){const choice=await ui.showQuickPick(changes.map(c=>({label:c.relative,description:!c.after.exists?'Delete':!c.before.exists?'Create':'Edit',change:c})),{placeHolder:'Review a file in this change group'});change=choice?.change;}
  if(!change)return;
  const key=crypto.randomUUID(),left=vscode.Uri.parse(`macstudio-diff:/${key}/before`),right=vscode.Uri.parse(`macstudio-diff:/${key}/after`);
  this.diffDocs.set(left.toString(),change.before.text);this.diffDocs.set(right.toString(),change.after.text);
  await vscode.commands.executeCommand('vscode.diff',left,right,change.relative+' · '+ui.translate('Review'),{preview:true});
 },
 async checkChangeStates(changes){
  for(const c of changes){const snap=await this.snapshot(c.relative);if(snap.target!==c.target||snap.dirty||!groups.equal(groups.state(snap.exists,snap.text),c.before))throw Error('File changed or has unsaved edits; no overwrite: '+c.relative);}
 },
 async writeChangeStates(changes,{restore=false}={}){
  const guard=()=>{this.trusted();if(restore)require('./permissions').assertEffect('files',{permission:this.permission,enabled:vscode.workspace.getConfiguration('macstudio').get('allowFileEdits',true)});else this.guardEffect('files');};guard();await this.checkChangeStates(changes);const edit=new vscode.WorkspaceEdit(),save=[];
  const renamed=new Set();
  for(const c of changes)if(c.renameTo){const destination=changes.find(x=>x.relative===c.renameTo);if(!destination)throw Error('Invalid rename snapshot');edit.renameFile(vscode.Uri.file(c.target),vscode.Uri.file(destination.target),{overwrite:false,ignoreIfExists:false});renamed.add(c.relative);renamed.add(destination.relative);}
  for(const c of changes){
   if(renamed.has(c.relative))continue;const uri=vscode.Uri.file(c.target);
   if(!c.after.exists){if(c.before.exists)edit.deleteFile(uri,{recursive:false,ignoreIfNotExists:false});continue;}
   if(!c.before.exists){edit.createFile(uri,{overwrite:false,ignoreIfExists:false});edit.insert(uri,new vscode.Position(0,0),c.after.text);}
   else{const doc=await vscode.workspace.openTextDocument(uri);edit.replace(uri,new vscode.Range(doc.positionAt(0),doc.positionAt(doc.getText().length)),c.after.text);}
   save.push(c);
  }
  for(const c of changes)if(c.after.exists&&!c.before.exists){await fs.mkdir(path.dirname(c.target),{recursive:true});await files.resolvePath(await this.project(),c.relative);}
  await this.checkChangeStates(changes);guard();if(this.controller?.signal.aborted)throw Error('Stopped before applying changes');
  if(!await vscode.workspace.applyEdit(edit))throw Error('Apply was incomplete. Reconcile actual file state before retrying.');
  for(const c of save){const doc=await vscode.workspace.openTextDocument(vscode.Uri.file(c.target));if(!await doc.save())throw Error('Save failed; reconcile editor and disk state: '+c.relative);}
 },
 async applyGroup(id){
  this.guardEffect('files');if(this.edits.length>=100)throw Error('Start a new task after 100 checkpoints.');
  const record=this.pending.get(id);if(!record)throw Error('Change is no longer pending.');
  if(this.edits.some(x=>(x.groupId||x.id)===id&&['applying','restoring','partial'].includes(x.status)))throw Error('Reconcile or rewind the interrupted group before applying again.');
  await this.checkChangeStates(record.changes);
  const checkpoint={...structuredClone(record),id:this.edits.some(x=>x.id===id)?crypto.randomUUID():id,groupId:id,status:'applying',createdAt:new Date().toISOString(),taskId:this.task.id};
  this.edits.push(checkpoint);await this.checkpoint();
  try{await this.writeChangeStates(record.changes);}catch(error){checkpoint.error=error.message;await this.checkpoint();throw error;}
  checkpoint.status='applied';this.pending.delete(id);this.invalidateVerification();this.task.status='awaiting_verification';
  if(!this.hasFullAccess())this.history.push({role:'user',content:'[Workflow] '+(this.hasFullAccess()?'Full access applied':'User applied reviewed')+' change group: '+record.changes.map(c=>c.relative).join(', ')});
  this.add('tool','Applied change group: '+record.changes.length+' paths');await this.checkpoint();await this.runHooks('after-apply',{checkpointId:checkpoint.id},this.controller?.signal);this.publish();
 },
 async rewindChanges(id){
  return this.exclusive(async()=>{
   this.trusted();require('./permissions').assertEffect('files',{permission:this.permission,enabled:vscode.workspace.getConfiguration('macstudio').get('allowFileEdits',true)});const plan=groups.rewindPlan(this.edits,id);await this.checkChangeStates(plan.changes);
   for(const record of plan.selected){record.status='restoring';record.restoreChanges=plan.changes;}await this.checkpoint();
   await this.writeChangeStates(plan.changes,{restore:true});
   for(const record of plan.selected)record.status='reverted';this.pending.clear();this.invalidateVerification();this.task.status='restored';this.task.approved=false;this.task.steps.forEach(s=>s.status='pending');
   this.history.push({role:'user',content:'[Workflow] User restored content/existence snapshots for '+plan.changes.map(c=>c.relative).join(', ')+'. External commands and services were not rolled back.'});await this.checkpoint();this.publish();
  });
 },
 async reconcileGroups(){
  return this.exclusive(async()=>{
   for(const record of this.edits.filter(x=>['applying','partial','restoring'].includes(x.status))){
    const restoring=record.status==='restoring',changes=restoring?record.restoreChanges:groups.changes(record);if(!changes){record.status='partial';continue;}
    record.observed={};
    for(const c of changes){const snap=await this.snapshot(c.relative),current=groups.state(snap.exists,snap.text);record.observed[c.relative]=snap.dirty?'conflict':groups.equal(current,c.after)?'after':groups.equal(current,c.before)?'before':'conflict';}
    const values=Object.values(record.observed);
    if(values.every(x=>x==='after')){record.status=restoring?'reverted':'applied';this.pending.delete(record.groupId||record.id);}
    else if(values.every(x=>x==='before'))record.status=restoring?'applied':'not_applied';else record.status=restoring?'restoring':'partial';
   }
   this.invalidateVerification();this.task.approved=false;this.task.status=this.edits.some(x=>['partial','restoring'].includes(x.status))?'blocked':'awaiting_verification';await this.checkpoint();this.publish();
  });
 },
 invalidateVerification(){for(const check of this.task.checks)if(check.status==='passed')check.status='stale';if(this.task.status==='verified')this.task.status='awaiting_verification';},
 recipePassed(){const last=this.task.checks.at(-1);return !!last&&last.status==='passed'&&!this.task.recipeRemaining?.length&&this.task.checks.filter(c=>c.recipeId===last.recipeId).every(c=>c.status==='passed');},
 async projectChanged(uri){
  if(!this.root||uri.scheme!=='file'||!files.within(this.root,uri.fsPath)||files.blocked(path.relative(this.root,uri.fsPath)))return;
  const taskId=this.task.id,check=this.task.checks.at(-1);if(check?.status!=='passed')return;
  const relative=path.relative(this.root,uri.fsPath);
  if(!Object.hasOwn(check.files||{},relative)||!await this.evidenceCurrent(check)){if(this.task.id!==taskId)return;this.invalidateVerification();await this.checkpoint();this.publish();}
 },
 async fileEvidence(){
  const paths=[...new Set(this.edits.filter(x=>x.status==='applied').flatMap(x=>groups.changes(x).map(c=>c.relative)))],evidence={};
  for(const relative of paths){const snap=await this.snapshot(relative);if(snap.dirty)throw Error('Save editor changes before verification: '+relative);evidence[relative]={exists:snap.exists,hash:files.hash(snap.text)};}
  return evidence;
 },
 async evidenceCurrent(check){try{return !!check?.files&&JSON.stringify(check.files)===JSON.stringify(await this.fileEvidence());}catch{return false;}},
 async memoryFile(){const root=await this.project(),base=this.context.globalStorageUri||this.context.storageUri;if(!base)throw Error('Local storage unavailable.');return path.join(base.fsPath,'project-memory',files.hash(root)+'.md');},
 async memoryText(){const file=await this.memoryFile();try{const stat=await fs.stat(file);if(stat.size>12000)throw Error('Project memory exceeds 12000 bytes.');return await fs.readFile(file,'utf8');}catch(error){if(error.code==='ENOENT')return '';throw error;}},
 async editMemory(clear=false){
  await this.ready;this.trusted();if(this.busy)throw Error('Wait for the current task.');const file=await this.memoryFile();
  if(clear){await fs.unlink(file).catch(error=>{if(error.code!=='ENOENT')throw error;});this.add('tool','Project memory cleared.');return;}
  await fs.mkdir(path.dirname(file),{recursive:true});try{await fs.writeFile(file,'# Project memory\n\nAdd confirmed constraints, build commands and decisions. Save to use in future turns.\n',{flag:'wx'});}catch(error){if(error.code!=='EEXIST')throw error;}
  await vscode.window.showTextDocument(await vscode.workspace.openTextDocument(vscode.Uri.file(file)),{preview:false});
 },
 async initProject(){
  return this.exclusive(async()=>{const existing=await this.snapshot('AGENTS.md');if(existing.exists)return this.openFile('AGENTS.md');return this.proposeChanges({summary:'Review project instructions before applying',operations:[{kind:'create',path:'AGENTS.md',content:'# Project instructions\n\n## Confirmed constraints\n\n<!-- Add project requirements reviewed by the maintainer. -->\n\n## Build and verification\n\n<!-- Add commands that have been verified for this project. -->\n'}]});});
 },
 async showContext(){await this.loadGuidance(await this.project());this.add('tool',JSON.stringify({permission:this.permission,instructions:this.projectInstructions.map(({path,scope,truncated})=>({path,scope,truncated})),memory:'Local to this project; /memory to review',constraints:this.task.constraints,metrics:this.metrics},null,2));}
};
