"""Bounded ComfyUI operations over the existing SSH connection. No shell commands."""
import base64
import fcntl
import hashlib
import json
import os
import socket
import ssl
import struct
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid


def run(request):
    base = request.get('baseUrl', 'http://127.0.0.1:8188').rstrip('/')
    parsed = urllib.parse.urlparse(base)
    if parsed.scheme not in ('http', 'https') or parsed.hostname not in ('127.0.0.1', 'localhost', '::1') or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ('', '/'):
        raise ValueError('ComfyUI must use a loopback HTTP(S) origin on the SSH host')

    def api(route, body=None, raw=False, headers=None):
        data = body if isinstance(body, bytes) else json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(base + route, data=data, headers=headers or {'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=20) as response:
            value = response.read(12_000_001)
        if len(value) > 12_000_000:
            raise ValueError('ComfyUI response exceeds size limit')
        return value if raw else json.loads(value)

    def job_status(job_id):
        try:
            job = api('/api/jobs/' + job_id)
        except urllib.error.HTTPError as error:
            if error.code == 404:
                error.close()
                return {'id': job_id, 'status': 'unknown', 'note': 'Job is absent from server history; never resubmit automatically.'}
            raise
        images = [dict(filename=x['filename'], subfolder=x.get('subfolder', ''), type=x.get('type', 'output')) for out in job.get('outputs', {}).values() for x in out.get('images', [])][:4]
        result = {k: job.get(k) for k in ('status', 'create_time', 'execution_start_time', 'execution_end_time')}
        result.update(id=job_id, images=images)
        if result['status'] == 'failed':
            messages = job.get('execution_status', {}).get('messages', [])
            result['error'] = next((str(x[1].get('exception_message', 'Generation failed'))[:1600] for x in reversed(messages) if x[0] == 'execution_error'), 'Generation failed')
        if result['status'] in ('running', 'in_progress'):
            node = current_node(job_id)
            result['phase'] = 'loading' if node in ('1', '2', '3', '4', '14', '15', '16') else 'generating' if node == '11' else 'decoding' if node in ('12', '13') else 'running'
        return result

    def current_node(client_id):
        # Read ComfyUI's reconnect snapshot, not other clients' progress or prompts.
        sock = None
        try:
            sock = socket.create_connection((parsed.hostname, parsed.port or (443 if parsed.scheme == 'https' else 80)), timeout=1)
            if parsed.scheme == 'https':
                sock = ssl.create_default_context().wrap_socket(sock, server_hostname=parsed.hostname)
            sock.settimeout(0.5)
            key = base64.b64encode(os.urandom(16)).decode()
            sock.sendall(('GET /ws?clientId=' + client_id + ' HTTP/1.1\r\nHost: ' + parsed.netloc + '\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: ' + key + '\r\nSec-WebSocket-Version: 13\r\n\r\n').encode())
            stream = sock.makefile('rb')
            if b'101' not in stream.readline():
                return None
            while stream.readline() not in (b'\r\n', b''):
                pass
            for _ in range(3):
                header = stream.read(2)
                if len(header) != 2:
                    break
                length = header[1] & 127
                if length == 126:
                    length = struct.unpack('!H', stream.read(2))[0]
                elif length == 127:
                    length = struct.unpack('!Q', stream.read(8))[0]
                if length > 65536 or header[1] & 128:
                    break
                payload = stream.read(length)
                if header[0] & 15 == 1:
                    event = json.loads(payload)
                    if event.get('type') == 'executing':
                        return str(event.get('data', {}).get('node'))
        except Exception:
            pass
        finally:
            if sock:
                sock.close()
        return None

    operation = request['operation']
    if operation == 'inspect':
        stats = api('/system_stats')
        info = api('/object_info')
        def choices(node, field):
            return info.get(node, {}).get('input', {}).get('required', {}).get(field, [[]])[0]
        version = stats.get('system', {}).get('comfyui_version', '')
        try:
            safe_jobs = tuple(int(v) for v in version.split('.')[:2]) >= (0, 41)
        except (ValueError, TypeError):
            safe_jobs = False
        queue = api('/queue')
        required = ['UNETLoader', 'CLIPLoader', 'VAELoader', 'Flux2Scheduler', 'EmptyFlux2LatentImage', 'CFGGuider', 'SamplerCustomAdvanced', 'SaveImage']
        return {'version': stats.get('system', {}).get('comfyui_version'), 'safeJobs': safe_jobs, 'devices': [{'name': d.get('name'), 'type': d.get('type')} for d in stats.get('devices', [])], 'running': len(queue.get('queue_running', [])), 'pending': len(queue.get('queue_pending', [])), 'models': [n for n in choices('UNETLoader', 'unet_name') if 'klein' in n.lower()], 'encoders': [n for n in choices('CLIPLoader', 'clip_name') if 'klein' in n.lower()], 'vaes': [n for n in choices('VAELoader', 'vae_name') if 'flux2' in n.lower()], 'textToImage': all(n in info for n in required), 'imageToImage': all(n in info for n in required + ['LoadImage', 'ImageScale', 'VAEEncode', 'ReferenceLatent'])}

    job_id = str(uuid.UUID(request['id']))
    if job_id != request['id']:
        raise ValueError('Invalid job ID')
    # Receipts contain identifiers only. Images and prompts stay in ComfyUI's
    # configured session storage; a lost receipt response must not duplicate work.
    directory = os.path.expanduser('~/.local/state/studio-agent/comfy-receipts')
    os.makedirs(directory, mode=0o700, exist_ok=True)
    receipt = os.path.join(directory, job_id + '.json')
    target = hashlib.sha256(base.encode()).hexdigest()
    if operation != 'submit':
        with open(receipt, encoding='utf-8') as handle:
            owner = json.load(handle)
        if owner.get('target') != target:
            raise ValueError('Job belongs to another ComfyUI endpoint')
        if operation == 'status':
            return job_status(job_id)
        if operation == 'cancel':
            # The per-job endpoint atomically checks the running ID. Never use
            # the global /interrupt endpoint or clear another client's queue.
            return api('/api/jobs/' + job_id + '/cancel', {})
        if operation == 'download':
            job = job_status(job_id)
            index = request.get('index', 0)
            if not isinstance(index, int) or index < 0 or index >= len(job.get('images', [])):
                raise ValueError('Image is not available for this job')
            data = api('/view?' + urllib.parse.urlencode(job['images'][index]), raw=True)
            return {'data': base64.b64encode(data).decode()}
        raise ValueError('Unknown ComfyUI operation')

    with open(receipt + '.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if os.path.exists(receipt):
            with open(receipt, encoding='utf-8') as handle:
                prior = json.load(handle)
            if prior.get('target') != target:
                raise ValueError('Job target mismatch')
            return job_status(job_id)
        spec = request['spec']
        width, height, count, steps = [spec[k] for k in ('width', 'height', 'count', 'steps')]
        if any(type(v) is not int for v in (width, height, count, steps)) or width % 16 or height % 16 or not (256 <= width <= 1536 and 256 <= height <= 1536 and width * height <= 1048576 and 1 <= count <= 4 and 1 <= steps <= 40):
            raise ValueError('Invalid image generation limits')
        if not isinstance(spec['prompt'], str) or not 1 <= len(spec['prompt'].strip()) <= 4000 or spec['workflow'] not in ('text-to-image', 'image-to-image'):
            raise ValueError('Invalid image request')
        info = api('/object_info')
        for key, node, field in [('model', 'UNETLoader', 'unet_name'), ('encoder', 'CLIPLoader', 'clip_name'), ('vae', 'VAELoader', 'vae_name')]:
            if spec[key] not in info[node]['input']['required'][field][0]:
                raise ValueError('Selected model file is unavailable')
        if 'klein' not in spec['model'].lower() or 'klein' not in spec['encoder'].lower() or 'flux2' not in spec['vae'].lower():
            raise ValueError('This template requires FLUX.2 Klein model files')
        def node(kind, **inputs):
            return {'class_type': kind, 'inputs': inputs}
        p = {
            '1': node('UNETLoader', unet_name=spec['model'], weight_dtype='default'),
            '2': node('CLIPLoader', clip_name=spec['encoder'], type='flux2', device='default'),
            '3': node('VAELoader', vae_name=spec['vae']),
            '4': node('CLIPTextEncode', clip=['2', 0], text=spec['prompt']),
            '5': node('ConditioningZeroOut', conditioning=['4', 0]),
            '6': node('CFGGuider', model=['1', 0], positive=['4', 0], negative=['5', 0], cfg=5.0 if 'base' in spec['model'].lower() else 1.0),
            '7': node('RandomNoise', noise_seed=int(spec['seed']) % (2**53)),
            '8': node('KSamplerSelect', sampler_name='euler'),
            '9': node('Flux2Scheduler', steps=steps, width=width, height=height),
            '10': node('EmptyFlux2LatentImage', width=width, height=height, batch_size=count),
            '11': node('SamplerCustomAdvanced', noise=['7', 0], guider=['6', 0], sampler=['8', 0], sigmas=['9', 0], latent_image=['10', 0]),
            '12': node('VAEDecode', samples=['11', 0], vae=['3', 0]),
            '13': node('SaveImage', images=['12', 0], filename_prefix='Studio/' + job_id)
        }
        if spec['workflow'] == 'image-to-image':
            data = base64.b64decode(request['image'], validate=True)
            if len(data) > 8_000_000 or not (data.startswith(b'\x89PNG\r\n\x1a\n') or data.startswith(b'\xff\xd8\xff')):
                raise ValueError('Expected a bounded PNG or JPEG reference')
            filename = 'studio-' + job_id + ('.png' if data.startswith(b'\x89PNG') else '.jpg')
            boundary = uuid.uuid4().hex
            body = ('--' + boundary + '\r\nContent-Disposition: form-data; name="image"; filename="' + filename + '"\r\nContent-Type: application/octet-stream\r\n\r\n').encode() + data + ('\r\n--' + boundary + '--\r\n').encode()
            uploaded = api('/upload/image', body, headers={'Content-Type': 'multipart/form-data; boundary=' + boundary})
            image_name = (uploaded.get('subfolder', '') + '/' + uploaded['name']).lstrip('/')
            p.update({'14': node('LoadImage', image=image_name), '15': node('ImageScale', image=['14', 0], upscale_method='lanczos', width=width, height=height, crop='center'), '16': node('VAEEncode', pixels=['15', 0], vae=['3', 0]), '17': node('ReferenceLatent', conditioning=['4', 0], latent=['16', 0]), '18': node('ReferenceLatent', conditioning=['5', 0], latent=['16', 0])})
            p['6']['inputs'].update(positive=['17', 0], negative=['18', 0])
        fd = os.open(receipt, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w') as handle:
            json.dump({'target': target, 'id': job_id, 'created': time.time()}, handle)
            handle.flush()
            os.fsync(handle.fileno())
        result = api('/prompt', {'prompt': p, 'prompt_id': job_id, 'client_id': job_id})
        if result.get('prompt_id') != job_id:
            # A legacy server can assign its own ID; retain the receipt, never retry.
            raise ValueError('Server must support client prompt IDs (ComfyUI 0.41+); submission may exist in its history')
        return {'id': job_id, 'status': 'queued'}


if __name__ == '__main__':
    try:
        print(json.dumps(run(json.load(sys.stdin))), flush=True)
    except urllib.error.HTTPError as error:
        print('ComfyUI HTTP ' + str(error.code) + ': ' + error.read(1800).decode(errors='replace'), file=sys.stderr)
        sys.exit(1)
    except Exception as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
