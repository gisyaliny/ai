'use strict';
// JSON Pointer selection and bounded pages; never silently truncate a record.
function page(text,{path,pointer='',offset=0,limit=10}={}){
 if(typeof pointer!=='string'||pointer.length>1000||(pointer&&!pointer.startsWith('/'))||!Number.isSafeInteger(offset)||offset<0||!Number.isInteger(limit)||limit<1||limit>50)throw Error('Use a JSON Pointer, nonnegative offset and limit 1–50.');
 let value=JSON.parse(text);
 for(const raw of pointer?pointer.slice(1).split('/'):[]){
  if(/~(?![01])/u.test(raw))throw Error('Invalid JSON Pointer escape.');
  const key=raw.replace(/~1/g,'/').replace(/~0/g,'~');
  if(!value||typeof value!=='object'||!Object.hasOwn(value,key))throw Error('JSON Pointer not found.');
  value=value[key];
 }
 const base={path,pointer};
 if(Array.isArray(value)){
  const items=[];let size=0;
  for(const item of value.slice(offset,offset+limit)){const bytes=Buffer.byteLength(JSON.stringify(item));if(size+bytes>18000){if(!items.length)return {...base,total:value.length,offset,items:[],nextOffset:offset,needsNarrowerPointer:true,message:'Record exceeds 18 KB. Select its fields with a narrower JSON Pointer.'};break;}items.push(item);size+=bytes;}
  return {...base,total:value.length,offset,items,nextOffset:offset+items.length<value.length?offset+items.length:null};
 }
 if(value&&typeof value==='object')return {...base,keys:Object.entries(value).slice(offset,offset+limit).map(([key,v])=>({key,type:Array.isArray(v)?'array':typeof v,count:v&&typeof v==='object'?Object.keys(v).length:undefined})),total:Object.keys(value).length,nextOffset:offset+limit<Object.keys(value).length?offset+limit:null};
 if(Buffer.byteLength(JSON.stringify(value))>18000)throw Error('Scalar exceeds 18 KB; use a bounded file read.');
 return {...base,value};
}
module.exports={page};
