'use strict';
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const ignored = new Set(['.git', '.ssh', '.aws', '.azure', '.gnupg', '.codex', '.openclaw', '.vscode', 'node_modules', '.venv', 'venv', '__pycache__', 'dist', 'build', '.next']);
function blocked(relative) {
  return relative.replace(/\\/g, '/').split('/').some(x => ignored.has(x.toLowerCase()) || /^\.env(?:\.|$)/i.test(x) || /^(?:id_rsa|id_ed25519|credentials(?:\.json)?|secrets?(?:\..*)?|\.npmrc|\.pypirc)$/i.test(x) || /\.(?:pem|key|p12|pfx)$/i.test(x));
}
function within(root, candidate) { const r = path.relative(root, candidate); return r === '' || (!r.startsWith('..' + path.sep) && r !== '..' && !path.isAbsolute(r)); }
async function resolvePath(root, relative, allowRoot = false) {
  if (typeof relative !== 'string' || relative.includes('\0') || relative.includes(':') || path.isAbsolute(relative) || /^[\\/]/.test(relative)) throw new Error('需要项目内的相对路径');
  if (relative.split(/[\\/]/).includes('..') || blocked(relative)) throw new Error('此路径不允许访问');
  const realRoot = await fs.realpath(root), target = path.resolve(realRoot, relative);
  if (!within(realRoot, target) || (!allowRoot && target === realRoot)) throw new Error('路径超出项目范围');
  let parent = target;
  while (true) {
    try {
      const real = await fs.realpath(parent);
      if (!within(realRoot, real) || blocked(path.relative(realRoot, real))) throw new Error('符号链接指向项目外部或受限目录');
      break;
    }
    catch (error) { if (error.code !== 'ENOENT') throw error; parent = path.dirname(parent); }
  }
  return target;
}
function hash(text) { return crypto.createHash('sha256').update(text).digest('hex'); }
function editText(original, oldText, newText, exists) {
  if (typeof oldText !== 'string' || typeof newText !== 'string') throw new Error('编辑参数必须为文本');
  if (newText.length > 120_000) throw new Error('修改过大，请拆分文件');
  if (!exists) { if (oldText !== '') throw new Error('创建文件时 old_text 必须为空'); return newText; }
  if (!oldText) throw new Error('已有文件必须提供非空且唯一的 old_text');
  const pos = original.indexOf(oldText);
  if (pos < 0 || original.indexOf(oldText, pos + 1) >= 0) throw new Error('old_text 未找到或不唯一，请重新读取文件');
  return original.slice(0, pos) + newText + original.slice(pos + oldText.length);
}
async function readText(root, relative, {maxBytes=160_000}={}) {
  const target = await resolvePath(root, relative);
  const stat = await fs.stat(target);
  if (!stat.isFile() || stat.size > maxBytes) throw new Error('只支持不超过 160 KB 的文本文件');
  const text = await fs.readFile(target, 'utf8');
  if (text.includes('\0')) throw new Error('不支持二进制文件');
  return text;
}
async function listFiles(root, relative = '.', limit = 400) {
  const start = await resolvePath(root, relative, true), result = [], queue = [start];
  while (queue.length && result.length < limit) {
    const dir = queue.shift();
    const entries = await fs.readdir(dir, { withFileTypes: true });
    for (const entry of entries.sort((a,b) => a.name.localeCompare(b.name))) {
      const full = path.join(dir, entry.name), rel = path.relative(await fs.realpath(root), full).split(path.sep).join('/');
      if (blocked(rel) || entry.isSymbolicLink()) continue;
      if (entry.isDirectory()) queue.push(full);
      else if (entry.isFile()) result.push(rel);
      if (result.length >= limit) break;
    }
    if (queue.length > 1000) break;
  }
  return { files: result, truncated: result.length >= limit || queue.length > 0 };
}
module.exports = { blocked, within, resolvePath, hash, editText, readText, listFiles };
