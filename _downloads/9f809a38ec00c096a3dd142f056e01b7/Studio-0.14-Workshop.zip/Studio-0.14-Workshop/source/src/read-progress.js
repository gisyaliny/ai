'use strict';
const {hash}=require('./files');
class ReadProgress{
 constructor(){this.seen=new Set();this.ranges=new Map();this.stale=0;}
 observe(name,args,result){
  if(!['local_read_file','local_read_json','local_search','local_list_files'].includes(name))return false;
  const fingerprint=hash(JSON.stringify([name,args.path||args.directory,args.pointer,result.documentVersion??result.revision,result.content??result.items??result.matches??result.files??result]));
  let repeated=this.seen.has(fingerprint);this.seen.add(fingerprint);
  if(name==='local_read_file'&&Number.isInteger(result.startLine)&&Number.isInteger(result.endLine)){
   const key=args.path+':'+(result.documentVersion??result.revision??''),previous=this.ranges.get(key)||[];
   // Covered ranges do not become new evidence by changing argument boundaries.
   if(previous.some(([start,end])=>start<=result.startLine&&end>=result.endLine))repeated=true;
   previous.push([result.startLine,result.endLine]);this.ranges.set(key,previous);
  }
  if(name==='local_read_json'&&Array.isArray(result.items)&&result.items.length){
   const key='json:'+args.path+':'+(args.pointer||'')+':'+(result.revision||''),previous=this.ranges.get(key)||[],start=result.offset,end=start+result.items.length-1;
   if(previous.some(([a,b])=>a<=start&&b>=end))repeated=true;
   previous.push([start,end]);this.ranges.set(key,previous);
  }
  this.stale=repeated?this.stale+1:0;return name==='local_read_json'?repeated:this.stale>=3;
 }
}
module.exports={ReadProgress};
