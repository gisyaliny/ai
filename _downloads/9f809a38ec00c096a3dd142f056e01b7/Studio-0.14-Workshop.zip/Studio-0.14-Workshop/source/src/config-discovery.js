'use strict';
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const toml=require('smol-toml');
const {hash}=require('./files');
async function readConfig(file){const stat=await fs.stat(file);if(!stat.isFile()||stat.size>4_000_000)throw Error('Configuration too large.');const text=(await fs.readFile(file,'utf8')).replace(/^\uFEFF/,'');return file.endsWith('.toml')?toml.parse(text):JSON.parse(text);}
function envExpand(value,env){if(typeof value!=='string')return value;return value.replace(/\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}/g,(_,name,fallback)=>{const found=env[name]??fallback;if(found===undefined)throw Error('Missing environment variable: '+name);return found;});}
async function discover(root,{home=os.homedir(),codexHome=process.env.CODEX_HOME||path.join(home,'.codex')}={}){
 const entries=[],warnings=[];
 const claudePolicies=[];
 for(const f of [path.join(home,'.claude/settings.json'),...(root?[path.join(root,'.claude/settings.json'),path.join(root,'.claude/settings.local.json')]:[])])try{claudePolicies.push(await readConfig(f));}catch(error){if(error.code!=='ENOENT')warnings.push('Claude Code settings could not be parsed.');}
 const add=(source,file,name,raw,scope,cwd)=>{
  if(!raw||typeof raw!=='object')return;
  const transport=raw.command?'stdio':raw.type||'http';let enabled=raw.enabled!==false&&raw.disabled!==true;
  if(source==='Claude Code'&&scope==='project'&&claudePolicies.some(p=>p.enableAllProjectMcpServers===false||p.disabledMcpjsonServers?.includes(name)||(Array.isArray(p.enabledMcpjsonServers)&&!p.enabledMcpjsonServers.includes(name))))enabled=false;
  const reason=!['stdio','http','streamable-http'].includes(transport)?'Unsupported transport':undefined;
  const key=hash(file+'\n'+scope+'\n'+name).slice(0,24);
  entries.push({key,id:'i_'+key.slice(0,20),name,source,file,scope,cwd,transport,enabled,reason,raw,fingerprint:hash(JSON.stringify({raw,cwd}))});
 };
 for(const [label,file,scope] of [['Codex',path.join(codexHome,'config.toml'),'user'],...(root?[['Codex',path.join(root,'.codex/config.toml'),'project']]:[]),['Claude Code',path.join(home,'.claude.json'),'user'],...(root?[['Claude Code',path.join(root,'.mcp.json'),'project']]:[])]){
  try{
   const config=await readConfig(file);for(const [name,raw] of Object.entries(config.mcp_servers||config.mcpServers||{}))add(label,file,name,raw,scope,scope==='project'?root:home);
   if(label==='Claude Code'&&scope==='user'&&root){for(const [project,value] of Object.entries(config.projects||{})){if(path.resolve(project)!==path.resolve(root))continue;for(const [name,raw] of Object.entries(value.mcpServers||{}))add(label,file,name,raw,'local',root);}}
  }catch(error){if(error.code!=='ENOENT')warnings.push(label+' '+scope+': configuration could not be parsed.');}
 }
 return {entries,warnings};
}
function resolve(entry,allowedTools=[],env=process.env){
 if(!entry.enabled||entry.reason)throw Error(entry.reason||'Server is disabled at source.');
 const raw=entry.raw,c={id:entry.id,allowedTools,sourceLabel:entry.source,sourceKey:entry.key,sourceFingerprint:entry.fingerprint};
 if(entry.transport==='stdio'){
  if(typeof raw.command!=='string'||(raw.args!==undefined&&(!Array.isArray(raw.args)||raw.args.some(x=>typeof x!=='string'))))throw Error('Invalid MCP command or arguments.');
  c.transport='stdio';c.command=envExpand(raw.command,env);c.args=(raw.args||[]).map(x=>envExpand(x,env));c.cwd=raw.cwd?envExpand(raw.cwd,env):entry.cwd;
  if(!path.isAbsolute(c.cwd))c.cwd=path.resolve(entry.cwd,c.cwd);
  c.env={};for(const name of raw.env_vars||[]){if(typeof name!=='string'||env[name]===undefined)throw Error('Missing environment variable: '+String(name));c.env[name]=env[name];}
  for(const [name,value] of Object.entries(raw.env||{})){if(typeof value!=='string')throw Error('MCP environment values must be strings.');c.env[name]=envExpand(value,env);}
 }else{
  c.url=envExpand(raw.url,env);c.headers={};if(raw.oauth)c.oauth={clientId:raw.oauth.clientId||raw.oauth.client_id,clientMetadataUrl:raw.oauth.clientMetadataUrl||raw.oauth.client_metadata_url,callbackPort:raw.oauth.callbackPort||raw.oauth.callback_port};
  for(const [key,value] of Object.entries(raw.http_headers||raw.headers||{})){if(typeof value!=='string')throw Error('Invalid MCP header.');c.headers[key]=envExpand(value,env);}
  for(const [key,name] of Object.entries(raw.env_http_headers||{})){if(!env[name])throw Error('Required MCP header environment variable is unavailable.');c.headers[key]=env[name];}
  if(raw.bearer_token_env_var){if(!env[raw.bearer_token_env_var])throw Error('Required MCP token environment variable is unavailable.');c.headers.Authorization='Bearer '+env[raw.bearer_token_env_var];}
 }
 if(Array.isArray(raw.enabled_tools))c.allowedTools=c.allowedTools.filter(x=>raw.enabled_tools.includes(x));
 if(Array.isArray(raw.disabled_tools))c.allowedTools=c.allowedTools.filter(x=>!raw.disabled_tools.includes(x));
 return c;
}
function safeEntry(entry){return {key:entry.key,name:entry.name,source:entry.source,scope:entry.scope,transport:entry.transport,enabled:entry.enabled,reason:entry.reason,program:entry.raw.command?path.basename(entry.raw.command):undefined};}
module.exports={discover,resolve,safeEntry,readConfig,envExpand};
