'use strict';
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const bridge = fs.readFileSync(path.join(__dirname, 'bridge.py'), 'utf8');
const comfyBridge = fs.readFileSync(path.join(__dirname, 'comfy-bridge.py'), 'utf8');
const quote = value => "'" + String(value).replace(/'/g, "'\\''") + "'";

class SSEReader {
  constructor(onEvent) { this.buffer = ''; this.onEvent = onEvent; }
  push(chunk) {
    this.buffer += chunk;
    if (this.buffer.length > 2_000_000) throw new Error('Server event exceeded size limit');
    let match;
    while ((match = /\r?\n\r?\n/.exec(this.buffer))) {
      const block = this.buffer.slice(0, match.index);
      this.buffer = this.buffer.slice(match.index + match[0].length);
      const data = block.split(/\r?\n/).filter(x => x.startsWith('data:')).map(x => x.slice(5).trimStart()).join('\n');
      if (data) this.onEvent(data);
    }
  }
}

function sshRequest(options, request, signal, onData) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(new Error('已停止'));
    if (!/^[a-zA-Z0-9_][a-zA-Z0-9_.@:\-]*$/.test(options.host || '')) return reject(new Error('无效的 SSH 主机名'));
    const args = ['-T', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes', '-o', 'ConnectTimeout=12', '-o', 'ServerAliveInterval=20', '-o', 'ServerAliveCountMax=3'];
    if (options.identity) args.push('-o', 'IdentitiesOnly=yes', '-i', options.identity.replace(/^~(?=[/\\])/, os.homedir()));
    const encoded = Buffer.from(request.namespace==='comfy'?comfyBridge:bridge).toString('base64');
    const code = `import base64;exec(compile(base64.b64decode('${encoded}'),'<macstudio-bridge>','exec'))`;
    args.push(options.host, `${quote(options.python || '/usr/bin/python3')} -u -c ${quote(code)}`);
    const child = spawn(options.executable || 'ssh', args, { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    let stderr = '', output = '', failure, timer;
    const abort = () => { failure = new Error('已停止；远程已开始的工具操作可能仍在收尾。'); child.kill(); };
    signal?.addEventListener('abort', abort, { once: true });
    timer = setTimeout(() => { failure = new Error('连接或推理超时，请检查 VPN 与 Mac 服务。'); child.kill(); }, ((request.timeout || 600) + 15) * 1000);
    child.stdout.setEncoding('utf8'); child.stderr.setEncoding('utf8');
    child.stdout.on('data', data => {
      try {
        if (onData) onData(data);
        else { output += data; if (output.length > (request.namespace==='comfy'?17_000_000:2_000_000)) throw new Error('Response too large'); }
      } catch (error) { failure = error; child.kill(); }
    });
    child.stderr.on('data', data => { stderr = (stderr + data).slice(-4096); });
    child.stdin.on('error', () => {});
    child.on('error', error => { failure = error; });
    child.on('close', code => {
      clearTimeout(timer); signal?.removeEventListener('abort', abort);
      if (failure) reject(failure);
      else if (code !== 0) reject(new Error(stderr.trim() || `SSH exited (${code})`));
      else resolve(output);
    });
    child.stdin.end(JSON.stringify({ ...request, expectedModel: options.resolvedModel, direct: options.direct, config: options.config || '~/.openclaw/openclaw.json' }));
  });
}

async function completion(options, payload, signal, onText = () => {}, onMeta = () => {}) {
  const message = { role: 'assistant', content: '' }, calls = new Map();
  let done = false, finish;
  const reader = new SSEReader(data => {
    if (data === '[DONE]') { done = true; return; }
    const event = JSON.parse(data);
    if (event.error) throw new Error(event.error.message || 'Remote API error');
    if (event.model || event.usage) onMeta({model:event.model,usage:event.usage});
    const choice = event.choices?.[0];
    if (!choice) return;
    if (choice.finish_reason) finish = choice.finish_reason;
    const delta = choice.delta || {};
    if(delta.reasoning_content||delta.reasoning)onMeta({thinking:true});
    if (delta.content) { message.content += delta.content; onText(delta.content); }
    if (message.content.length > 500_000) throw new Error('Reply exceeded size limit');
    for (const part of delta.tool_calls || []) {
      const index = part.index ?? 0;
      const call = calls.get(index) || { id: '', type: 'function', function: { name: '', arguments: '' } };
      if (part.id) call.id = part.id;
      if (part.function?.name) call.function.name += part.function.name;
      if (part.function?.arguments) call.function.arguments += part.function.arguments;
      if (call.function.arguments.length > 200_000) throw new Error('Tool arguments exceeded size limit');
      calls.set(index, call);
    }
  });
  await sshRequest(options, { mode: options.mode, timeout: options.timeout, payload: { ...payload, ...(options.includeUsage ? {stream_options:{include_usage:true}} : {}), stream: true } }, signal, chunk => reader.push(chunk));
  if (!done) throw new Error('连接中断：没有收到完整响应，未执行未完成的工具调用。');
  if (finish === 'length') {const error=new Error('输出达到长度上限；请缩小任务或提高输出 token 设置。');error.code='OUTPUT_LIMIT';throw error;}
  if (calls.size) {
    message.tool_calls = [...calls.values()];
    for (const call of message.tool_calls) if (!call.id || !call.function.name) throw new Error('Incomplete tool call');
    if(new Set(message.tool_calls.map(x=>x.id)).size!==message.tool_calls.length)throw new Error('Duplicate tool call IDs');
  }
  if (!message.content && !calls.size) throw new Error('模型返回空内容');
  return message;
}

module.exports = { SSEReader, sshRequest, completion };
