'use strict';
const {hash}=require('./files');
const EVENTS=['before-tool','after-apply','after-verification','task-end'];
function definitions(rows){if(!Array.isArray(rows)||rows.length>12)throw Error('Configure at most 12 hooks.');const ids=new Set();return rows.map(r=>{if(!r||!/^[-\w]{1,40}$/.test(r.id)||ids.has(r.id)||!EVENTS.includes(r.event)||typeof r.command!=='string'||!r.command.trim()||r.command.length>4000||!Number.isInteger(r.timeoutSeconds??30)||(r.timeoutSeconds??30)<1||(r.timeoutSeconds??30)>60)throw Error('Invalid hook definition');ids.add(r.id);return {id:r.id,event:r.event,command:r.command,timeoutSeconds:r.timeoutSeconds??30,fingerprint:hash(JSON.stringify([r.id,r.event,r.command,r.timeoutSeconds??30]))};});}
module.exports={EVENTS,definitions};
