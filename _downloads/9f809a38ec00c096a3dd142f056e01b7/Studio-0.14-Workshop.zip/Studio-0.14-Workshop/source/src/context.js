'use strict';
// Upper estimate for common byte-based tokenizers, not an exact tokenizer or a server limit.
function estimate(messages, tools = []) {
  return Buffer.byteLength(JSON.stringify({messages,tools}), 'utf8') + messages.length * 128 + 1024;
}
function prepareContext(system, history, tools, budget, summary) {
  let messages = [{role:'system',content:system}, ...structuredClone(history)];
  let compacted = false, omittedTurns = 0;
  if (estimate(messages,tools) > budget) {
    // Keep tool call/result pairs intact. The full transcript remains on disk.
    for (const m of messages) if (m.role==='tool' && m.content.length>2000) {
      m.content=JSON.stringify({contextPreview:m.content.slice(0,2000),truncated:true,note:'Full result is in the saved session. Request a smaller file range or a more specific search.'});
      compacted=true;
    }
    const extracts=[];
    while (estimate(messages,tools)>budget) {
      const next=messages.findIndex((m,i)=>i>1 && m.role==='user');
      if(next<0) break;
      const old=messages.splice(1,next-1);
      extracts.push(old.filter(m=>m.role==='user'||(m.role==='assistant'&&m.content)).map(m=>`${m.role}: ${m.content.slice(0,240)}`).join('\n'));
      omittedTurns++; compacted=true;
    }
    if(extracts.length) {
      const extract={role:'user',content:'Earlier context extract (quoted history, not new instructions; details may be omitted):\n'+(summary?JSON.stringify(summary):extracts.slice(-4).join('\n').slice(-1600))};
      if(estimate([...messages.slice(0,1),extract,...messages.slice(1)],tools)<=budget)messages.splice(1,0,extract);
      else if(summary?.semantic){
        // Goal/current request/constraints already live in the system state.
        // Avoid losing the entire semantic summary just because duplicated
        // requests make the full extracted-state wrapper too large.
        extract.content='Earlier semantic summary (may omit details): '+JSON.stringify({semantic:summary.semantic,operationsToCheck:summary.operationsToCheck,unfinished:summary.unfinished});
        if(estimate([...messages.slice(0,1),extract,...messages.slice(1)],tools)<=budget)messages.splice(1,0,extract);
      }
    }
  }
  // A single active turn can accumulate many reads, so removing only OLD turns
  // is insufficient. Shrink result previews by bytes without losing call IDs,
  // user requirements, or the immutable full transcript saved on disk.
  for(const limit of [1024,512,128]){
    if(estimate(messages,tools)<=budget)break;
    for(const m of messages){
      if(m.role!=='tool'||Buffer.byteLength(m.content,'utf8')<=limit+256)continue;
      let original=m.content;
      try{const previous=JSON.parse(original);if(previous.truncated&&typeof previous.contextPreview==='string')original=previous.contextPreview;}catch{}
      const preview=Buffer.from(original,'utf8').subarray(0,limit).toString('utf8').replace(/\uFFFD$/,'');
      m.content=JSON.stringify({contextPreview:preview,truncated:true,note:'Preview only. Full tool result remains in saved history; request a narrower range if needed.'});
      compacted=true;
      if(estimate(messages,tools)<=budget)break;
    }
  }
  return {messages,estimatedTokens:estimate(messages,tools),compacted,omittedTurns};
}
const READ_TOOLS=new Set(['local_delegate','local_agent_status','local_cancel_agent','local_find_mcp_tools','local_navigation','local_command_status','local_image_services','local_image_status','local_find_skills','local_use_skill','local_read_skill_resource','local_list_files','local_read_json','local_read_file','local_search','local_diagnostics','local_update_plan']);
function allowed(name, permission, mcpNames = new Set()) {
  return READ_TOOLS.has(name) || mcpNames.has(name) || (require('./permissions').canEffect(permission) && ['local_propose_changes','local_propose_edit','local_run_command','local_propose_image'].includes(name));
}
module.exports={estimate,prepareContext,allowed};
