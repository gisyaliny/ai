'use strict';
const http=require('node:http');
const crypto=require('node:crypto');
function safeUrl(value){const url=new URL(value);if(url.username||url.password||!(url.protocol==='https:'||url.protocol==='http:'&&['127.0.0.1','localhost','[::1]'].includes(url.hostname)))throw Error('OAuth requires HTTPS or loopback HTTP without URL credentials.');return url;}
class OAuthProvider{
 constructor(config,secrets,{openUrl,signal,timeoutMs=120000}={}){
  this.config=config;this.secrets=secrets;this.openUrl=openUrl;this.signal=signal;this.timeoutMs=timeoutMs;this.interactive=true;this.requested=false;this.saved={};this.queue=Promise.resolve();
  this.key='studio.oauth.'+crypto.createHash('sha256').update(JSON.stringify([config.id,config.url,config.oauth?.clientId,config.oauth?.clientMetadataUrl])).digest('hex');
 }
 async init(){
  const raw=await this.secrets.get(this.key);if(raw)try{this.saved=JSON.parse(raw);if(!this.saved||typeof this.saved!=='object'||Array.isArray(this.saved))throw Error();}catch{throw Error('Stored OAuth credentials are invalid; sign out and reconnect.');}
  if(this.signal?.aborted)throw Error('OAuth sign-in cancelled');
  const port=this.config.oauth?.callbackPort??this.saved.callbackPort??0;if(!Number.isInteger(port)||port<0||port>65535||port>0&&port<1024)throw Error('Use callback port 0 or 1024–65535.');
  this.code=new Promise((resolve,reject)=>{this.resolveCode=resolve;this.rejectCode=reject;});this.code.catch(()=>{});
  this.server=http.createServer((req,res)=>this.callback(req,res));
  await new Promise((resolve,reject)=>{this.server.once('error',reject);this.server.listen(port,'127.0.0.1',resolve);});
  this.redirect='http://127.0.0.1:'+this.server.address().port+'/callback';this.saved.callbackPort=this.server.address().port;
  this.abort=()=>this.close(Error('OAuth sign-in cancelled'));this.signal?.addEventListener('abort',this.abort,{once:true});if(this.signal?.aborted){this.abort();throw Error('OAuth sign-in cancelled');}
  this.timer=setTimeout(()=>this.close(Error('OAuth sign-in timed out')),this.timeoutMs);this.timer.unref();return this;
 }
 get redirectUrl(){return this.redirect;}
 get clientMetadataUrl(){return this.config.oauth?.clientMetadataUrl;}
 get clientMetadata(){return {client_name:'Studio VS Code',redirect_uris:[this.redirect],grant_types:['authorization_code','refresh_token'],response_types:['code'],token_endpoint_auth_method:'none'};}
 state(){this.nonce=crypto.randomBytes(32).toString('base64url');return this.nonce;}
 clientInformation(){return this.saved.client|| (this.config.oauth?.clientId?{client_id:this.config.oauth.clientId,...(this.config.oauth.issuer?{issuer:this.config.oauth.issuer}:{})}:undefined);}
 async saveClientInformation(client){this.saved.client=client;await this.persist();}
 tokens(){return this.saved.tokens;}
 async saveTokens(tokens){this.saved.tokens=tokens;this.saved.expiresAt=Number.isFinite(tokens.expires_in)?Date.now()+tokens.expires_in*1000:undefined;await this.persist();}
 expired(){return !!this.saved.tokens&&Number.isFinite(this.saved.expiresAt)&&Date.now()>=this.saved.expiresAt-30000;}
 saveCodeVerifier(value){this.verifier=value;}
 codeVerifier(){if(!this.verifier)throw Error('OAuth verifier is unavailable; sign in again.');return this.verifier;}
 discoveryState(){return this.discovery;}
 saveDiscoveryState(value){this.discovery=value;}
 async redirectToAuthorization(value){
  if(!this.interactive||!this.openUrl)throw Error('Sign in again from Tools before invoking this server.');
  const url=safeUrl(value);this.requested=true;
  if(await this.openUrl(url)===false)throw Error('OAuth sign-in was cancelled.');
 }
 callback(req,res){
  const reject=()=>{res.writeHead(400,{'Content-Type':'text/plain','Cache-Control':'no-store'});res.end('Invalid authorization response.');};
  try{
   if(req.method!=='GET'||req.url.length>8192||req.headers.host!==new URL(this.redirect).host)return reject();
   const url=new URL(req.url,this.redirect),state=url.searchParams.get('state')||'';
   if(url.pathname!=='/callback'||url.searchParams.getAll('state').length!==1||!this.nonce||Buffer.byteLength(state)!==Buffer.byteLength(this.nonce)||!crypto.timingSafeEqual(Buffer.from(state),Buffer.from(this.nonce)))return reject();
   const issuer=url.searchParams.get('iss'),expected=this.discovery?.authorizationServerUrl;
   if((issuer&&(!expected||issuer!==String(expected)))||this.discovery?.metadata?.authorization_response_iss_parameter_supported&&!issuer)return reject();
   if(url.searchParams.has('error')){res.writeHead(200,{'Content-Type':'text/plain','Cache-Control':'no-store'});res.end('Authorization declined. Return to VS Code.');this.close(Error('OAuth authorization declined'));return;}
   const code=url.searchParams.get('code');if(!code||code.length>4096||url.searchParams.getAll('code').length!==1)return reject();
   res.writeHead(200,{'Content-Type':'text/plain','Cache-Control':'no-store'});res.end('Authorization received. Return to VS Code.');this.resolveCode(code);this.stopListener();
  }catch{reject();}
 }
 async waitForCode(){return this.code;}
 async invalidateCredentials(scope){
  if(scope==='all'||scope==='client')delete this.saved.client;
  if(scope==='all'||scope==='tokens'){delete this.saved.tokens;delete this.saved.expiresAt;}
  if(scope==='all'||scope==='verifier')this.verifier=undefined;
  if(scope==='all'||scope==='discovery')this.discovery=undefined;
  await this.persist();
 }
 persist(){this.queue=this.queue.catch(()=>{}).then(()=>this.secrets.store(this.key,JSON.stringify(this.saved)));return this.queue;}
 stopListener(){clearTimeout(this.timer);this.signal?.removeEventListener('abort',this.abort);this.server?.close();this.server?.closeIdleConnections();}
 close(error=Error('OAuth sign-in closed')){this.stopListener();this.rejectCode?.(error);this.verifier=undefined;this.interactive=false;}
 async signOut(){this.close();await this.queue.catch(()=>{});this.saved={};await this.secrets.delete(this.key);}
}
module.exports={OAuthProvider,safeUrl};
