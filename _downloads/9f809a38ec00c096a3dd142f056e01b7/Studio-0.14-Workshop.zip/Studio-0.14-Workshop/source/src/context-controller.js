'use strict';
const vscode=require('vscode');
const ui=require('./host-ui');
const workflow=require('./workflow');
const project=require('./project');
const {resolveThinking}=require('./thinking');
const {sshRequest}=require('./transport');
const {summarize}=require('./semantic');
const {estimate}=require('./context');
module.exports={
  async measureContext(messages,tools,options,parameters={},imageReserve=0,signal=this.controller?.signal){
    const fallback={count:estimate(messages,tools)+imageReserve,source:'保守估算（非精确 tokenizer）'};
    if(!vscode.workspace.getConfiguration('macstudio').get('useServerTokenizer',true)||options.mode!=='direct'||imageReserve)return fallback;
    const key=JSON.stringify([options.host,options.direct?.baseUrl,options.resolvedModel]);
    if(this.tokenizerUnavailable?.key===key&&Date.now()<this.tokenizerUnavailable.until)return fallback;
    try{
      const answer=JSON.parse(await sshRequest(options,{mode:options.mode,operation:'count_tokens',payload:{messages,tools,...parameters},timeout:35},signal));
      if(Number.isSafeInteger(answer.tokens)&&answer.tokens>0){this.tokenizerUnavailable=undefined;return {count:answer.tokens,source:'服务端 tokenizer'};}
    }catch(error){if(signal?.aborted)throw error;}
    // Unsupported endpoints must not add a failing SSH probe to every tool round.
    this.tokenizerUnavailable={key,until:Date.now()+60000};return fallback;
  },
  async saveConstraints(text){
    await this.ready;this.trusted();if(this.busy)throw new Error('请等待当前生成');
    if(typeof text!=='string')throw new Error('无效约束');
    const before=JSON.stringify(this.task.constraints||[]);
    workflow.setConstraints(this.task,text.split('\n'));
    if(before!==JSON.stringify(this.task.constraints)&&this.task.steps.length){this.task.approved=false;if(this.requiresPlanApproval())this.task.status='awaiting_plan';else if(this.task.status==='awaiting_plan')this.task.status='idle';}
    await this.checkpoint();this.publish();
  },
  async suggestPaths(query,requestId){
    await this.ready;this.trusted();
    if(typeof query!=='string'||query.length>500||!Number.isInteger(requestId))return;
    this.pathRequest=requestId;
    const root=await this.project();
    const items=[],report={};let limited=false;
    // Read names only; nested prefixes search beyond the root traversal cap.
    const normalized=query.replace(/\\/g,'/'),slash=normalized.lastIndexOf('/');
    const directory=slash>=0?normalized.slice(0,slash)||'.':'.';
    try{
      for await(const relative of project.walk(root,directory,undefined,report)){
        if(this.pathRequest!==requestId)return;
        if(/["\r\n]/.test(relative)||!relative.toLowerCase().includes(normalized.toLowerCase()))continue;
        items.push(relative);if(items.length===21){limited=true;break;}
      }
    }catch{ /* Invalid or restricted prefixes yield no suggestions. */ }
    if(this.pathRequest===requestId)this.view?.webview.postMessage({type:'pathSuggestions',requestId,query,items:items.slice(0,20),truncated:limited||report.truncated});
  },
  async compact(mode='semantic'){
    if(!['semantic','extract'].includes(mode))throw new Error('使用 /compact 或 /compact extract');
    return this.exclusive(()=>this.compactInternal({mode}));
  },
  async compactInternal({mode='semantic',options,parameters,through=require('./compaction-policy').frontier(this.history,this.compaction?.through||0),signal=this.controller?.signal}={}){
    if(!through){this.add('tool','暂无旧轮次可压缩；最近一轮保留原文。');return;}
    let semantic,calls=0;
    if(mode==='semantic'){
      options=options||await this.connectionOptions();
      if(options.mode==='openclaw')throw new Error('语义压缩需使用 Mac API 或 Qwen 模式；网关模式可用 /compact extract');
      if(!options.resolvedModel){const resolved=JSON.parse(await sshRequest(options,{mode:options.mode,operation:'resolve',timeout:30},signal));options.resolvedModel=resolved.model;}
      const config=vscode.workspace.getConfiguration('macstudio');
      const caps=this.thinkingCapsModel===options.resolvedModel?this.thinkingCaps:{};
      const summaryThinking=resolveThinking('default',config.get('thinkingProtocol','qwen'),caps,options.mode);
      const level=summaryThinking.supported.includes('off')?'off':summaryThinking.supported.includes('low')?'low':'default';
      // Auxiliary JSON summarization must not spend its small output allowance on
      // the main task's reasoning level. This does not change the user's setting.
      parameters=resolveThinking(level,summaryThinking.protocol,caps,options.mode).parameters;
      const previous=this.compaction?.method==='semantic'?this.compaction:undefined;
      if(previous?.through===through){this.add('tool','摘要已覆盖所有旧轮次；最近一轮保留原文。');return;}
      try{
        const result=await summarize({history:this.history,from:previous?.through||0,through,previous:previous?.summary.semantic,task:this.task,options,parameters,capacity:config.get('contextTokens',32768),outputTokens:Math.min(config.get('maxOutputTokens',4096),2048),signal:signal,
          onProgress:p=>{this.metrics.compactionProgress=ui.translate(`语义压缩 ${p.batch}/8 · ${p.processed}/${p.total} 片段`);this.publish();},
          onUsage:usage=>{const total=usage.total_tokens??((usage.prompt_tokens||0)+(usage.completion_tokens||0));this.metrics.summaryTokens=(this.metrics.summaryTokens||0)+total;this.metrics.totalTokens=(this.metrics.totalTokens||0)+total;}});
        semantic=result.summary;calls=result.calls;
      }finally{delete this.metrics.compactionProgress;this.publish();}
    }
    if(signal?.aborted)throw new Error('摘要已取消，原记录保留');
    const summary=workflow.taskSummary(this.task,this.history,this.journal,this.edits);
    if(semantic){summary.semantic=semantic;summary.note='Model-generated summary; may omit details. Confirm candidate constraints explicitly. Recorded tool/test evidence remains authoritative.';}
    this.compaction={through,summary,method:mode,calls,createdAt:new Date().toISOString()};
    this.add('tool',mode==='semantic'?'语义摘要已保存；固定约束逐字保留，近期消息与完整历史仍保留。':'已保存提取式摘要；未调用模型，可能遗漏细节。');await this.checkpoint();
  }
};
