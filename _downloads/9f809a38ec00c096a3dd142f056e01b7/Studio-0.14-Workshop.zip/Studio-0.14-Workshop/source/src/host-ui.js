'use strict';
const vscode=require('vscode');
const {locale,t}=require('../media/i18n');
const en=require('./host-en.json');
function translate(text){
 if(typeof text!=='string')return text;if(locale(vscode.env?.language)==='zh-CN')return t(text,[],vscode.env.language);
 if(en[text])return en[text];
 for(const key of Object.keys(en))if((key.endsWith('：')||key.endsWith(' '))&&text.startsWith(key))return en[key]+text.slice(key.length);
 const command=/^允许在本机运行此命令？\n目录：([^]*?)\n\n([^]*)$/.exec(text);
 if(command)return `Run this command on the client?\nDirectory: ${command[1]}\n\n${command[2]}`;
 const verification=/^验证 ([^\n]+)\n([^]*)$/.exec(text);if(verification)return `Verification ${verification[1]}\n${verification[2]}`;
 const progress=/^语义压缩 (\d+)\/8 · (\d+)\/(\d+) 片段$/.exec(text);if(progress)return `Summarizing ${progress[1]}/8 · ${progress[2]}/${progress[3]} excerpts`;
 return text;
}
function options(value){if(!value||typeof value!=='object')return value;const copy={...value};for(const key of ['title','prompt','placeHolder','detail','label','description'])if(typeof copy[key]==='string')copy[key]=translate(copy[key]);return copy;}
const ui={translate};
for(const method of ['showInputBox','showWarningMessage','showInformationMessage','showErrorMessage'])ui[method]=async(...args)=>{
 const translated=args.map(x=>typeof x==='string'?translate(x):options(x));
 const answer=await vscode.window[method](...translated);
 // Preserve original action identity after localizing the approval labels.
 const index=translated.findIndex((x,i)=>i>0&&typeof x==='string'&&x===answer);return index>=0?args[index]:answer;
};
ui.showQuickPick=async(items,config)=>{const original=await items,translated=original.map(x=>typeof x==='string'?x:options(x));const answer=await vscode.window.showQuickPick(translated,options(config));const restore=x=>original[translated.indexOf(x)]??x;return Array.isArray(answer)?answer.map(restore):restore(answer);};
module.exports=ui;
