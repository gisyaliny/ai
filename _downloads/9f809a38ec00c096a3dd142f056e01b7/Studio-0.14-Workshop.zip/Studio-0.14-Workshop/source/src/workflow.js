'use strict';
const crypto=require('node:crypto');
const files=require('./files');
function newTask(goal='') {return {id:crypto.randomUUID(),goal:goal.slice(0,4000),constraints:[],status:'idle',steps:[],approved:false,checks:[],repairAttempts:0,verificationCommand:''};}
function setConstraints(task,lines){
  if(!Array.isArray(lines)||lines.length>30||lines.some(x=>typeof x!=='string'||x.length>2000))throw new Error('固定约束最多 30 条，每条最多 2000 字符');
  const cleaned=[...new Set(lines.map(x=>x.trim()).filter(Boolean))];
  if(cleaned.join('\n').length>12000)throw new Error('固定约束超过 12,000 字符，未保存也未截断');
  task.constraints=cleaned;return cleaned;
}
function requiresPlanApproval(task,permission){return permission==='plan'&&!!task.steps.length&&!task.approved;}
function updatePlan(task,steps,permission='plan') {
  if(!Array.isArray(steps)||!steps.length||steps.length>16)throw new Error('计划需包含 1–16 个步骤');
  const next=steps.map((s,i)=>{if(typeof s.title!=='string'||!s.title.trim()||s.title.length>400||!['pending','running','done','blocked'].includes(s.status||'pending'))throw new Error('无效计划步骤');return {id:String(i+1),title:s.title.trim(),status:s.status||'pending'};});
  const changed=JSON.stringify(next.map(x=>x.title))!==JSON.stringify(task.steps.map(x=>x.title));
  task.steps=next;
  if(changed){task.approved=false;task.status=requiresPlanApproval(task,permission)?'awaiting_plan':'running';}
  return {approved:task.approved,steps:task.steps,status:task.status};
}
function taskSummary(task,history,journal,edits) {
  return {
    goal:task.goal,
    currentRequest:require('./task-intent').excerpt(task.currentRequest),
    pinnedConstraints:[...(task.constraints||[])],
    userRequests:history.filter(x=>x.role==='user'&&!x.content.startsWith('[Workflow')).slice(-5).map(x=>x.content.slice(0,1200)),
    plan:task.steps,
    changedFiles:[...new Set(edits.filter(x=>x.status==='applied').map(x=>x.relative))],
    verification:task.checks.slice(-3).map(x=>({command:x.command,status:x.status,exitCode:x.result?.exitCode,output:x.result?.output?.slice(-1600)})),
    operationsToCheck:journal.filter(x=>x.status!=='completed'||x.result?.status==='unknown_check_actual_state').slice(-5).map(x=>({tool:x.name,status:x.status})),
    unfinished:task.steps.filter(x=>x.status!=='done').map(x=>x.title),
    note:'Extracted state, not a complete semantic summary. Consult saved history and reread files for missing constraints.'
  };
}
// Build expected current and target states before touching any file.
function rewindPlan(edits,id) {
  const index=edits.findIndex(x=>x.id===id);if(index<0)throw new Error('检查点不存在');
  if(edits.slice(index).some(x=>['applying','restoring'].includes(x.status)))throw new Error('存在中断的应用或恢复操作，请先核对实际文件');
  const selected=edits.slice(index).filter(x=>x.status==='applied');
  if(!selected.length)throw new Error('检查点已恢复或未完成应用');
  const byFile=new Map();
  for(const item of selected){
    const previous=byFile.get(item.relative);
    if(previous&&previous.expectedHash!==item.originalHash)throw new Error('检查点之间存在外部修改，无法安全批量恢复');
    byFile.set(item.relative,{relative:item.relative,target:item.target,restoreText:previous?previous.restoreText:item.original,restoreExists:previous?previous.restoreExists:item.exists,expectedHash:files.hash(item.updated)});
  }
  return {selected,files:[...byFile.values()]};
}
module.exports={newTask,setConstraints,requiresPlanApproval,updatePlan,taskSummary,rewindPlan};
