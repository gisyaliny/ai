'use strict';
const fs=require('node:fs/promises');
const path=require('node:path');
const ignore=require('ignore');
const files=require('./files');

async function* walk(root, relative='.', signal, report={}) {
  // Use the same canonical root as resolvePath (TEMP aliases and project junctions).
  root=await fs.realpath(root);
  const start=await files.resolvePath(root,relative,true), queue=[{dir:start,rules:[]}];
  report.visited=0; report.truncated=false;
  // Load ancestor .gitignore files when starting below root.
  const parents=[];for(let d=path.dirname(start);files.within(root,d)&&d!==start;d=path.dirname(d)){parents.unshift(d);if(d===root)break;}
  for(const d of parents)try{queue[0].rules.push({base:d,matcher:ignore().add(await files.readText(root,path.relative(root,path.join(d,'.gitignore'))))});}catch{ /* Never follow escaping ignore files. */ }
  while(queue.length) {
    if(signal?.aborted)throw new Error('已停止');
    const {dir,rules}=queue.shift();
    await files.resolvePath(root,path.relative(root,dir)||'.',true);
    const local=[...rules];
    try { local.push({base:dir,matcher:ignore().add(await files.readText(root,path.relative(root,path.join(dir,'.gitignore'))))}); } catch { /* Ignore unreadable/escaping ignore files, never follow them. */ }
    let entries;try{entries=await fs.readdir(dir,{withFileTypes:true});}catch(error){report.skipped||=[];if(report.skipped.length<50)report.skipped.push({path:path.relative(root,dir)||'.',reason:error.code||'unreadable directory'});continue;}
    for(const entry of entries.sort((a,b)=>a.name.localeCompare(b.name))) {
      if(++report.visited>100_000){report.truncated=true;return;}
      const full=path.join(dir,entry.name),rel=path.relative(root,full).split(path.sep).join('/');
      if(files.blocked(rel)||entry.isSymbolicLink())continue;
      let ignored=false;for(const rule of local){const result=rule.matcher.test(path.relative(rule.base,full).split(path.sep).join('/')+(entry.isDirectory()?'/':''));if(result.ignored||result.unignored)ignored=result.ignored;}if(ignored)continue;
      if(entry.isDirectory())queue.push({dir:full,rules:local});
      else if(entry.isFile())yield rel;
    }
  }
}
async function search(root, query, {offset=0,limit=30,directory='.',signal,read=files.readText}={}) {
  if(typeof query!=='string'||!query||query.length>500)throw new Error('请提供 1–500 字符搜索文本');
  if(!Number.isInteger(offset)||offset<0||offset>100_000)throw new Error('无效 offset');
  const matches=[],report={};let hits=0,scanned=0,skipped=0;
  for await(const rel of walk(root,directory,signal,report)) {
    let text;try{text=await read(root,rel);}catch{skipped++;continue;}scanned++;
    const lines=text.split('\n');
    for(let i=0;i<lines.length;i++)if(lines[i].includes(query)){
      if(hits++<offset)continue;
      if(matches.length===limit)return {matches,scanned,skipped,truncated:true,nextOffset:offset+limit};
      matches.push({path:rel,line:i+1,text:lines[i].slice(0,500)});
    }
  }
  return {matches,scanned,skipped,truncated:report.truncated,nextOffset:null};
}
async function instructions(root, focus) {
  const dirs=[''];
  if(focus&&files.within(root,focus)){const rel=path.relative(root,path.dirname(focus));let d='';for(const part of rel.split(path.sep).filter(Boolean)){d=path.join(d,part);dirs.push(d);}}
  const loaded=[];let total=0;
  for(const dir of dirs)for(const name of ['AGENTS.md','CLAUDE.md']) {
    const rel=path.join(dir,name);let text;
    try{text=await files.readText(root,rel);}catch(e){if(e.code==='ENOENT')continue;loaded.push({path:rel,error:'unreadable or restricted'});continue;}
    const remaining=Math.max(0,24000-total);const part=text.slice(0,remaining);total+=part.length;
    loaded.push({path:rel,scope:dir||'.',text:part,truncated:part.length<text.length});
  }
  return loaded;
}
async function skills(root) {
  const found=[];
  for(const base of ['skills','.agents/skills','.claude/skills']) {
    let dir;try{dir=await files.resolvePath(root,base,true);}catch{continue;}
    for(const item of await fs.readdir(dir,{withFileTypes:true}).catch(()=>[])){
      if(!item.isDirectory()||item.isSymbolicLink())continue;
      const rel=path.join(base,item.name,'SKILL.md');
      try{const text=await files.readText(root,rel);found.push({label:item.name,description:rel,path:rel,text:text.slice(0,24000)});}catch{}
    }
  }
  return found;
}
module.exports={walk,search,instructions,skills};
