/* Assistant Markdown uses the restricted parser; all other text remains literal. */
const vscode = acquireVsCodeApi();
const el = id => document.getElementById(id);
const send = (type, extra = {}) => vscode.postMessage({ type, ...extra });
let busy = false;
let requestId=0,pathTimer,pathItems=[],pathIndex=0,pathToken=null,constraintTask;
function hidePaths(){
  clearTimeout(pathTimer);requestId++;pathItems=[];pathToken=null;
  el('pathSuggestions').hidden=true;el('prompt').setAttribute('aria-expanded','false');el('prompt').removeAttribute('aria-activedescendant');
}
function requestPaths(){
  hidePaths();if(busy)return;
  pathToken=mentionTools.active(el('prompt').value,el('prompt').selectionStart);
  if(!pathToken)return;
  const id=requestId,query=pathToken.query;
  pathTimer=setTimeout(()=>send('pathSuggestions',{requestId:id,query}),140);
}
function choosePath(index){
  if(!pathItems[index]||!pathToken)return;
  const value=mentionTools.insert(el('prompt').value,pathToken,pathItems[index]);
  el('prompt').value=value.text;el('prompt').focus();el('prompt').setSelectionRange(value.caret,value.caret);
  vscode.setState({draft:value.text});hidePaths();
}
function highlightPath(){
  for(const [index,node] of [...el('pathSuggestions').querySelectorAll('[role=option]')].entries())node.setAttribute('aria-selected',String(index===pathIndex));
  el('prompt').setAttribute('aria-activedescendant','path-option-'+pathIndex);
  el('path-option-'+pathIndex)?.scrollIntoView({block:'nearest'});
}
function renderPaths(data){
  if(data.requestId!==requestId||busy||!pathToken||data.query!==pathToken.query)return;
  pathItems=data.items;pathIndex=0;el('pathSuggestions').replaceChildren();
  const hint=document.createElement('div');hint.className='path-hint';hint.textContent=pathItems.length?(data.truncated?'前 20 项或扫描已达上限；输入目录缩小范围':'项目文件 · ↑↓ 选择 · Enter / Tab 引用'):'未找到文件，检查路径或输入更具体的目录';el('pathSuggestions').append(hint);
  pathItems.forEach((path,index)=>{const item=button(path,()=>choosePath(index));item.type='button';item.id='path-option-'+index;item.setAttribute('role','option');item.tabIndex=-1;item.addEventListener('mousedown',e=>e.preventDefault());el('pathSuggestions').append(item);});
  el('pathSuggestions').hidden=false;el('prompt').setAttribute('aria-expanded','true');
  el('pathHint').textContent=pathItems.length+' 个路径候选';if(pathItems.length)highlightPath();
}
function handlePathKey(event){
  if(event.isComposing)return true;
  if(event.key==='Escape'){hidePaths();return true;}
  if(el('pathSuggestions').hidden||!pathItems.length)return false;
  if(['ArrowDown','ArrowUp','Enter','Tab'].includes(event.key)&&!event.shiftKey){
    event.preventDefault();
    if(event.key==='Enter'||event.key==='Tab')choosePath(pathIndex);
    else{pathIndex=(pathIndex+(event.key==='ArrowDown'?1:-1)+pathItems.length)%pathItems.length;highlightPath();}
    return true;
  }
  return false;
}
function renderSummary(state){
  const container=el('contextSummary');container.replaceChildren();el('constraintCandidates').replaceChildren();
  const summary=state.compaction;
  if(!summary){container.textContent='使用 /compact 生成语义摘要；完整历史仍保留。';return;}
  const heading=document.createElement('p');heading.className='summary-kind';heading.textContent=state.compactionMethod==='semantic'?'语义摘要 · 模型生成，请核对':'提取式摘要 · 未调用模型';container.append(heading);
  const text=document.createElement('p');text.textContent=summary.semantic?.overview||summary.goal;container.append(text);
  for(const [title,items] of [['已讨论的决定',summary.semantic?.decisions],['下一步',summary.semantic?.nextSteps],['已记录修改',summary.changedFiles]]){
    if(!items?.length)continue;const h=document.createElement('h4'),ul=document.createElement('ul');h.textContent=title;
    for(const value of items){const li=document.createElement('li');li.textContent=value;ul.append(li);}container.append(h,ul);
  }
  for(const candidate of summary.semantic?.constraintCandidates||[]){
    if(state.task.constraints?.includes(candidate.quote))continue;
    const card=document.createElement('div');card.className='candidate';const quote=document.createElement('p');quote.textContent=candidate.quote;
    const pin=button('确认并固定',()=>send('saveConstraints',{text:[...(state.task.constraints||[]),candidate.quote].join('\n')}));pin.disabled=busy;
    const label=document.createElement('small');label.textContent='待确认约束 · 原始消息 '+(candidate.sourceIndex+1);card.append(label,quote,pin);el('constraintCandidates').append(card);
  }
}
let activeTab='chat';
function setTab(tab){
  if(!['chat','changes','tasks'].includes(tab))return;activeTab=tab;
  el('messages').hidden=tab!=='chat';el('changesPanel').hidden=tab!=='changes';el('tasksPanel').hidden=tab!=='tasks';
  for(const name of ['chat','changes','tasks'])el('tab-'+name).setAttribute('aria-pressed',String(name===tab));
}
for(const tab of ['chat','changes','tasks'])el('tab-'+tab).addEventListener('click',()=>setTab(tab));
const messageNodes = new Map();
function renderBody(body, row) {
  const text = row.text || '正在思考…';
  if (row.role !== 'assistant' || !row.text) {
    body.classList.remove('markdown'); body.textContent = text; return;
  }
  body.classList.add('markdown');
  body.innerHTML = safeMarkdown.render(text);
  for (const pre of body.querySelectorAll('pre')) {
    const code = pre.querySelector('code');
    if (!code) continue;
    const copy = button('复制代码', () => send('copyCode', { text: code.textContent }));
    copy.className = 'copy-code'; copy.setAttribute('aria-label', '复制此代码块');
    pre.prepend(copy);
  }
}
el('messages').addEventListener('click', event => {
  const link = event.target.closest('a');
  if (!link) return;
  event.preventDefault();
  const url = link.getAttribute('href');
  if (safeMarkdown.safeLink(url)) send('openLink', { url });
});
function button(label, action) { const b = document.createElement('button'); b.textContent = label; b.addEventListener('click', action); return b; }
function submit() { const text = el('prompt').value.trim(); if (!busy && text) { send('send', { text }); el('prompt').value = ''; vscode.setState({ draft: '' }); } }
for (const id of ['connect', 'settings', 'attach', 'stop', 'new', 'history', 'skills', 'mcp', 'mcpKey', 'model','modelThinking','pickFile','editPlan','approvePlan','compact','verify','applyVerify','reconcile']) el(id).addEventListener('click', () => send(id));
el('saveConstraints').addEventListener('click',()=>send('saveConstraints',{text:el('constraints').value}));
el('constraints').addEventListener('input',()=>el('constraints').dataset.dirty='true');
el('saveVerification').addEventListener('click',()=>send('setVerification',{command:el('verificationCommand').value}));
el('thinking').addEventListener('change',()=>send('thinking',{value:el('thinking').value}));
el('send').addEventListener('click', submit);
el('permission').addEventListener('change', () => send('permission', {value:el('permission').value}));
el('mode').addEventListener('change', () => send('mode', { value: el('mode').value }));
el('prompt').addEventListener('keydown', event => { if (handlePathKey(event))return; if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) { event.preventDefault(); submit(); } });
el('prompt').value = vscode.getState()?.draft || '';
el('prompt').addEventListener('input', () => vscode.setState({ draft: el('prompt').value }));
el('prompt').addEventListener('input',event=>{if(!event.isComposing)requestPaths();else hidePaths();});
el('prompt').addEventListener('compositionend',requestPaths);
el('prompt').addEventListener('click',requestPaths);
el('prompt').addEventListener('keyup',event=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key))requestPaths();});
document.addEventListener('mousedown',event=>{if(!event.target.closest('#pathSuggestions')&&event.target!==el('prompt'))hidePaths();});
const slashCommands=['/plan ','/compact','/review','/test','/thinking ','/help'];
el('prompt').addEventListener('input',()=>{
  const text=el('prompt').value;el('suggestions').replaceChildren();
  const suggestions=text.startsWith('/')&&!text.includes(' ')?slashCommands.filter(x=>x.startsWith(text)):[];
  el('suggestions').hidden=!suggestions.length&&true;
  for(const command of suggestions)el('suggestions').append(button(command,()=>{el('prompt').value=command;el('suggestions').hidden=true;el('prompt').focus();}));

});
window.addEventListener('message', event => {
  if(event.data.type==='pathSuggestions'){renderPaths(event.data);return;}
  if(event.data.type==='tab'){setTab(event.data.tab);return;}
  if (event.data.type !== 'state') return;
  const state = event.data.state; busy = state.busy;
  const thinking=state.thinking||{level:'default',supported:['default']};
  const labels={default:'默认',off:'关闭',on:'开启',low:'低',medium:'中',high:'高'};
  el('thinking').replaceChildren();
  for(const level of ['default','off','on','low','medium','high']){const option=document.createElement('option');option.value=level;option.textContent='Thinking · '+labels[level];option.disabled=!thinking.supported?.includes(level);el('thinking').append(option);}
  el('thinking').value=thinking.level;
  el('thinking').title=thinking.error||`${thinking.protocol} · ${thinking.capabilityReported?'服务已报告模板能力':'模板能力未确认'} · ${JSON.stringify(thinking.parameters||{})}`;
  el('connection').textContent = state.connection; el('mode').value = state.mode;
  el('permission').value=state.permission||'review';
  const metrics=state.metrics||{}, resolved=state.resolved;
  const status=[resolved ? `请求模型：${resolved.model} · ${resolved.transport}` : '模型：尚未解析', resolved?.responseModel ? `响应模型：${resolved.responseModel}` : '', metrics.inputTokens ? `输入 ${metrics.inputTokens.toLocaleString()} / ${metrics.budget.toLocaleString()} · ${metrics.countSource}` : '', metrics.lastUsage ? `最近报告：输入 ${metrics.lastUsage.prompt_tokens??'?'} / 输出 ${metrics.lastUsage.completion_tokens??'?'} tokens · 累计报告 ${metrics.totalTokens||0}${metrics.usageReported===false?'（本次未报告）':''}` : '实际 token 用量：服务端尚未报告', metrics.compacted?'已压缩发送上下文；完整历史保留在本机':'', state.instructions?.length?`已载入：${state.instructions.join(', ')}`:'', ...(state.mcp||[]), metrics.compactionProgress||'',metrics.summaryTokens?`摘要调用累计 ${metrics.summaryTokens} tokens（服务报告）`:'',state.storageError||''].filter(Boolean);
  el('status').textContent=status.join('\n');
  el('status').textContent+=`\nThinking 协议：${thinking.protocol||'默认'} · ${thinking.capabilityReported?'服务已报告能力':'能力未确认'}\n请求参数：${JSON.stringify(thinking.parameters||{})}${thinking.error?'\n'+thinking.error:''}`;
  el('compactStatus').textContent=`${resolved?.model||'模型待连接'} · ${state.permission||'review'} · ${metrics.inputTokens?`${metrics.inputTokens.toLocaleString()}/${metrics.budget?.toLocaleString()} 估算/计数`: '上下文待计算'}${busy&&metrics.reasoningObserved?' · 服务返回思考流':''}`;
  if(metrics.compactionProgress)el('compactStatus').textContent+=' · '+metrics.compactionProgress;
  el('project').textContent = `本地项目：${state.project}`;
  for (const id of ['send', 'attach', 'mode', 'new','permission','history','skills','mcp','mcpKey','model','connect','thinking','modelThinking','pickFile','editPlan','compact','saveVerification','verificationCommand','reconcile','saveConstraints','constraints']) el(id).disabled = busy;
  const task=state.task||{steps:[],checks:[]};
  if(constraintTask!==task.id){constraintTask=task.id;delete el('constraints').dataset.dirty;}
  const savedConstraints=(task.constraints||[]).join('\n');
  if(el('constraints').value===savedConstraints)delete el('constraints').dataset.dirty;
  if(!el('constraints').dataset.dirty)el('constraints').value=savedConstraints;
  el('constraintStatus').textContent=`${task.constraints?.length||0} 条已保存`;
  if(busy)hidePaths();
  el('approvePlan').disabled=busy||!task.steps?.length||task.approved;
  el('verify').disabled=busy||state.permission!=='review'||state.pending.length>0;
  el('applyVerify').disabled=busy||state.permission!=='review'||!state.pending.length||(task.steps?.length&&!task.approved);
  const statusNames={idle:'就绪',running:'进行中',awaiting_command:'等待命令批准',awaiting_plan:'等待计划批准',awaiting_review:'等待修改审阅',awaiting_verification:'等待验证',verifying:'正在验证',verified:'验证通过',verification_failed:'验证失败',blocked:'受阻',interrupted:'上次操作已中断',responded:'本轮回复结束',restored:'文件已恢复'};
  el('taskState').textContent=`${statusNames[task.status]||task.status||'就绪'} · 修复轮数 ${task.repairAttempts||0}\n${task.goal||'暂无任务'}`;
  el('steps').replaceChildren();
  for(const step of task.steps||[]){const li=document.createElement('li');li.textContent=`${{pending:'待办',running:'进行中',done:'模型报告完成',blocked:'受阻'}[step.status]} · ${step.title}`;el('steps').append(li);}
  if(document.activeElement!==el('verificationCommand'))el('verificationCommand').value=task.verificationCommand||'';
  el('checks').replaceChildren();
  for(const check of (task.checks||[]).slice(-10).reverse()){const details=document.createElement('details'),summary=document.createElement('summary'),pre=document.createElement('pre');summary.textContent=`${check.status} · ${check.command}`;pre.textContent=check.result?.output||check.result?.error||'等待或未知结果';details.append(summary,pre);el('checks').append(details);}
  renderSummary(state);
  el('checkpoints').replaceChildren();
  for(const point of (state.edits||[]).slice().reverse()){const card=document.createElement('div');card.className='change';const open=button(point.path,()=>send('openFile',{path:point.path}));const label=document.createElement('p');label.textContent=point.status+' · '+point.createdAt;const restore=button('恢复到此修改之前',()=>send('rewind',{id:point.id}));restore.disabled=busy||state.permission!=='review'||point.status!=='applied';card.append(open,label,restore);el('checkpoints').append(card);}
  el('tab-changes').textContent=`Changes${state.pending.length?' ('+state.pending.length+')':''}`;
  el('stop').hidden = !busy;
  const container = el('messages'); const nearBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 100;
  if (!state.messages.length) {
    container.replaceChildren(); messageNodes.clear();
    const welcome = document.createElement('div'); welcome.className = 'welcome';
    const title = document.createElement('h2'); title.textContent = '你的 Mac，随时协作。';
    const body = document.createElement('p'); body.textContent = '打开项目后开始聊天。模型会按需读取文件，把修改放到审阅区。OpenClaw 模式还可使用 Mac 上的技能与 MCP。';
    welcome.append(title, body); container.append(welcome);
  } else {
    container.querySelector('.welcome')?.remove();
  }
  const visible = new Set();
  for (const row of state.messages) {
    if (!row.text && !busy) continue;
    visible.add(row.id);
    let entry = messageNodes.get(row.id);
    if (!entry) {
      const article = document.createElement(row.role==='tool'?'details':'article'); article.className = `message ${row.role}`;
      const label = document.createElement(row.role==='tool'?'summary':'div'); label.className = 'label'; label.textContent = row.role==='tool'?(row.text||'工具').split('\n')[0].slice(0,110):{ user: '你', assistant: 'Studio', error: '提示' }[row.role] || row.role;
      const body = document.createElement('div'); body.className = 'body';
      article.append(label, body); container.append(article);
      entry = { article, body }; messageNodes.set(row.id, entry);
    }
    if (entry.text !== row.text || entry.role !== row.role) {
      renderBody(entry.body, row); entry.text = row.text; entry.role = row.role;
    }
  }
  for (const [id, entry] of messageNodes) if (!visible.has(id)) { entry.article.remove(); messageNodes.delete(id); }
  if (nearBottom) container.scrollTop = container.scrollHeight;
  el('attachments').replaceChildren();
  if (state.attachments.length) { const text = document.createElement('span'); text.textContent = state.attachments.join(' · '); el('attachments').append(text, button('清除', () => send('clearAttachments'))); }
  el('changes').replaceChildren();
  for (const change of state.pending) {
    const card = document.createElement('div'); card.className = 'change';
    const name = button(change.path,()=>send('openFile',{path:change.path}));
    const summary = document.createElement('p'); summary.textContent = change.summary;
    const preview = button('查看差异', () => send('preview', { id: change.id }));
    const apply = button('应用并保存', () => send('apply', { id: change.id })); apply.disabled = busy || state.permission !== 'review' || (task.steps?.length&&!task.approved);
    const reject = button('拒绝', () => send('reject', { id: change.id })); reject.disabled = busy;
    card.append(name, summary, preview, apply, reject); el('changes').append(card);
  }
});
send('ready');
