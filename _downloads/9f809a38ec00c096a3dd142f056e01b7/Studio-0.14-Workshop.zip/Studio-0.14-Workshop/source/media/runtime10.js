/* Task controls use host state; no model content becomes executable markup. */
el('pauseTask').onclick=()=>send('pause');el('resumeTask').onclick=()=>send('resume');
el('reviewWaitingPlan').onclick=()=>setTab('tasks');el('approveWaitingPlan').onclick=()=>send('approvePlan');
function queueDraft(kind){const text=el('prompt').value.trim();if(!text)return;send('queueInput',{text,kind});el('prompt').value='';vscode.setState({draft:''});updateSend();}
el('queueMessage').onclick=()=>queueDraft('next');el('steerMessage').onclick=()=>queueDraft('steer');
let runtimeKey='';const commandNodes=new Map();
window.renderRuntime=()=>{
 const phase=state.run?.phase||'idle',waitingPlan=!!state.planApprovalRequired;
 el('runtimeStatus').textContent=t('Task: {0}',waitingPlan?t('Awaiting plan approval'):t(phase))+(state.run?.reason?' · '+state.run.reason:'')+(state.metrics?.toolRound?' · '+t('Rounds: {0} / {1}',state.metrics.toolRound,state.metrics.maxToolRounds):'');
 el('planApprovalNotice').hidden=!waitingPlan;el('approveWaitingPlan').disabled=busy;el('reviewWaitingPlan').disabled=busy;
 const planKey=JSON.stringify(state.task?.steps||[]);if(el('waitingPlanSteps').dataset.plan!==planKey){el('waitingPlanSteps').dataset.plan=planKey;el('waitingPlanSteps').replaceChildren();for(const step of state.task?.steps||[]){const item=document.createElement('li');item.textContent=step.title;el('waitingPlanSteps').append(item);}}
 el('pauseTask').hidden=!busy;el('resumeTask').hidden=busy||!['paused','cancelled','blocked','interrupted'].includes(phase);
 el('queueActions').hidden=!busy;el('queueMessage').disabled=!el('prompt').value.trim();el('steerMessage').disabled=!el('prompt').value.trim();
 const key=JSON.stringify([state.inbox,state.commandJobs,state.commandGrants,state.run?.commandId]);if(runtimeKey===key)return;runtimeKey=key;
 el('queuedMessages').replaceChildren();for(const item of state.inbox||[]){const row=document.createElement('div');row.className='runtime-row';const label=document.createElement('span');label.textContent=t(item.kind==='steer'?'Next instruction':'Queued message')+': '+item.text;row.append(label,button(t('Remove'),()=>send('removeQueued',{id:item.id})));el('queuedMessages').append(row);}
 const jobs=el('commandJobs'),seen=new Set();for(const job of state.commandJobs||[]){seen.add(job.id);let row=commandNodes.get(job.id);if(!row){const card=document.createElement('details');card.className='command-job';card.open=job.canStop;const title=document.createElement('summary'),output=document.createElement('pre'),actions=document.createElement('div'),note=document.createElement('p');actions.className='toolbar';card.append(title,output,actions,note);jobs.append(card);row={card,title,output,actions,note};commandNodes.set(job.id,row);}row.title.textContent=t(job.status)+' · '+job.command;row.output.textContent=job.output||t('Waiting for output');row.note.textContent=[job.logTruncated?t('Log reached the 8 MB limit.'):'',job.error||''].filter(Boolean).join(' ');row.note.hidden=!row.note.textContent;
 const actionKey=JSON.stringify([job.canStop,state.run?.commandId===job.id]);if(row.actionKey!==actionKey){row.actionKey=actionKey;row.actions.replaceChildren(button(t('Open command log'),()=>send('openCommandLog',{id:job.id})));if(job.canStop){row.actions.append(button(t('Stop command'),()=>send('stopCommand',{id:job.id})));if(state.run?.commandId===job.id)row.actions.append(button(t('Run in background'),()=>send('backgroundCommand',{id:job.id})));}}}
 for(const [id,row] of commandNodes)if(!seen.has(id)){row.card.remove();commandNodes.delete(id);}
 const grants=el('commandGrants');grants.replaceChildren();for(const grant of state.commandGrants||[]){const row=document.createElement('div');row.className='runtime-row';const label=document.createElement('span');label.textContent=grant.command;label.title=grant.cwd;row.append(label,button(t('Revoke'),()=>send('revokeCommand',{id:grant.id})));grants.append(row);}
};
