/* M4 views consume host data only; credentials never enter webview state. */
let historyTimer,historyRequest=0,historyKey='',agentKey='',connectionKey='';
const itemText=(tag,text,cls)=>{const node=document.createElement(tag);node.textContent=text;if(cls)node.className=cls;return node;};
function historyQuery(offset=0){send('historyQuery',{query:el('historySearch').value,scope:el('historyAll').checked?'all':'project',archived:el('historyArchived').checked,offset,requestId:++historyRequest});}
el('historySearch').oninput=()=>{clearTimeout(historyTimer);historyTimer=setTimeout(()=>historyQuery(),200);};
el('historyAll').onchange=()=>historyQuery();el('historyArchived').onchange=()=>historyQuery();el('historyPrevious').onclick=()=>historyQuery(Math.max(0,(state.historyPage?.offset||0)-30));el('historyNext').onclick=()=>historyQuery((state.historyPage?.offset||0)+30);el('closeHistory').onclick=()=>setTab('chat');
el('setupConnection').onclick=()=>send('setupConnection');el('diagnoseConnection').onclick=()=>send('connect');el('testModelResponse').onclick=()=>send('testModelResponse');el('startAgent').onclick=()=>send('startAgent');
window.renderExperience=()=>{
 const page=state.historyPage||{items:[],total:0,offset:0};const next=JSON.stringify([page,busy]);
 if(next!==historyKey){historyKey=next;if(document.activeElement!==el('historySearch'))el('historySearch').value=page.query||'';el('historyAll').checked=page.scope==='all';el('historyArchived').checked=!!page.archived;el('historyCount').textContent=t('{0} chats saved on this computer',page.total);el('historyRows').replaceChildren();
  if(!page.items.length)el('historyRows').append(itemText('p',t('No matching chats. Change the search or project filter.'),'hint'));
  for(const row of page.items){const card=document.createElement('article');card.className='history-row';const action=key=>send('historyAction',{action:key,id:row.session});const title=button((row.pinned?'★ ':'')+row.title,()=>action('resume'));title.className='history-title';title.disabled=busy;card.append(title,itemText('p',row.project+' · '+new Date(row.updatedAt).toLocaleString(locale),'hint'));if(row.parent)card.append(itemText('p',t('Branched chat'),'hint'));
   const actions=document.createElement('details');actions.append(itemText('summary',t('Chat actions')));const bar=document.createElement('div');bar.className='toolbar';for(const [key,label]of [['fork','Branch'],['rename','Rename'],['pin',row.pinned?'Unpin':'Pin'],['archive',row.archived?'Unarchive':'Archive'],['export','Export transcript']]){const b=button(t(label),()=>action(key));b.disabled=busy;bar.append(b);}actions.append(bar);card.append(actions);el('historyRows').append(card);}
  el('historyPrevious').disabled=page.offset<=0;el('historyNext').disabled=page.offset+30>=page.total;
 }
 const jobs=state.agentJobs||[],nextAgents=JSON.stringify([jobs,busy,state.task?.agentResults]);
 if(nextAgents!==agentKey){agentKey=nextAgents;const focused=document.activeElement?.closest('.agent-job'),focusId=focused?.dataset.id,focusLabel=focused?document.activeElement.textContent:undefined;const open=new Set([...el('agentJobs').querySelectorAll('details[open]')].map(n=>n.dataset.id));el('agentJobs').replaceChildren();if(!jobs.length)el('agentJobs').append(itemText('p',t('Delegate a focused question or code review.'),'hint'));
  for(const job of jobs){const card=document.createElement('details');card.className='agent-job';card.dataset.id=job.id;card.open=open.has(job.id);card.append(itemText('summary',t(job.status)+' · '+job.task.slice(0,100)),itemText('p',job.model+' · '+t('Rounds: {0}',job.rounds),'hint'),itemText('p',t('Budget estimate: {0} / {1}',job.budgetUsed,job.maxTotalTokens),'hint'));
   if(job.result){const result=document.createElement('div');result.className='markdown';result.innerHTML=safeMarkdown.render(job.result);card.append(result);}
   if(job.error)card.append(itemText('p',job.error,'hint'));if(job.evidence?.length){const paths=document.createElement('div');paths.className='toolbar';for(const path of job.evidence)paths.append(button(path,()=>send('openFile',{path})));card.append(paths);}
   const bar=document.createElement('div');bar.className='toolbar';if(['running','queued'].includes(job.status))bar.append(button(t('Cancel investigation'),()=>send('cancelAgent',{id:job.id})));
   if(job.status==='completed'){const use=button(t('Add findings to context'),()=>send('useAgent',{id:job.id}));use.disabled=busy||state.task?.agentResults?.includes(job.id);bar.append(use);}bar.append(button(t('Open agent record'),()=>send('agentLog',{id:job.id})));card.append(bar);el('agentJobs').append(card);if(job.id===focusId){const target=[...card.querySelectorAll('button,summary')].find(n=>n.textContent===focusLabel&&!n.disabled);target?.focus({preventScroll:true});}
  }
 }
 el('startAgent').disabled=busy||jobs.filter(j=>['queued','running'].includes(j.status)).length>=4;
 const checks=state.connectionChecks||[],ck=JSON.stringify(checks);if(ck!==connectionKey){connectionKey=ck;el('connectionChecks').replaceChildren();for(const check of checks){const li=document.createElement('li');li.append(itemText('span',t(check.name)+' · '+t(check.status)));if(check.hint)li.append(itemText('p',t(check.hint),'hint'));el('connectionChecks').append(li);}}
 for(const id of ['setupConnection','diagnoseConnection','testModelResponse'])el(id).disabled=busy;
};

el('agentJobs').onclick=el('messages').onclick;
