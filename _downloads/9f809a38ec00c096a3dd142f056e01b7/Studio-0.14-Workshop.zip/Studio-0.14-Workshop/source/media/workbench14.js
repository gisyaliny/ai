/* Studio workbench: real host actions, no simulated execution or model HTML. */
const workbenchBody=document.createElement('div');workbenchBody.id='workbenchBody';
el('messages').before(workbenchBody);
for(const id of ['messages','workPanel','toolsPanel','historyPanel'])workbenchBody.append(el(id));
const taskToggle=button(t('Task details'),()=>setTab(activeTab==='work'?'chat':'work'));
taskToggle.id='taskToggle';taskToggle.setAttribute('aria-controls','workPanel');
const conversationLabel=document.createElement('span');conversationLabel.className='conversation-label';conversationLabel.textContent=t('Conversation');
const navigation=document.querySelector('nav.tabs');navigation.prepend(conversationLabel);navigation.append(taskToggle);
for(const id of ['tab-chat','tab-work','tab-tools'])el(id).hidden=true;
const footer=document.querySelector('footer'),caption=document.querySelector('.composer-caption');
caption.firstElementChild.id='permissionCaption';caption.lastElementChild.id='sendCaption';caption.before(el('contextMenu'));
const secondary=document.createElement('div');secondary.className='status-secondary';footer.append(secondary);secondary.append(el('contextMenu'),el('requestPerformance'));
const decision=document.createElement('section');decision.id='decisionStrip';decision.setAttribute('aria-label',t('Task status'));
footer.prepend(decision);decision.append(el('runtimeStatus').parentElement,el('reviewNotice'));
const phaseDetail=document.createElement('p');phaseDetail.id='phaseDetail';phaseDetail.className='hint';decision.append(phaseDetail);
const permissionNote=document.createElement('p');permissionNote.id='fullAccessNotice';permissionNote.hidden=true;footer.prepend(permissionNote);
const toolsBack=button(t('Back to chat'),()=>setTab('chat'));toolsBack.className='panel-back';el('toolsPanel').prepend(toolsBack);
const preferences=button(t('VS Code settings'),()=>send('settings'));el('toolsPanel').append(preferences);
el('headerSettings').onclick=()=>{setTab(activeTab==='tools'?'chat':'tools');if(activeTab==='tools')send('inspectServices');};
const toolsAction=button(t('Tools and services'),()=>{setTab('tools');send('inspectServices');});el('addPopover').append(toolsAction);

// Retain every existing renderer/host action; only regroup their containers.
const panels={changes:document.createElement('div'),plan:document.createElement('div'),agents:document.createElement('div'),activity:document.createElement('div')};
for(const [key,node] of Object.entries(panels)){node.id='detail-'+key;node.setAttribute('role','tabpanel');node.setAttribute('aria-labelledby','detail-tab-'+key);}
panels.changes.append(el('changesPanel'),el('verificationSection'));
panels.plan.append(el('taskState'),el('planSection'),el('constraintsSection'),el('summarySection'));
panels.agents.append(el('agentJobs').parentElement);
panels.activity.append(el('commandJobs').parentElement,el('imageWorkJobs').parentElement);
const detailNav=document.createElement('div');detailNav.className='detail-tabs';detailNav.setAttribute('role','tablist');detailNav.setAttribute('aria-label',t('Task details'));
let detail='changes';const detailButtons={};
function chooseDetail(key,focus=false){detail=key;for(const [name,panel] of Object.entries(panels)){panel.hidden=name!==key;detailButtons[name].setAttribute('aria-selected',String(name===key));detailButtons[name].tabIndex=name===key?0:-1;}if(focus)detailButtons[key].focus();}
for(const [key,label] of [['changes','Changes'],['plan','Plan'],['agents','Subagents'],['activity','Activity']]){const b=button(t(label),()=>chooseDetail(key));b.id='detail-tab-'+key;b.setAttribute('role','tab');b.setAttribute('aria-controls',panels[key].id);detailButtons[key]=b;detailNav.append(b);}
detailNav.addEventListener('keydown',event=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;const keys=Object.keys(panels),index=keys.indexOf(detail);event.preventDefault();chooseDetail(event.key==='Home'?keys[0]:event.key==='End'?keys.at(-1):keys[(index+(event.key==='ArrowRight'?1:-1)+keys.length)%keys.length],true);});
const detailHeading=document.createElement('div');detailHeading.className='section-heading';const detailTitle=document.createElement('h2');detailTitle.textContent=t('Task details');const detailClose=button('×',()=>{setTab('chat');taskToggle.focus();});detailClose.setAttribute('aria-label',t('Close task details'));detailHeading.append(detailTitle,detailClose);
el('workPanel').replaceChildren(detailHeading,detailNav,...Object.values(panels));chooseDetail(detail);
const originalReview=el('reviewChanges');originalReview.onclick=()=>{chooseDetail('changes');setTab('work');};
el('reviewWaitingPlan').onclick=()=>{chooseDetail('plan');setTab('work');};
window.layoutWorkbench=()=>{
 const wide=window.innerWidth>=720,work=activeTab==='work';
 workbenchBody.classList.toggle('split',wide&&work);el('messages').hidden=activeTab!=='chat'&&!(wide&&work);
 taskToggle.setAttribute('aria-expanded',String(work));taskToggle.textContent=t(work?'Hide details':'Task details')+(state.pending?.length?' · '+state.pending.length:'');
 conversationLabel.textContent=t(activeTab==='tools'?'Tools and services':activeTab==='history'?'History':'Conversation');
 if(work)el('reviewNotice').hidden=true;
};
window.addEventListener('resize',()=>window.layoutWorkbench());
let activityKey='',groupOpen=new Set();
function groupMessages(){
 const rows=state.messages||[],key=rows.map(r=>r.id+':'+r.role).join('|');
 if(key===activityKey)return;activityKey=key;
 for(const group of document.querySelectorAll('.activity-group')){if(group.open)groupOpen.add(group.dataset.key);else groupOpen.delete(group.dataset.key);}
 const container=el('messages'),nearBottom=container.scrollHeight-container.scrollTop-container.clientHeight<110;
 let group;
 for(const row of rows){const entry=messageNodes.get(row.id);if(!entry)continue;
  if(row.role==='tool'){
   if(!group){group=document.createElement('details');group.className='activity-group';group.dataset.key=row.id;group.open=groupOpen.has(row.id);const summary=document.createElement('summary');group.append(summary);container.append(group);}
   group.append(entry.article);const count=group.querySelectorAll('.message').length;group.firstElementChild.textContent=t('Tool activity · {0} records',count);
  }else{group=undefined;container.append(entry.article);}
  if(['user','assistant'].includes(row.role)&&!entry.actions){
   const actions=document.createElement('div');actions.className='message-actions';
   actions.append(button(t('Copy message'),()=>send('copyCode',{text:entry.text||''})),button(t('Use in input'),()=>{el('prompt').value=entry.text||'';vscode.setState({draft:el('prompt').value});updateSend();el('prompt').focus();}));entry.article.append(actions);entry.actions=actions;
  }
 }
 for(const group of container.querySelectorAll('.activity-group'))if(!group.querySelector('.message'))group.remove();
 if(nearBottom)container.scrollTop=container.scrollHeight;
}
function stageLabel(){
 const phase=state.run?.phase||'idle',metrics=state.metrics||{};
 if(state.planApprovalRequired)return t('Awaiting plan approval');
 if(phase==='awaiting_command')return t('Awaiting command approval');
 if(busy){if(metrics.compactionProgress)return t('Compacting context');if(phase==='executing')return t('Executing command');if(metrics.requestState==='tool')return t('Using tool')+' · '+(metrics.activeTool||'');if(metrics.requestState==='preparing')return t('Preparing context');if(metrics.requestState==='thinking')return t('Thinking…');if(metrics.requestState==='waiting')return t('Waiting for model');if(metrics.requestState==='generating')return t('Generating response');return t('Running');}
 if(state.pending?.length)return t('Awaiting review');
 return t(({idle:state.task?.status==='responded'?'Response complete':'Ready',waiting:'Waiting',paused:'Paused',cancelled:'Cancelled',blocked:'Blocked',interrupted:'Interrupted'})[phase]||phase);
}
window.renderWorkbench=()=>{
 window.layoutWorkbench();groupMessages();
 const full=state.permission==='full';permissionNote.hidden=!full;permissionNote.textContent=t('Full access · local edits and commands run without individual approval. This task only.');
 el('permissionMenu').classList.toggle('full-access',full);
 el('permissionCaption').textContent=t(full?'Checkpoints enabled · commands are not sandboxed':state.permission==='readonly'?'Read-only tools only':state.permission==='plan'?'Plan approval before execution':'Reads continue · review edits and commands');
 el('sendCaption').textContent=t(busy?'Enter to guide next step':'Enter to send');
 el('send').title=t(busy?'Guide next step':'Send');el('send').setAttribute('aria-label',el('send').title);el('send').hidden=false;el('stop').hidden=true;
 el('queueActions').hidden=true; // Send now steers at the next safe tool boundary.
 el('runtimeStatus').textContent=stageLabel();
 const metrics=state.metrics||{},phase=state.run?.phase||'idle';
 const since=['waiting','thinking','generating'].includes(metrics.requestState)?metrics.requestStartedAt:metrics.stageStartedAt;
 const elapsed=busy&&since?Math.max(0,Math.round((Date.now()-since)/1000)):0;
 const note=state.run?.reason||(!busy&&phase==='idle'&&state.task?.status==='responded'?t('The model ended this reply. Send a follow-up if work remains.'):'');
 phaseDetail.textContent=[note,busy&&elapsed?t('Current stage: {0}s',elapsed):'',metrics.compactionProgress||''].filter(Boolean).join(' · ');phaseDetail.hidden=!phaseDetail.textContent;
 el('resumeTask').textContent=t(phase==='paused'?'Resume':'Continue saved task');
 el('pauseTask').title=t('Pause after stopping the current request');
 el('reviewNotice').hidden=!state.pending?.length||activeTab==='work'||busy;
 decision.hidden=!busy&&!state.pending?.length&&!['blocked','paused','cancelled','interrupted'].includes(phase)&&state.task?.status!=='responded'&&!state.planApprovalRequired;
 detailButtons.changes.textContent=t('Changes')+(state.pending?.length?' · '+state.pending.length:'');
 detailButtons.agents.textContent=t('Subagents')+(state.agentJobs?.length?' · '+state.agentJobs.length:'');
 el('applyVerify').hidden=!state.pending?.length;
 el('applyVerify').classList.toggle('primary',(state.pending?.length||0)>1);for(const b of el('changes').querySelectorAll('button'))if(b.textContent===t('Apply and save'))b.classList.toggle('primary',state.pending?.length===1);
 if(!busy)el('requestPerformance').textContent=[metrics.toolRound?t('Rounds: {0} / {1}',metrics.toolRound,metrics.maxToolRounds):'',metrics.lastCallMs?t('Last response: {0}s',(metrics.lastCallMs/1000).toFixed(1)):''].filter(Boolean).join(' · ');
};
setInterval(()=>{if(busy)window.renderWorkbench();},1000);
window.layoutWorkbench();

if(state.task)window.renderWorkbench();
