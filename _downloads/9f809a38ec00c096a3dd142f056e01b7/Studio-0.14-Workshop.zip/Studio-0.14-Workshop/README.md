# Studio 0.14.1 workshop kit

Install the bundled VSIX; Windows users may run install-preview.ps1. See SHA256SUMS.txt and RELEASE-MANIFEST.json.

Canonical tutorial (including earlier beginner downloads): https://gisyaliny.github.io/ai/docs/workshops/macstudio-agent/index.html

The source folder is pinned to the manifest commit. Run npm ci and npm test there. All included screenshots/exercises are synthetic. No model key, personal chat or private project is bundled.
