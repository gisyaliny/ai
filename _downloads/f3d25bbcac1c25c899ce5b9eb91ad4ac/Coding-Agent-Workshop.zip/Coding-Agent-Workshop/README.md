# Build Your Own Coding Agent — Cross-platform Workshop

Start with COURSE.md or the numbered Markdown chapters in lessons/.
The first lab covers Windows, Linux and macOS, with same-machine inference,
SSH tunnelling to any server OS, and an optional POSIX remote Python bridge.
reference/ contains the completed extension; exercise-project/ is intentionally broken.
VALIDATION.md states the exact tested scope. No real credentials are included.

The original public lesson URL is retained for compatibility:
https://gisyaliny.github.io/ai/docs/workshops/macstudio-agent/index.html
