# Local Coding Assistant 0.3.0

A beginner VS Code extension workshop for Windows, Linux and macOS.
Use a local OpenAI-compatible model endpoint, or forward a server endpoint
through SSH. The optional remote Python bridge requires a Linux/macOS server
with a POSIX login shell. Windows servers use SSH port forwarding instead.

Read the workshop at https://gisyaliny.github.io/ai/docs/workshops/macstudio-agent/index.html
and start at Lab 1 before running live tests (offline: ../COURSE.md).
Windows: npm.cmd ci; npm.cmd test; npm.cmd run test:bridge.
Linux/macOS: npm ci; npm test; npm run test:bridge.
Python: python on Windows, python3 elsewhere; override with AGENT_PYTHON.
Convenience checks: powershell -File scripts/check.ps1 or sh scripts/check.sh.

Press F5, open a disposable project, then Local Agent: Open chat.
Set localagent.transport=local and localagent.modelId to an installed model.
Use Local Agent: Set API key; a nonsecret placeholder is sufficient only
when your local server intentionally ignores authentication.
Run npm run package (npm.cmd on Windows) to create a VSIX.

Edits require review and explicit application. Commands require approval.
Tools run on the VS Code workspace extension host, with your permissions.
This is not an OS sandbox. MCP and automatic skill loading are design labs.
This new extension ID does not migrate older settings or SecretStorage.
