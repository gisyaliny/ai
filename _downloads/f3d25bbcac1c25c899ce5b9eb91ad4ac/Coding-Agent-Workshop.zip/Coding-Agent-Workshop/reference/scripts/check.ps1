$ErrorActionPreference = 'Stop'
Push-Location (Join-Path $PSScriptRoot '..')
try {
    node --version
    if ($LASTEXITCODE -ne 0) { throw 'Node.js is required' }
    npm.cmd test
    if ($LASTEXITCODE -ne 0) { throw 'Core/transport tests failed' }
    npm.cmd run test:bridge
    if ($LASTEXITCODE -ne 0) { throw 'Bridge tests failed' }
} finally { Pop-Location }
