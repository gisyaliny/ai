@echo off
setlocal
pushd "%~dp0.."
call npm.cmd test
if errorlevel 1 goto fail
call npm.cmd run test:bridge
if errorlevel 1 goto fail
popd
exit /b 0
:fail
popd
exit /b 1
