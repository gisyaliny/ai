#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
node --version
npm test
npm run test:bridge
