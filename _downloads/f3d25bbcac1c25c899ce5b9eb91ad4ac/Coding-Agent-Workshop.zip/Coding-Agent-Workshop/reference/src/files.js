'use strict';
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const ignored = new Set(['.git', '.ssh', '.aws', '.azure', '.gnupg', '.codex', '.openclaw', '.vscode', 'node_modules', '.venv', 'venv', '__pycache__', 'dist', 'build', '.next']);
function blocked(relative) {
  return relative.replace(/\\/g, '/').split('/').some(x => ignored.has(x.toLowerCase()) || /^\.env(?:\.|$)/i.test(x) || /^(?:id_rsa|id_ed25519|credentials(?:\.json)?|secrets?(?:\..*)?|\.npmrc|\.pypirc)$/i.test(x) || /\.(?:pem|key|p12|pfx)$/i.test(x));
}
function within(root, candidate) { const r = path.relative(root, candidate); return r === '' || (!r.startsWith('..' + path.sep) && r !== '..' && !path.isAbsolute(r)); }
async function resolvePath(root, relative, allowRoot = false) {
  if (typeof relative !== 'string' || relative.includes('\0') || relative.includes(':') || path.isAbsolute(relative) || /^[\\/]/.test(relative)) throw new Error('Use a project-relative path');
  if (relative.split(/[\\/]/).includes('..') || blocked(relative)) throw new Error('This path is not allowed');
  const realRoot = await fs.realpath(root), target = path.resolve(realRoot, relative);
  if (!within(realRoot, target) || (!allowRoot && target === realRoot)) throw new Error('Path escapes the project');
  let parent = target;
  while (true) {
    try {
      const real = await fs.realpath(parent);
      if (!within(realRoot, real) || blocked(path.relative(realRoot, real))) throw new Error('Link points outside the project or into a restricted directory');
      break;
    }
    catch (error) { if (error.code !== 'ENOENT') throw error; parent = path.dirname(parent); }
  }
  return target;
}
function hash(text) { return crypto.createHash('sha256').update(text).digest('hex'); }
function editText(original, oldText, newText, exists) {
  if (typeof oldText !== 'string' || typeof newText !== 'string') throw new Error('Edit arguments must be strings');
  if (newText.length > 120_000) throw new Error('Edit too large; split the file');
  if (!exists) { if (oldText !== '') throw new Error('old_text must be empty for a new file'); return newText; }
  if (!oldText) throw new Error('Existing files require nonempty unique old_text');
  const pos = original.indexOf(oldText);
  if (pos < 0 || original.indexOf(oldText, pos + 1) >= 0) throw new Error('old_text was missing or ambiguous; read the file again');
  return original.slice(0, pos) + newText + original.slice(pos + oldText.length);
}
async function readText(root, relative) {
  const target = await resolvePath(root, relative);
  const stat = await fs.stat(target);
  if (!stat.isFile() || stat.size > 160_000) throw new Error('Only text files up to 160 KB are supported');
  const text = await fs.readFile(target, 'utf8');
  if (text.includes('\0')) throw new Error('Binary files are not supported');
  return text;
}
async function listFiles(root, relative = '.', limit = 400) {
  const start = await resolvePath(root, relative, true), result = [], queue = [start];
  while (queue.length && result.length < limit) {
    const dir = queue.shift();
    const entries = await fs.readdir(dir, { withFileTypes: true });
    for (const entry of entries.sort((a,b) => a.name.localeCompare(b.name))) {
      const full = path.join(dir, entry.name), rel = path.relative(await fs.realpath(root), full).split(path.sep).join('/');
      if (blocked(rel) || entry.isSymbolicLink()) continue;
      if (entry.isDirectory()) queue.push(full);
      else if (entry.isFile()) result.push(rel);
      if (result.length >= limit) break;
    }
    if (queue.length > 1000) break;
  }
  return { files: result, truncated: result.length >= limit || queue.length > 0 };
}
module.exports = { blocked, within, resolvePath, hash, editText, readText, listFiles };
