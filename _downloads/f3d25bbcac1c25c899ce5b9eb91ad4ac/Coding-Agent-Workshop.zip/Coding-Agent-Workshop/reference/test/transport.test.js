const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { bridgeRequest, completion, sshCommand } = require('../src/transport');

test('local Python discovery, UTF-8 stream and tool continuation; reject incomplete stream', async t => {
  const server = http.createServer(async (req, res) => {
    let body = ''; for await (const chunk of req) body += chunk;
    assert.equal(req.headers.authorization, 'Bearer fixture-only');
    if (req.url === '/v1/models') { res.end(JSON.stringify({data: [{id: 'fixture'}]})); return; }
    const payload = JSON.parse(body); assert.equal(payload.model, 'fixture');
    res.writeHead(200, {'Content-Type':'text/event-stream'});
    const event = delta => res.write('data: ' + JSON.stringify({choices:[{delta}]}) + '\n\n');
    if (payload.messages.at(-1).role === 'tool') event({content:'工具 café verified'});
    else if (payload.tools) {
      event({tool_calls:[{index:0,id:'call-fixture',function:{name:'local_read_file',arguments:'{"path":'}}]});
      event({tool_calls:[{index:0,function:{arguments:'"fixture.txt"}'}}]});
    } else event({content:'hello'});
    if (payload.user !== 'incomplete') res.write('data: [DONE]\n\n');
    res.end();
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise(resolve => server.close(resolve)));
  const options = {transport:'local', localPython:process.env.AGENT_PYTHON, mode:'direct', timeout:10,
    direct:{baseUrl:`http://127.0.0.1:${server.address().port}/v1`,model:'fixture',apiKey:'fixture-only'}};
  const probe = JSON.parse(await bridgeRequest(options,{mode:'direct',operation:'probe',timeout:10}));
  assert.deepEqual(probe.models,['fixture']);
  const messages = [{role:'user',content:'Read fixture'}];
  const first = await completion(options,{messages,tools:[{type:'function'}]});
  assert.equal(first.tool_calls[0].function.name,'local_read_file');
  assert.deepEqual(JSON.parse(first.tool_calls[0].function.arguments),{path:'fixture.txt'});
  messages.push(first,{role:'tool',tool_call_id:first.tool_calls[0].id,content:'fixture'});
  assert.equal((await completion(options,{messages})).content,'工具 café verified');
  await assert.rejects(completion(options,{messages,user:'incomplete'}),/Incomplete/);
  await assert.rejects(bridgeRequest({...options, transport:'unknown'},{}),/Unknown transport/);
  await assert.rejects(bridgeRequest({...options, localPython:'missing-python-fixture'},{}),/ENOENT/);
});

test('SSH command preserves executable/key argument boundaries and POSIX quotes', () => {
  const result = sshCommand({host:'model-server',identity:'key with spaces',python:"/opt/python's/bin/python3"});
  assert.equal(result.executable,'ssh');
  assert.equal(result.args[result.args.indexOf('-i')+1],'key with spaces');
  assert.equal(result.args.at(-2),'model-server');
  assert.ok(result.args.at(-1).includes("'\\''"));
  assert.throws(() => sshCommand({host:'-oProxyCommand=bad'}),/Invalid SSH/);
});
