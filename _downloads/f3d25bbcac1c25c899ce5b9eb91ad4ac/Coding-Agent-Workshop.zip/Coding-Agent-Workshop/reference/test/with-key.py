import getpass
import os
import subprocess
import sys

if len(sys.argv) < 2:
    raise SystemExit("Usage: python test/with-key.py node test/smoke.js")
env = os.environ.copy()
env["LOCALAGENT_API_KEY"] = getpass.getpass("API key (ollama for default local Ollama): ")
raise SystemExit(subprocess.call(sys.argv[1:], env=env))
