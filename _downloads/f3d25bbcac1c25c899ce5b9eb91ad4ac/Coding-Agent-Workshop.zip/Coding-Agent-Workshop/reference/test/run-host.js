const { downloadAndUnzipVSCode } = require('@vscode/test-electron');
const fs = require('node:fs/promises');
const { spawn } = require('node:child_process');
const path = require('node:path');
async function main() {
  const workspace = path.resolve(__dirname, '../test-results/workspace');
  await fs.mkdir(workspace, { recursive: true });
  await fs.rm(path.join(workspace, 'new-fixture.txt'), { force: true });
  await fs.writeFile(path.join(workspace, 'fixture.txt'), 'first\noriginal\nlast\n');
  const executable = process.env.VSCODE_EXECUTABLE || await downloadAndUnzipVSCode('stable');
  const log = await fs.open(path.resolve(__dirname, '../test-results/host-run.log'), 'w');
  await new Promise((resolve, reject) => {
    // Pass argument boundaries directly: the workspace path contains spaces.
    const child = spawn(executable, [workspace, '--disable-extensions', '--disable-updates', '--skip-welcome', '--skip-release-notes', '--disable-workspace-trust', '--user-data-dir', path.resolve(__dirname, '../test-results/vscode-profile'), '--extensions-dir', path.resolve(__dirname, '../test-results/extensions'), '--extensionDevelopmentPath=' + path.resolve(__dirname, '..'), '--extensionTestsPath=' + path.resolve(__dirname, 'host.js')], { windowsHide: true, stdio: ['ignore', log.fd, log.fd] });
    child.on('error', reject);
    child.on('close', code => code === 0 ? resolve() : reject(new Error('Extension host test failed (' + code + '); see test-results/host-run.log')));
  });
  await log.close();
  console.log('VS Code extension host tests passed.');
}
main().catch(error => { console.error(error); process.exitCode = 1; });
