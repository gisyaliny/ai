const vscode = require('vscode');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
exports.run = async function () {
  const extension = vscode.extensions.getExtension('workshop-example.localagent-assistant');
  assert.ok(extension);
  const assistant = await extension.activate();
  assert.ok(assistant);
  assert.ok(process.env.LOCALAGENT_API_KEY, 'Set LOCALAGENT_API_KEY for direct API host test');
  await assistant.context.secrets.store('localagent.apiKey', process.env.LOCALAGENT_API_KEY);
  const options = require('./options')();
  const config = vscode.workspace.getConfiguration('localagent');
  for (const [key, value] of Object.entries({mode: 'direct', transport: options.transport,
    localPython: options.localPython || '', sshHost: options.host, sshIdentityFile: options.identity,
    remotePython: options.python, baseUrl: options.direct.baseUrl, modelId: options.direct.model})) {
    await config.update(key, value, vscode.ConfigurationTarget.Global);
  }
  const connection = await assistant.connect();
  assert.ok(connection.models.includes(options.direct.model));
  await vscode.commands.executeCommand('localagent.open');
  const root = vscode.workspace.workspaceFolders[0].uri.fsPath;
  const read = await assistant.executeTool('local_read_file', { path: 'fixture.txt' });
  assert.match(read.content, /original/);
  const proposed = await assistant.executeTool('local_propose_edit', { path: 'fixture.txt', old_text: 'original', new_text: 'reviewed', summary: 'Fixture change' });
  assert.match(await fs.readFile(path.join(root, 'fixture.txt'), 'utf8'), /original/);
  await assistant.preview(proposed.id);
  await assistant.apply(proposed.id);
  assert.match(await fs.readFile(path.join(root, 'fixture.txt'), 'utf8'), /reviewed/);
  const stale = await assistant.executeTool('local_propose_edit', { path: 'fixture.txt', old_text: 'reviewed', new_text: 'should-not-apply', summary: 'Stale fixture' });
  const document = await vscode.workspace.openTextDocument(vscode.Uri.file(path.join(root, 'fixture.txt')));
  const edit = new vscode.WorkspaceEdit(); edit.insert(document.uri, new vscode.Position(0, 0), 'user edit\n'); await vscode.workspace.applyEdit(edit);
  await assert.rejects(assistant.apply(stale.id), /changed/);
  assert.ok(!document.getText().includes('should-not-apply'));
  await document.save();
  const created = await assistant.executeTool('local_propose_edit', { path: 'new-fixture.txt', old_text: '', new_text: 'created only after review', summary: 'Create fixture' });
  await assistant.apply(created.id);
  assert.equal(await fs.readFile(path.join(root, 'new-fixture.txt'), 'utf8'), 'created only after review');
  await assert.rejects(assistant.executeTool('local_read_file', { path: '../escape.txt' }));
  for (let i = 0; i < 50 && !assistant.webviewReady; i++) await new Promise(resolve => setTimeout(resolve, 100));
  assert.equal(assistant.webviewReady, true, 'Webview script should load and post ready');
  await assistant.newChat();
  const agentFile = path.join(root, 'agent-fixture.js');
  const original = 'export function add(a, b) { return a - b; }\n';
  await fs.writeFile(agentFile, original);
  await assistant.send('Integration test. Use only local_read_file and local_propose_edit on the client file agent-fixture.js. Read it, replace subtraction with addition in add(), and propose the edit for review. Do not run commands, send external messages, or access server files. Briefly explain when finished.');
  assert.equal(await fs.readFile(agentFile, 'utf8'), original, 'Model may only propose before review');
  const change = [...assistant.pending.values()].find(x => x.relative === 'agent-fixture.js');
  assert.ok(change, 'Direct model should request a local edit proposal');
  assert.match(change.updated, /a\s*\+\s*b/);
  await assistant.apply(change.id);
  assert.match(await fs.readFile(agentFile, 'utf8'), /a\s*\+\s*b/);
  await fs.writeFile(path.resolve(__dirname, '../test-results/host.json'), JSON.stringify({ activated: true, webviewReady: true, viewOpened: true, diffOpened: true, applied: true, staleEditBlocked: true, createFile: true, traversalBlocked: true, liveDirectEditFlow: true }, null, 2));
  await assistant.context.secrets.delete('localagent.apiKey');
  console.log('PASS: extension activation, webview, actual diff/apply, stale-edit guard, new file, path restrictions, live direct read/propose/apply');
};
