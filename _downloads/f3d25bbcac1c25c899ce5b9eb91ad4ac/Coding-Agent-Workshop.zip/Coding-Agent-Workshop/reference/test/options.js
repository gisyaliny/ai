// Shared by terminal tests; VS Code settings are configured separately.
module.exports = function testOptions(mode = 'direct') {
  const env = process.env;
  return {
    transport: env.AGENT_TRANSPORT || 'local',
    localPython: env.AGENT_PYTHON,
    host: env.AGENT_SSH_HOST || 'model-server',
    identity: env.AGENT_SSH_IDENTITY || '',
    python: env.AGENT_REMOTE_PYTHON || 'python3',
    mode, timeout: 300,
    direct: {
      baseUrl: env.AGENT_BASE_URL || 'http://127.0.0.1:11434/v1',
      model: env.AGENT_MODEL || 'YOUR_MODEL_ID',
      apiKey: env.LOCALAGENT_API_KEY
    }
  };
};
