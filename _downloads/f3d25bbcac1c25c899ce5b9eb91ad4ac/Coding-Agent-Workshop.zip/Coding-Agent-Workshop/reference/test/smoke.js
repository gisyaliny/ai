const { bridgeRequest, completion } = require('../src/transport');

async function main() {
  if (!process.env.LOCALAGENT_API_KEY) throw new Error('Set LOCALAGENT_API_KEY first');
  const options = require('./options')();
  console.log(await bridgeRequest(options, {mode: 'direct', operation: 'probe', timeout: 20}));
  await completion(options, {
    messages: [{role: 'user', content: 'Explain what an extension host does in one sentence.'}],
    max_tokens: 256
  }, undefined, text => process.stdout.write(text));
  process.stdout.write('\n');
}

main().catch(error => { console.error(error.message); process.exitCode = 1; });
