const { spawnSync } = require('node:child_process');
const path = require('node:path');
const python = process.env.AGENT_PYTHON || (process.platform === 'win32' ? 'python' : 'python3');
const result = spawnSync(python, [path.join(__dirname, 'bridge_test.py')], {stdio: 'inherit', windowsHide: true});
if (result.error) console.error(result.error.message);
process.exitCode = result.status ?? 1;
