'use strict';
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const {parse}=require('yaml');
const {hash,within,blocked}=require('./files');
const MAX_SKILLS=400, MAX_DIRS=3000;
function locations(root,{home=os.homedir(),codexHome=process.env.CODEX_HOME||path.join(home,'.codex'),claudeHome=process.env.CLAUDE_CONFIG_DIR||path.join(home,'.claude'),extra=[]}={}){
 const rows=[];const add=(label,dir,external=false)=>rows.push({id:hash(path.resolve(dir)).slice(0,24),label,dir:path.resolve(dir),external});
 if(root)for(const dir of ['.agents/skills','.claude/skills','skills'])add('Project · '+dir,path.join(root,dir));
 add('Personal · Agent Skills',path.join(home,'.agents/skills'),true);
 add('Codex · personal',path.join(codexHome,'skills'),true);
 add('Codex · cached plugins (select explicitly)',path.join(codexHome,'plugins/cache'),true);
 add('Claude Code · personal / synced',path.join(claudeHome,'skills'),true);
 add('Claude Code · cached plugins (select explicitly)',path.join(claudeHome,'plugins/cache'),true);
 for(const dir of extra.filter(x=>typeof x==='string'&&path.isAbsolute(x)))add('Custom library',dir,true);
 return rows.filter((s,i)=>rows.findIndex(x=>x.id===s.id)===i);
}
async function textFile(file,limit=160000){const stat=await fs.stat(file);if(!stat.isFile()||stat.size>limit)throw Error('Skill file is too large or not a regular file.');const text=await fs.readFile(file,'utf8');if(text.includes('\0'))throw Error('Skill resource must be text.');return text;}
function metadata(text,fallback){
 const match=/^\uFEFF?---\r?\n([^]*?)\r?\n---(?:\r?\n|$)/.exec(text);
 const front=match?parse(match[1],{maxAliasCount:20}):{};
 if(front&&typeof front!=='object')throw Error('Invalid skill metadata.');
 const name=String(front?.name||fallback).trim(),description=String(front?.description||'').trim();
 if(!name||name.length>120)throw Error('Invalid skill name.');
 const warnings=[];for(const field of ['context','agent','hooks'])if(front?.[field])warnings.push('Host-specific field: '+field);
 const raw=front?.['allowed-tools'];const restrictions=raw===undefined?undefined:(Array.isArray(raw)?raw:String(raw).split(/[\s,]+/)).map(String).filter(Boolean);
 if(restrictions)warnings.push('allowed-tools narrows Studio permissions; unsupported names grant nothing.');
 if(/mcp__|plugin:\/\/|skill:\/\//.test(text))warnings.push('Host tools or plugin resources must be connected separately.');
 if(/(?:python3?\s|\.py\b)/i.test(text))warnings.push('Scripts may require Python; runtime is checked when an approved command runs.');
 if(/!`/.test(text))warnings.push('Dynamic command injection is not executed.');
 return {name,description:description.slice(0,1200),auto:front?.['disable-model-invocation']!==true,userInvocable:front?.['user-invocable']!==false,argumentHint:String(front?.['argument-hint']||'').slice(0,160),restrictions,compatibility:warnings.length?'partial':'instructions',warnings};
}
async function scan(sources){
 const items=[],warnings=[],seen=new Set();let visited=0;
 for(const source of sources){
  let base;try{base=await fs.realpath(source.dir);}catch{continue;}
  const queue=[base];
  while(queue.length&&items.length<MAX_SKILLS&&visited<MAX_DIRS){
   const dir=queue.shift();visited++;
   let entries;try{entries=await fs.readdir(dir,{withFileTypes:true});}catch{continue;}
   if(entries.some(e=>e.name==='SKILL.md'&&e.isFile())){
    try{
     const file=await fs.realpath(path.join(dir,'SKILL.md'));if(!within(base,file)||seen.has(file))continue;seen.add(file);
     const text=await textFile(file),meta=metadata(text,path.basename(dir));
     // A plugin may explicitly forbid implicit invocation independently of SKILL.md.
     try{const policyFile=await fs.realpath(path.join(dir,'agents/openai.yaml'));if(within(dir,policyFile)){const policy=parse(await textFile(policyFile,16000));if(policy?.policy?.allow_implicit_invocation===false)meta.auto=false;}}catch{}
     items.push({...meta,id:hash(file).slice(0,24),file,dir,source:source.label,sourceId:source.id,version:hash(text),external:source.external});
    }catch{warnings.push(source.label+': unreadable or invalid skill');}
    continue;
   }
   for(const e of entries.sort((a,b)=>a.name.localeCompare(b.name)))if(e.isDirectory()&&!e.isSymbolicLink()&&!['node_modules','.git','.venv','__pycache__'].includes(e.name))queue.push(path.join(dir,e.name));
  }
 }
 if(items.length>=MAX_SKILLS||visited>=MAX_DIRS)warnings.push('Skill scan limit reached; choose a smaller library.');
 return {items,warnings};
}
class SkillLibrary{
 constructor(){this.items=[];this.active=new Map();this.cache=new Map();this.warnings=[];this.indexKey='';this.indexAt=0;}
 invalidate(){this.indexAt=0;}
 async refresh(sources,{force=true}={}){const key=JSON.stringify(sources);if(force||key!==this.indexKey||Date.now()-this.indexAt>30000){const result=await scan(sources);this.indexItems=result.items;this.warnings=result.warnings;this.indexKey=key;this.indexAt=Date.now();}this.items=[...this.indexItems];this.active.clear();this.cache.clear();return {items:this.items,warnings:this.warnings};}
 commands(){return this.items.filter(s=>s.userInvocable!==false).map(s=>({id:s.id,name:s.name,source:s.source,hint:s.argumentHint,status:s.compatibility}));}
 toolAllowed(name){
  const aliases={Read:['local_read_file','local_read_skill_resource'],Grep:['local_search'],Glob:['local_list_files'],Bash:['local_run_command','local_command_status'],Edit:['local_propose_edit','local_propose_changes'],Write:['local_propose_changes'],TodoWrite:['local_update_plan']};
  if(['local_find_skills','local_use_skill','local_find_mcp_tools'].includes(name))return true;
  return [...this.active.values()].every(s=>s.restrictions===undefined||s.restrictions.some(x=>x===name||aliases[x]?.includes(name)));
 }
 assertTool(name){if(!this.toolAllowed(name))throw Error('Active skill restrictions prohibit this tool. Skill metadata never grants permissions.');}
 find(id){return this.items.find(x=>x.id===id);}
 search(query){
  const words=[...new Set(String(query||'').toLowerCase().slice(0,1000).split(/[^\p{L}\p{N}_-]+/u).filter(Boolean))].slice(0,20);
  return this.items.filter(s=>s.auto).map(s=>({skill:s,score:words.reduce((score,w)=>score+(s.name.toLowerCase().includes(w)?3:0)+(s.description.toLowerCase().includes(w)?1:0),0)}))
   .filter(x=>!words.length||x.score>0).sort((a,b)=>b.score-a.score||a.skill.name.localeCompare(b.skill.name)).slice(0,20)
   .map(({skill:s})=>({id:s.id,name:s.name,description:s.description,source:s.source}));
 }
 catalog(auto=true,budget=8000){let text='',omitted=0;for(const s of this.items){if(!auto||!s.auto)continue;const row=JSON.stringify({id:s.id,name:s.name,description:s.description,source:s.source})+'\n';if(text.length+row.length>budget){omitted++;continue;}text+=row;}return {text,omitted};}
 async use(id,{manual=false,reason='Matched task',arguments:args=''}={}){
  const item=this.find(id);if(!item)throw Error('Skill is unavailable; refresh the library.');
  if(!manual&&!item.auto)throw Error('This skill requires explicit selection.');
  if(!this.active.has(id)&&this.active.size>=3)throw Error('At most 3 skills can be active per turn.');
  let text=this.cache.get(id+':SKILL.md');if(text===undefined){text=await this.readChecked(item,'SKILL.md');if(hash(text)!==item.version){this.invalidate();throw Error('Skill changed; start a new turn to refresh.');}if(text.length>24000)throw Error('SKILL.md exceeds 24,000 characters; split supporting references.');this.cache.set(id+':SKILL.md',text);}
  this.active.set(id,{id,name:item.name,source:item.source,version:item.version,reason:manual?'Manual selection':String(reason).slice(0,200),warnings:item.warnings,restrictions:item.restrictions});
  const expanded=expandArguments(text,args);this.cache.set(id+':expanded',expanded);
  return {id,name:item.name,source:item.source,directory:item.dir,content:expanded,warnings:item.warnings,note:'Read supporting text with local_read_skill_resource. Scripts require local_run_command approval; host-specific tools are not automatically available.'};
 }
 async readChecked(item,relative){
  if(typeof relative!=='string'||!relative||relative.includes(':')||relative.includes('\0')||path.isAbsolute(relative)||relative.split(/[\\/]/).includes('..')||blocked(relative))throw Error('Invalid skill resource path.');
  const target=await fs.realpath(path.join(item.dir,relative));if(!within(item.dir,target)||blocked(path.relative(item.dir,target)))throw Error('Skill resource escapes its directory or targets a restricted file.');return textFile(target);
 }
 async resource(id,relative){const item=this.find(id);if(!item||!this.active.has(id))throw Error('Activate this skill before reading resources.');const key=id+':'+relative;if(!this.cache.has(key))this.cache.set(key,await this.readChecked(item,relative));const content=this.cache.get(key);if(content.length>24000)throw Error('Skill resource exceeds 24,000 characters.');return {skill:item.name,path:relative,content};}
 guidance(){return [...this.active.keys()].map(id=>({path:'skill:'+id,text:this.cache.get(id+':expanded')||this.cache.get(id+':SKILL.md')}));}
}
function expandArguments(text,args){
 if(typeof args!=='string'||args.length>8000)throw Error('Skill arguments exceed 8,000 characters.');
 const words=(args.match(/"(?:[^"\\]|\\.)*"|'[^']*'|\S+/g)||[]).map(x=>/^(["']).*\1$/.test(x)?x.slice(1,-1):x);
 const has=/\$ARGUMENTS(?:\[\d+\])?|\$\d+/.test(text);
 const result=text.replace(/\$ARGUMENTS\[(\d+)\]|\$(\d+)\b|\$ARGUMENTS\b/g,(all,a,b)=>a!==undefined||b!==undefined?words[Number(a??b)]||'':args);
 return result+(!has&&args?'\n\nUser arguments (data, not permission grants):\n'+args:'');
}
module.exports={SkillLibrary,locations,scan,metadata,textFile,expandArguments};
