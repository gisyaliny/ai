// Bounded project reads. Disk access and search share the same path policy.
'use strict';
const fs=require('node:fs/promises');
const path=require('node:path');
const {StringDecoder}=require('node:string_decoder');
const {execFile}=require('node:child_process');
const {promisify}=require('node:util');
const execute=promisify(execFile);
const files=require('./files');
const {walk}=require('./project');
const MAX_SCAN=32*1024*1024,MAX_LINE=24000;
function rangeOptions({startLine=1,endLine=startLine+199}={}){
 if(!Number.isSafeInteger(startLine)||!Number.isSafeInteger(endLine)||startLine<1||endLine<startLine||endLine-startLine>=2000)throw Error('Request 1–2000 lines using positive integer line numbers.');
 return {startLine,endLine};
}
async function* lines(root,relative,{signal,report={}}={}){
 const target=await files.resolvePath(root,relative),handle=await fs.open(target,'r');
 try{
  const stat=await handle.stat({bigint:true}),real=await fs.realpath(target),opened=await fs.stat(real,{bigint:true}),canonical=await fs.realpath(root);
  if(!stat.isFile()||!files.within(canonical,real)||files.blocked(path.relative(canonical,real))||stat.ino!==opened.ino||(stat.dev&&opened.dev&&stat.dev!==opened.dev))throw Error('File changed or is not an allowed regular file.');
  report.size=Number(stat.size);report.scannedBytes=0;report.truncated=false;
  const decoder=new StringDecoder('utf8'),buffer=Buffer.alloc(65536);let pending='',shortened=false,number=1;
  while(true){
   if(signal?.aborted)throw Error('Stopped');
   const count=await handle.read(buffer,0,Math.min(buffer.length,MAX_SCAN-report.scannedBytes),null);
   if(!count.bytesRead){if(report.scannedBytes<stat.size){report.truncated=true;report.reason='32 MiB scan limit';}else{pending+=decoder.end();yield {number,text:pending.replace(/\r$/,''),truncated:shortened};report.totalLines=number;}return;}
   report.scannedBytes+=count.bytesRead;
   if(buffer.subarray(0,count.bytesRead).includes(0))throw Error('Binary file is not supported.');
   const chunk=decoder.write(buffer.subarray(0,count.bytesRead));let pos=0;
   for(let end=chunk.indexOf('\n',pos);;end=chunk.indexOf('\n',pos)){
    const part=chunk.slice(pos,end<0?undefined:end),remaining=MAX_LINE-pending.length;
    pending+=part.slice(0,remaining);if(part.length>remaining)shortened=true;
    if(end<0)break;
    yield {number:number++,text:pending.replace(/\r$/,''),truncated:shortened};pending='';shortened=false;pos=end+1;
   }
  }
 }finally{await handle.close();}
}
async function readRange(root,relative,options={}){
 const {startLine,endLine}=rangeOptions(options),report={},output=[],longLines=[];let chars=0,last=startLine-1,nextLine=null;
 for await(const row of lines(root,relative,{signal:options.signal,report})){
  if(row.number<startLine)continue;
  if(row.number>endLine||chars+row.text.length>24000&&output.length){nextLine=row.number;break;}
  output.push(row.text.slice(0,24000-chars));chars+=row.text.length+1;last=row.number;if(row.truncated)longLines.push(row.number);
 }
 return {path:relative,startLine,endLine:last,totalLines:report.totalLines??null,content:output.join('\n'),nextLine,truncated:!!nextLine||!!report.truncated||!!longLines.length,longLines,scannedBytes:report.scannedBytes,reason:report.reason};
}
function readDocument(document,relative,options={}){
 const {startLine,endLine}=rangeOptions(options),output=[],longLines=[];let chars=0,last=startLine-1,nextLine=null;
 for(let i=startLine-1;i<document.lineCount;i++){
  const line=document.lineAt(i).text;if(line.includes('\0'))throw Error('Binary file is not supported.');
  if(i+1>endLine||chars+line.length>24000&&output.length){nextLine=i+1;break;}
  output.push(line.slice(0,24000-chars));last=i+1;if(line.length>24000-chars)longLines.push(i+1);chars+=line.length+1;
 }
 return {path:relative,startLine,endLine:last,totalLines:document.lineCount,content:output.join('\n'),nextLine,truncated:!!nextLine||!!longLines.length,longLines,unsaved:!!document.isDirty,documentVersion:document.version};
}
async function list(root,{directory='.',offset=0,limit=200,signal}={}){
 if(!Number.isSafeInteger(offset)||offset<0||offset>100000||!Number.isInteger(limit)||limit<1||limit>1000)throw Error('Invalid file page.');
 const found=[],report={};let count=0;
 for await(const relative of walk(root,directory,signal,report)){if(count++<offset)continue;if(found.length===limit)return {files:found,nextOffset:offset+limit,truncated:true};found.push(relative);}
 return {files:found,nextOffset:null,truncated:!!report.truncated,skipped:report.skipped||[]};
}
async function search(root,query,{directory='.',offset=0,limit=30,signal,documents=new Map(),rg='rg'}={}){
 if(typeof query!=='string'||!query||query.length>500||/[\r\n\0]/.test(query))throw Error('Use a literal single-line query of 1–500 characters.');
 if(!Number.isSafeInteger(offset)||offset<0||offset>100000||!Number.isInteger(limit)||limit<1||limit>100)throw Error('Invalid search page.');
 const matches=[],skipped=[],report={};let hits=0,scanned=0,usedRg=false,rgAvailable=!!rg;
 const add=(relative,line,text)=>{if(hits++<offset)return false;if(matches.length===limit)return true;matches.push({path:relative,line,text:text.slice(0,500)});return false;};
 let batch=[],length=0;
 async function processBatch(){
  if(!batch.length)return false;
  const paths=batch;batch=[];length=0;
  if(rgAvailable){
   try{
    const {stdout}=await execute(rg,['--no-config','--json','--fixed-strings','--no-ignore','--hidden','--max-filesize','32M','--max-columns','24000','--max-columns-preview','--',query,...paths],{cwd:root,signal,windowsHide:true,maxBuffer:2_000_000,timeout:15000,encoding:'utf8'});
    const rows=stdout.split('\n').filter(Boolean).map(s=>JSON.parse(s));
    usedRg=true;scanned+=paths.length;
    for(const row of rows.filter(r=>r.type==='match').sort((a,b)=>paths.indexOf(a.data.path.text)-paths.indexOf(b.data.path.text)||a.data.line_number-b.data.line_number)){const r=row.data.path.text;if(!paths.includes(r))throw Error('Unexpected search result path');await files.resolvePath(root,r);if(add(r,row.data.line_number,row.data.lines.text.replace(/\r?\n$/,'')))return true;}
    return false;
   }catch(error){if(signal?.aborted)throw error;if(error.code===1){usedRg=true;scanned+=paths.length;return false;}if(error.code==='ENOENT')rgAvailable=false;}
  }
  for(const relative of paths){const scan={};try{scanned++;for await(const row of lines(root,relative,{signal,report:scan})){if(row.truncated)skipped.push({path:relative,line:row.number,reason:'Line exceeds 24000 characters; search preview is incomplete'});if(row.text.includes(query)&&add(relative,row.number,row.text))return true;}if(scan.truncated)skipped.push({path:relative,reason:scan.reason});}catch(error){if(signal?.aborted)throw error;skipped.push({path:relative,reason:error.message});}}
  return false;
 }
 for await(const relative of walk(root,directory,signal,report)){
  if(documents.has(relative)){
   if(await processBatch())return done(true);
   const doc=documents.get(relative);scanned++;
   for(let i=0;i<doc.lineCount;i++)if(doc.lineAt(i).text.includes(query)&&add(relative,i+1,doc.lineAt(i).text))return done(true);
  }else{
   try{const target=await files.resolvePath(root,relative),stat=await fs.stat(target);if(stat.size>MAX_SCAN){skipped.push({path:relative,reason:'32 MiB file limit'});continue;}}catch(error){skipped.push({path:relative,reason:error.message});continue;}
   if(length+relative.length>6000&&await processBatch())return done(true);
   batch.push(relative);length+=relative.length+3;if(batch.length>=64&&await processBatch())return done(true);
  }
 }
 if(await processBatch())return done(true);return done(false);
 function done(more){return {matches,nextOffset:more?offset+limit:null,truncated:more||!!report.truncated||!!skipped.length,scanned,skipped:skipped.slice(0,50),skippedCount:skipped.length,engine:usedRg?'ripgrep (bounded fallback available)':'portable stream'};}
}
module.exports={readRange,readDocument,rangeOptions,list,search,lines};
