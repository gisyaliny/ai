'use strict';
function resolveThinking(level='default',protocol='qwen',caps={},mode='direct') {
  const all=['default','off','on','low','medium','high'];
  if(!all.includes(level))throw new Error('无效 thinking 档位');
  let supported=['default'];
  if(mode==='openclaw')protocol='none';
  if(protocol==='auto')protocol=caps.effortLevels?.length?'reasoning_effort':caps.enableThinking?'qwen':'none';
  if(protocol==='qwen')supported.push('off','on');
  else if(protocol==='reasoning_effort')supported.push(...(caps.effortLevels?.length?caps.effortLevels.map(x=>x==='none'?'off':x).filter(x=>all.includes(x)):['off','low','medium','high']));
  if(!supported.includes(level))throw new Error('当前思考协议不支持此档位；Qwen 模板支持开/关，分级强度需 reasoning_effort 协议');
  const parameters=level==='default'?{}:protocol==='qwen'?{chat_template_kwargs:{enable_thinking:level==='on'}}:{reasoning_effort:level==='off'?'none':level};
  return {level,protocol,supported,parameters,capabilityReported:protocol==='qwen'?!!caps.enableThinking:protocol==='reasoning_effort'&&!!caps.effortLevels?.length,note:mode==='openclaw'?'由远端 agent 控制':level==='default'?'使用服务默认值':'已指定请求参数；服务是否遵守取决于模型模板'};
}
module.exports={resolveThinking};
