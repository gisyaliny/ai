'use strict';
const crypto=require('node:crypto');
const {Client}=require('@modelcontextprotocol/sdk/client/index.js');
const {StreamableHTTPClientTransport}=require('@modelcontextprotocol/sdk/client/streamableHttp.js');
const {StdioClientTransport,getDefaultEnvironment}=require('@modelcontextprotocol/sdk/client/stdio.js');
const {auth}=require('@modelcontextprotocol/sdk/client/auth.js');
const {OAuthProvider,safeUrl}=require('./mcp-oauth');
function validateServer(c){
 if(!/^[a-zA-Z0-9_-]{1,24}$/.test(c.id)||!Array.isArray(c.allowedTools)||!c.allowedTools.every(x=>typeof x==='string')||c.writeTools!==undefined&&(!Array.isArray(c.writeTools)||!c.writeTools.every(x=>typeof x==='string')))throw Error('MCP 需要唯一 id 和明确的 allowedTools 列表');
 if(c.tokenSecret&&!/^macstudio\.mcp\.[a-zA-Z0-9_-]+$/.test(c.tokenSecret))throw Error('MCP tokenSecret 必须使用 macstudio.mcp.<名称>');
 if(c.transport==='stdio'){if(c.oauth||typeof c.command!=='string'||!c.command||c.command.includes('\0')||!Array.isArray(c.args)||c.args.some(x=>typeof x!=='string'||x.includes('\0')))throw Error('Invalid MCP command or arguments.');return;}
 const url=safeUrl(c.url);if(url.hash||url.search)throw Error('MCP 使用 HTTPS 或本机 loopback HTTP；不要在 URL 中放凭据');
 if(c.oauth){if(c.tokenSecret||Object.keys(c.headers||{}).length)throw Error('OAuth cannot be combined with custom headers or bearer credentials.');if(c.oauth.clientMetadataUrl&&safeUrl(c.oauth.clientMetadataUrl).protocol!=='https:')throw Error('Client metadata URL requires HTTPS.');}
 return url;
}
function permitted(t,c){return c.allowedTools.includes(t.name)&&t.annotations?.readOnlyHint===true&&t.annotations?.destructiveHint!==true;}
const fingerprint=t=>crypto.createHash('sha256').update(JSON.stringify([t.name,t.description,t.inputSchema,t.annotations])).digest('hex');
async function catalog(client,signal){let cursor,rows=[];for(let page=0;page<10;page++){const result=await client.listTools(cursor?{cursor}:undefined,{signal,timeout:15000});rows.push(...result.tools);if(rows.length>1000)throw Error('MCP tool catalog too large.');cursor=result.nextCursor;if(!cursor)return rows;}throw Error('MCP discovery pagination limit');}
async function boundedFetch(input,init){
 const response=await fetch(input,{...init,redirect:'error',signal:init?.signal?AbortSignal.any([init.signal,AbortSignal.timeout(20000)]):AbortSignal.timeout(20000)});
 if(Number(response.headers.get('content-length'))>2_000_000){await response.body?.cancel();throw Error('MCP response too large');}
 if(!response.body)return response;let bytes=0;
 return new Response(response.body.pipeThrough(new TransformStream({transform(chunk,c){bytes+=chunk.byteLength;if(bytes>2_000_000)throw Error('MCP response too large');c.enqueue(chunk);}})),{status:response.status,statusText:response.statusText,headers:response.headers});
}
class ReadonlyMcp{
 constructor(){this.routes=new Map();this.catalog=new Map();this.errors=new Map();this.epochs=new Map();this.generation=0;this.exposed=new Set();this.pending=new Map();}
 get clients(){return [...this.catalog.values()].map(r=>r.client);}
 get status(){return [...this.catalog].map(([id,r])=>`${id}: ${[...this.routes.values()].filter(t=>t.config.id===id&&!t.write).length} read-only / ${[...this.routes.values()].filter(t=>t.config.id===id&&t.write).length} reviewed tools`).concat([...this.errors].map(([id,error])=>`${id}: ${error}`));}
 async disconnect(id,{signOut=false}={}){this.epochs.set(id,(this.epochs.get(id)||0)+1);const pending=this.pending.get(id);this.pending.delete(id);pending?.controller.abort();pending?.provider?.close();await pending?.client?.close().catch(()=>{});const row=this.catalog.get(id);this.catalog.delete(id);this.errors.delete(id);for(const [key,r]of this.routes)if(r.config.id===id){this.routes.delete(key);this.exposed.delete(key);}if(signOut)await row?.provider?.signOut();else row?.provider?.close();await row?.client.close().catch(()=>{});}
 async close(){this.generation++;await Promise.allSettled([...new Set([...this.catalog.keys(),...this.epochs.keys()])].map(id=>this.disconnect(id)));this.errors.clear();}
 selectTools(id,names,writes=[]){const row=this.catalog.get(id);if(!row)return;if(names.length+writes.length>64)throw Error('Select at most 64 MCP tools.');row.config.allowedTools=[...names];row.config.writeTools=[...writes];for(const [key,r]of this.routes)if(r.config.id===id)this.routes.delete(key);
  for(const t of row.tools){const read=permitted(t,row.config);if(!read&&!writes.includes(t.name))continue;const name='mcp_'+id+'_'+crypto.createHash('sha256').update(t.name).digest('hex').slice(0,10);this.routes.set(name,{name,client:row.client,original:t.name,config:row.config,write:!read,fingerprint:fingerprint(t),definition:{type:'function',function:{name,description:`${read?'Read-only':'Requires user review; may change external state'} MCP ${id} / ${t.name}: ${t.description||''}`.slice(0,800),parameters:t.inputSchema}}});}
 }
 async connect(configs,secrets,{approveStdio,openUrl,signal:outerSignal}={}){
  const generation=this.generation,ids=new Set();
  for(const input of configs){let client,provider,epoch,pending,signal;const c={...input,allowedTools:[...(input.allowedTools||[])]};
   try{
    const url=validateServer(c);if(ids.has(c.id))throw Error('Duplicate MCP id');ids.add(c.id);await this.disconnect(c.id);epoch=this.epochs.get(c.id);pending={controller:new AbortController()};this.pending.set(c.id,pending);signal=outerSignal?AbortSignal.any([outerSignal,pending.controller.signal]):pending.controller.signal;
    if(c.validateCurrent)await c.validateCurrent();
    if(c.transport==='stdio'&&(!approveStdio||!await approveStdio(c)))throw Error('MCP process launch was not approved.');
    const token=c.tokenSecret?await secrets.get(c.tokenSecret):undefined;if(c.tokenSecret&&!token)throw Error('Set MCP credentials first.');
    if(c.oauth){provider=new OAuthProvider(c,secrets,{openUrl,signal});pending.provider=provider;await provider.init();}
    const transportOptions={authProvider:provider,requestInit:{headers:{...c.headers,...(token?{Authorization:'Bearer '+token}:{})}},fetch:async(input,init)=>{safeUrl(input instanceof Request?input.url:input);const response=await boundedFetch(input,init);let request;try{request=JSON.parse(init?.body);}catch{}if([401,403].includes(response.status)&&request?.method==='tools/call'&&c.writeTools?.includes(request.params?.name)){await response.body?.cancel();throw Error('Authorization expired during an effectful call; inspect actual state and sign in again. The call was not replayed.');}return response;}};
    const makeTransport=()=>c.transport==='stdio'?new StdioClientTransport({command:c.command,args:c.args,cwd:c.cwd,env:{...getDefaultEnvironment(),...c.env},stderr:'ignore',maxBufferSize:2_000_000}):new StreamableHTTPClientTransport(url,transportOptions);
    const makeClient=()=>new Client({name:'studio-assistant',version:'0.12.0'},{capabilities:{}});
    if(provider?.expired()){const result=await auth(provider,{serverUrl:url,fetchFn:transportOptions.fetch});if(result==='REDIRECT')await auth(provider,{serverUrl:url,authorizationCode:await provider.waitForCode(),fetchFn:transportOptions.fetch});}
    if(signal.aborted||generation!==this.generation||epoch!==this.epochs.get(c.id))throw Error('Connection superseded');
    client=makeClient();pending.client=client;let transport=makeTransport();
    try{await client.connect(transport,{timeout:20000,signal});}catch(error){if(!provider?.requested)throw error;await transport.finishAuth(await provider.waitForCode());await client.close().catch(()=>{});client=makeClient();pending.client=client;transport=makeTransport();await client.connect(transport,{timeout:20000,signal});}
    const available=await catalog(client,signal);if(generation!==this.generation||epoch!==this.epochs.get(c.id))throw Error('Connection superseded');
    provider?.close();this.catalog.set(c.id,{config:c,client,tools:available,provider});this.selectTools(c.id,c.allowedTools,c.writeTools||[]);this.errors.delete(c.id);client.onclose=()=>{if(this.catalog.get(c.id)?.client===client){this.catalog.delete(c.id);provider?.close();for(const [name,route]of this.routes)if(route.config.id===c.id)this.routes.delete(name);this.errors.set(c.id,'Disconnected; reconnect this server.');}};
   }catch(error){provider?.close();await client?.close().catch(()=>{});if(generation===this.generation&&(epoch===undefined||epoch===this.epochs.get(c.id)))this.errors.set(c.id,'Connection failed; inspect configuration, runtime and authentication.');}finally{if(this.pending.get(c.id)===pending)this.pending.delete(c.id);}
  }return this.status;
 }
 names(permission='review'){return new Set([...this.routes.values()].filter(r=>!r.write||permission==='review').map(r=>r.name));}
 definitions(permission='review'){let bytes=0;return [...this.routes.values()].filter(r=>this.names(permission).has(r.name)).sort((a,b)=>Number(this.exposed.has(b.name))-Number(this.exposed.has(a.name))).filter(r=>{const size=JSON.stringify(r.definition).length;if(size>24000||bytes+size>24000)return false;bytes+=size;return true;}).slice(0,16).map(r=>r.definition);}
 discover(query,permission='review'){const words=String(query||'').toLowerCase().split(/\s+/).filter(Boolean);const rows=[...this.routes.values()].filter(r=>this.names(permission).has(r.name)&&words.every(w=>(r.original+' '+r.definition.function.description).toLowerCase().includes(w))).slice(0,8);this.exposed=new Set(rows.map(r=>r.name));return rows.map(r=>({name:r.name,server:r.config.id,tool:r.original,reviewRequired:r.write}));}
 async call(name,args,signal,{authorizeWrite}={}){
  const r=this.routes.get(name);if(!r)throw Error('MCP 工具未连接或不在允许列表');if(r.config.validateCurrent)await r.config.validateCurrent();
  const current=(await catalog(r.client,signal)).find(t=>t.name===r.original);
  if(!current||(!r.write&&!permitted(current,r.config)))throw Error('MCP 工具不再声明为已允许的只读工具');if(fingerprint(current)!==r.fingerprint)throw Error('MCP tool definition changed; reconnect and review it.');
  if(r.write&&(!authorizeWrite||!await authorizeWrite(r,args)))throw Error('MCP write requires explicit review');
  if(r.write){const latest=(await catalog(r.client,signal)).find(t=>t.name===r.original);if(!latest||fingerprint(latest)!==r.fingerprint)throw Error('MCP tool definition changed during approval; reconnect and review it.');}
  if(signal?.aborted)throw Error('MCP call cancelled before dispatch');if(r.config.validateCurrent)await r.config.validateCurrent();if(this.routes.get(name)!==r)throw Error('MCP connection changed before dispatch');
  try{const result=await r.client.callTool({name:r.original,arguments:args},undefined,{signal,timeout:30000});const text=JSON.stringify(result);return text.length>24000?{truncated:true,preview:text.slice(0,24000)}:result;}
  catch(error){if(r.write)return {status:'interrupted_unknown',message:'The external effect may have occurred. Inspect actual state before requesting a freshly reviewed retry. No automatic replay.',error:String(error.message).slice(0,500)};throw error;}
 }
}
module.exports={ReadonlyMcp,validateServer,permitted,boundedFetch};
