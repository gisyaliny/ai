'use strict';
const crypto=require('node:crypto');
const EFFECTS={local_propose_changes:'files',local_propose_edit:'files',local_run_command:'commands',local_propose_image:'generation'};
function assertEffect(effect,{permission,enabled=true,planApproved=true,pending=false}){
 if(permission!=='review')throw Error('当前权限模式禁止此操作 / Review mode required');
 if(!enabled)throw Error(effect+' disabled in Tools');
 if(!planApproved)throw Error('请先批准计划 / Approve the plan first');
 if(effect==='commands'&&pending)throw Error('修改尚未应用；请等待审阅后再验证');
}
// Exact command + canonical cwd + task only. No prefix or wildcard approval.
class CommandGrants{
 constructor(){this.entries=new Map();}
 key(command,cwd,taskId){return crypto.createHash('sha256').update(JSON.stringify([command,cwd,taskId])).digest('hex');}
 has(command,cwd,taskId){return this.entries.has(this.key(command,cwd,taskId));}
 allow(command,cwd,taskId){const id=this.key(command,cwd,taskId);this.entries.set(id,{id,command,cwd,taskId});}
 revoke(id){this.entries.delete(id);}
 clear(){this.entries.clear();}
 list(taskId){return [...this.entries.values()].filter(x=>x.taskId===taskId);}
}
module.exports={assertEffect,EFFECTS,CommandGrants};
