'use strict';
const fs=require('node:fs/promises');
const path=require('node:path');
const crypto=require('node:crypto');
const {SessionStore}=require('./session');
function dimensions(data){
 if(!Buffer.isBuffer(data)||data.length<24||data.length>8_000_000)throw Error('Images must be PNG/JPEG files under 8 MB.');
 let width,height,mime,ext;
 if(data.subarray(0,8).toString('hex')==='89504e470d0a1a0a'){
  if(data.subarray(12,16).toString()!=='IHDR')throw Error('Invalid PNG');
  width=data.readUInt32BE(16);height=data.readUInt32BE(20);mime='image/png';ext='png';
 }else if(data[0]===255&&data[1]===216){
  let i=2;
  while(i+4<data.length){
   if(data[i++]!==255)throw Error('Invalid JPEG');while(data[i]===255)i++;
   const marker=data[i++];if(marker===217||marker===218)break;if(marker===1||marker>=208&&marker<=215)continue;
   const length=data.readUInt16BE(i);if(length<2||i+length>data.length)throw Error('Invalid JPEG');
   if([192,193,194,195,197,198,199,201,202,203,205,206,207].includes(marker)){height=data.readUInt16BE(i+3);width=data.readUInt16BE(i+5);break;}i+=length;
  }mime='image/jpeg';ext='jpg';
 }
 if(!width||!height||width>2048||height>2048)throw Error('Use a PNG/JPEG image no larger than 2048 × 2048.');
 return {width,height,mime,ext,bytes:data.length};
}
class ImageStore{
 constructor(directory){this.directory=directory;this.index=new SessionStore(directory);}
 async add(data,label='Image'){
  const meta=dimensions(data),id=crypto.randomUUID();await fs.mkdir(this.directory,{recursive:true,mode:0o700});
  await fs.writeFile(path.join(this.directory,id+'.'+meta.ext),data,{flag:'wx',mode:0o600});
  const asset={id,...meta,label:String(label).slice(0,160)};await this.index.save({...asset,session:id});return asset;
 }
 async get(id){const asset=await this.index.read(id);if(!['png','jpg'].includes(asset.ext)||asset.id!==id)throw Error('Invalid image record');return {...asset,file:path.join(this.directory,id+'.'+asset.ext)};}
 async data(id){const a=await this.get(id),data=await fs.readFile(a.file);dimensions(data);return {asset:a,data};}
 async messages(messages){
  return Promise.all(messages.map(async m=>{const {images,...plain}=m;if(!images?.length)return plain;const parts=[{type:'text',text:String(m.content)}];for(const id of images){const {asset,data}=await this.data(id);parts.push({type:'image_url',image_url:{url:`data:${asset.mime};base64,${data.toString('base64')}`}});}return {...plain,content:parts};}));
 }
}
module.exports={ImageStore,dimensions};
