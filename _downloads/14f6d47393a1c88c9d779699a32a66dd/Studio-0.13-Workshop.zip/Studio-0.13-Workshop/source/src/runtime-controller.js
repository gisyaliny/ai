'use strict';
const path=require('node:path');
const vscode=require('vscode');
const ui=require('./host-ui');
const {CommandRunner}=require('./commands');
const {CommandGrants,assertEffect}=require('./permissions');
module.exports={
 setupRuntime(storage){
  this.commandGrants=new CommandGrants();this.inbox=[];this.runState={phase:'idle'};this.loopSignatures=new Map();
  this.commandRunner=new CommandRunner(storage?path.join(storage.fsPath,'commands'):undefined,job=>{this.publish();this.commandChanged(job).catch(e=>this.add('error',e.message));});
 },
 async commandChanged(job){
  if(!['completed','failed','cancelled','timed_out','interrupted_unknown'].includes(job.status))return;
  const check=this.task.checks.find(c=>c.status==='running'&&c.result?.id===job.id);if(!check)return;
  check.result=this.commandRunner.result(job.id);check.status=job.status==='completed'?'passed':job.status==='failed'?'failed':'unknown';check.finishedAt=job.finishedAt;if(check.status==='passed'&&!await this.evidenceCurrent(check))check.status='stale';
  const current=JSON.stringify(check.editIds)===JSON.stringify(this.edits.filter(e=>e.status==='applied').map(e=>e.id));
  if(this.task.checks.at(-1)===check&&current)this.task.status=check.status==='passed'?(this.recipePassed()?'verified':'awaiting_verification'):check.status==='failed'?'verification_failed':'blocked';
  this.add('tool','Background verification: '+check.status);await this.checkpoint();this.publish();
 },
 async manageHooks(){
  return this.exclusive(async()=>{
   const rows=require('./hooks').definitions(vscode.workspace.getConfiguration('macstudio').get('hooks',[]));
   if(!rows.length){await vscode.commands.executeCommand('workbench.action.openSettings','macstudio.hooks');return;}
   const root=await this.project();
   const unknown=(this.task.hookRuns||[]).filter(r=>['started','interrupted_unknown','running','timed_out','cancelled'].includes(r.status)&&!r.acknowledgedAt);
   if(unknown.length){const answer=await ui.showWarningMessage('Inspect unknown hook outcomes before enabling a retry.',{modal:true,detail:unknown.map(r=>r.hook+' · '+r.status).join('\n')},'I inspected the actual state');if(answer!=='I inspected the actual state')return;for(const record of unknown)record.acknowledgedAt=new Date().toISOString();this.commandGrants.clear();await this.checkpoint();}
   const saved=this.context.globalState?.get('studio.hooks',{})||{},key=require('./files').hash(root),enabled=saved[key]||[];
   const selected=await ui.showQuickPick(rows.map(r=>({label:r.id,description:r.event,detail:r.command,picked:enabled.includes(r.fingerprint),row:r})),{canPickMany:true,placeHolder:'Enable hooks for this project; commands still require approval'});if(!selected)return;
   saved[key]=selected.map(x=>x.row.fingerprint);await this.context.globalState?.update('studio.hooks',saved);this.publish();
  });
 },
 async runHooks(event,data={},signal){
  if(this.inHook||this.permission!=='review'||signal?.aborted||!this.root||this.pending.size||this.task.steps.length&&!this.task.approved)return;
  if(!vscode.workspace.getConfiguration('macstudio').get('allowCommands',true)||!this.skillLibrary.toolAllowed('local_run_command'))return;
  const {hash}=require('./files'),key=hash(this.root),enabled=this.context.globalState?.get('studio.hooks',{})?.[key]||[];
  const rows=require('./hooks').definitions(vscode.workspace.getConfiguration('macstudio').get('hooks',[])).filter(r=>r.event===event&&enabled.includes(r.fingerprint));
  if(!rows.length)return;this.inHook=true;
  try{for(const row of rows){
   if((this.hookCount||0)>=8){this.add('tool','Hook limit reached (8 per operation).');if(event==='before-tool')throw Error('Before-tool hook limit reached; dispatch stopped.');break;}this.hookCount=(this.hookCount||0)+1;
   const unknown=(this.task.hookRuns||[]).some(r=>r.hook===row.id&&['started','interrupted_unknown','running','timed_out','cancelled'].includes(r.status)&&!r.acknowledgedAt);if(unknown){this.add('tool','Hook '+row.id+' has an unknown prior outcome. Inspect it and acknowledge it in Manage hooks.');if(event==='before-tool')throw Error('Before-tool hook outcome unknown; dispatch stopped.');continue;}
   const record={id:require('node:crypto').randomUUID(),hook:row.id,fingerprint:row.fingerprint,event,data,status:'started',startedAt:new Date().toISOString()};this.task.hookRuns||=[];this.task.hookRuns.push(record);this.task.hookRuns=this.task.hookRuns.slice(-80);await this.checkpoint();
   const authorize=()=>{const current=require('./hooks').definitions(vscode.workspace.getConfiguration('macstudio').get('hooks',[]));const allowed=this.context.globalState?.get('studio.hooks',{})?.[key]||[];if(!current.some(x=>x.fingerprint===row.fingerprint)||!allowed.includes(row.fingerprint))throw Error('Hook changed or was disabled before execution');};
   try{authorize();const result=await this.runCommand(row.command,this.root,signal,{waitForExit:true,timeoutMs:row.timeoutSeconds*1000,authorize});record.status=result.status;record.commandId=result.id;record.exitCode=result.exitCode;record.output=result.output?.slice(-2000);}
   catch(error){record.status='interrupted_unknown';record.error=error.message;}
   record.finishedAt=new Date().toISOString();this.add('tool',`Hook ${row.id}: ${record.status}`);await this.checkpoint();
   if(event==='before-tool'&&record.status!=='completed')throw Error('Before-tool hook did not pass; tool dispatch stopped.');
  }}finally{this.inHook=false;}
 },
 runtimeState(){return {run:this.runState,inbox:this.inbox,commandJobs:this.commandRunner.list(this.task.id),commandGrants:this.commandGrants.list(this.task.id)};},
 guardEffect(effect){
  this.trusted();const key={commands:'allowCommands',files:'allowFileEdits',generation:'allowImageGeneration',mcp:'allowMcpWrites'}[effect];
  assertEffect(effect,{permission:this.permission,enabled:vscode.workspace.getConfiguration('macstudio').get(key,true),planApproved:!this.task.steps.length||this.task.approved,pending:!!this.pending.size});
 },
 async runCommand(command,cwd,signal,execution={}){
  this.guardEffect('commands');this.skillLibrary.assertTool('local_run_command');
  if(typeof command!=='string'||!command.trim()||command.length>4000)throw Error('Invalid command');
  const root=await this.project();if(cwd!==root)throw Error('Command directory must match the selected project');
  const taskId=this.task.id;let taskGrant=false;
  const existing=[...this.commandRunner.jobs.values()].find(j=>j.taskId===taskId&&j.command===command&&j.cwd===cwd&&this.commandRunner.live.has(j.id));if(existing)return execution.waitForExit?this.commandRunner.wait(existing.id,{signal,backgroundAfterMs:Infinity}):this.commandRunner.result(existing.id);
  if(!this.commandGrants.has(command,cwd,taskId)){
   this.runState={phase:'awaiting_command'};await this.checkpoint();this.publish();
   const once='运行一次',task='Allow exact command for this task';
   const answer=await ui.showWarningMessage(`允许在本机运行此命令？\n目录：${cwd}\n\n${command}`,{modal:true,detail:'Runs with your system user permissions, without an OS sandbox. Task approval covers this exact command and directory, including later changes to scripts it calls. Revoke it in Work. It expires on reload.'},once,task);
   if(![once,task].includes(answer)||signal?.aborted){if(!['paused','cancelled'].includes(this.runState.phase))this.runState={phase:'blocked',reason:'Command denied'};return {status:'denied'};}
   this.guardEffect('commands');if(taskId!==this.task.id)throw Error('Task changed during approval');
   if(answer===task)this.commandGrants.allow(command,cwd,taskId);
  }
  taskGrant=this.commandGrants.has(command,cwd,taskId);
  this.guardEffect('commands');if(signal?.aborted)return {status:'denied',reason:'stopped'};
  const config=vscode.workspace.getConfiguration('macstudio');
  const id=await this.commandRunner.start({command,cwd,taskId,timeoutMs:execution.timeoutMs??config.get('commandTimeoutSeconds',600)*1000,signal,authorize:()=>{this.guardEffect('commands');this.skillLibrary.assertTool('local_run_command');if(execution.authorize)execution.authorize();if(taskGrant&&!this.commandGrants.has(command,cwd,taskId))throw Error('Command approval was revoked');if(taskId!==this.task.id)throw Error('Task changed before dispatch');}});
  this.runState={phase:'executing',commandId:id};await this.checkpoint();this.publish();
  const result=await this.commandRunner.wait(id,{signal,backgroundAfterMs:execution.waitForExit?Infinity:config.get('commandBackgroundSeconds',10)*1000});
  if(!['paused','cancelled'].includes(this.runState.phase))this.runState={phase:this.busy?'running':'idle'};await this.checkpoint();this.publish();return result;
 },
 commandJob(id){const job=this.commandRunner.jobs.get(id);if(!job||job.taskId!==this.task.id)throw Error('Unknown command in this task');return job;},
 async commandStatus(id){this.trusted();this.commandJob(id);return this.commandRunner.result(id);},
 async stopCommand(id){this.trusted();this.commandJob(id);await this.commandRunner.stop(id);this.publish();},
 async openCommandLog(id){this.trusted();this.commandJob(id);await vscode.commands.executeCommand('vscode.open',vscode.Uri.file(path.join(this.commandRunner.directory,id+'.log')));},
 async queueInput(text,kind='next'){
  this.trusted();if(typeof text!=='string'||!text.trim()||text.length>30000||!['next','steer'].includes(kind))throw Error('Invalid queued message');
  if(!this.busy)return this.handleInput(text);
  if(this.inbox.length>=8)throw Error('At most 8 queued messages');
  this.inbox.push({id:require('node:crypto').randomUUID(),text:text.trim(),kind});await this.checkpoint();this.publish();
 },
 async consumeSteering(){
  const items=this.inbox.filter(x=>x.kind==='steer');if(!items.length)return;
  this.inbox=this.inbox.filter(x=>x.kind!=='steer');for(const item of items){this.add('user',item.text);this.history.push({role:'user',content:item.text});}
  await this.checkpoint();
 },
 async drainInbox(){
  if(this.busy||['paused','cancelled','blocked','interrupted'].includes(this.runState.phase)||this.pending.size||this.task.steps.length&&!this.task.approved)return;
  const item=this.inbox.shift();if(!item)return;await this.checkpoint();return this.handleInput(item.text);
 },
 async pauseTask(cancel=false){
  this.runState={phase:cancel?'cancelled':'paused'};this.controller?.abort();await this.agents.cancelTask(this.task.id);
  if(cancel)await this.commandRunner.stopTask(this.task.id);
  await this.checkpoint();this.publish();
 },
 async resumeTask(){
  if(this.busy)throw Error('Wait for the current operation to stop');
  this.runState={phase:'idle'};const next=this.inbox.shift();await this.checkpoint();
  return this.handleInput(next?.text||'Continue the saved task. Inspect interrupted or unknown operations before any retry; never replay them automatically.');
 },
 repeatedCall(name,args){
  if(['local_command_status','local_image_status'].includes(name))return false;
  const signature=JSON.stringify([name,args]);const count=(this.loopSignatures.get(signature)||0)+1;this.loopSignatures.set(signature,count);
  return count>3;
 }
};
