'use strict';
const vscode=require('vscode');
const fs=require('node:fs/promises');
const path=require('node:path');
const crypto=require('node:crypto');
const ui=require('./host-ui');
const {sshRequest}=require('./transport');
const {ImageStore}=require('./images');
const {SessionStore}=require('./session');
const terminal=new Set(['completed','failed','cancelled','canceled','rejected']);
function validateSpec(input,defaults={}){
 const spec={workflow:'text-to-image',prompt:'',width:512,height:512,count:1,steps:4,seed:crypto.randomInt(0,2**32),...defaults,...input};
 if(!['text-to-image','image-to-image'].includes(spec.workflow)||typeof spec.prompt!=='string'||!spec.prompt.trim()||spec.prompt.length>4000)throw Error('Enter a prompt of 1–4000 characters.');
 if(![spec.width,spec.height,spec.count,spec.steps,spec.seed].every(Number.isSafeInteger)||spec.width%16||spec.height%16||spec.width<256||spec.height<256||spec.width>1536||spec.height>1536||spec.width*spec.height>1048576||spec.count<1||spec.count>4||spec.steps<1||spec.steps>40||spec.seed<0)throw Error('Use dimensions divisible by 16, 256–1536 per side, at most 1 megapixel, 1–4 images and 1–40 steps.');
 return Object.fromEntries(['workflow','prompt','width','height','count','steps','seed','model','encoder','vae','referenceImage'].map(k=>[k,spec[k]]));
}
module.exports={
 setupMedia(storage){
  this.imageAssets=new Map();this.imageJobs=new Map();this.services={};
  if(storage){this.images=new ImageStore(path.join(storage.fsPath,'images'));this.jobStore=new SessionStore(path.join(storage.fsPath,'image-jobs'));}
 },
 async initMedia(){
  if(this.mediaInitialized||!this.jobStore)return;this.mediaInitialized=true;
  for(const job of await this.jobStore.list())if(job.id===job.session)this.imageJobs.set(job.id,job);
  await this.restoreImageAssets();
  this.mediaTimer=setInterval(()=>this.pollImageJobs().catch(()=>{}),5000);this.mediaTimer.unref?.();
 },
 async restoreImageAssets(){
  const ids=new Set([...(this.messages||[]).flatMap(m=>m.images||[]),...(this.attachments||[]).filter(x=>x.imageId).map(x=>x.imageId),...[...this.imageJobs.values()].flatMap(j=>[...(j.assets||[]),j.spec?.referenceImage].filter(Boolean))]);
  for(const id of ids)try{this.imageAssets.set(id,await this.images.get(id));}catch{/* A missing local image is shown as unavailable, not silently replaced. */}
 },
 mediaState(){
  const config=vscode.workspace.getConfiguration('macstudio');
  return {jobs:[...this.imageJobs.values()].filter(j=>j.conversationId===(this.conversationId||this.session)).map(({target,...job})=>job),assets:[...this.imageAssets.values()].map(({file,...asset})=>({...asset,url:this.view&&file?String(this.view.webview.asWebviewUri(vscode.Uri.file(file))):undefined})),services:this.services,comfyDefaults:{model:config.get('comfy.model','flux-2-klein-9b.safetensors')},mediaEnabled:config.get('comfy.enabled',false),permissions:{generation:config.get('allowImageGeneration',true),files:config.get('allowFileEdits',true),commands:config.get('allowCommands',true),mcp:config.get('allowMcpWrites',true)},visionEnabled:config.get('visionEnabled',true),libraries:{active:this.skillLibrary?.active.size||0,available:this.skillLibrary?.items.length||0,automatic:this.libraryPreferences().auto,sources:[...new Set((this.skillLibrary?.items||[]).map(s=>s.source))]},clientLocation:({win32:'Windows',darwin:'macOS',linux:'Linux'})[process.platform]||process.platform,mcpTools:[...this.mcp.catalog?.entries()||[]].map(([id,s])=>({id,authentication:s.provider?'OAuth':s.config.tokenSecret?'Bearer token':'Server configuration',source:s.config.sourceLabel||'Extension settings',transport:s.config.transport||'http',tools:s.tools.map(t=>({name:t.name,enabled:s.config.allowedTools.includes(t.name)&&t.annotations?.readOnlyHint===true&&t.annotations?.destructiveHint!==true||s.config.writeTools?.includes(t.name),reviewRequired:s.config.writeTools?.includes(t.name)}))}))};
 },
 async addImage(data,label){this.imageQueue=(this.imageQueue||Promise.resolve()).catch(()=>{}).then(()=>this.addImageInternal(data,label));return this.imageQueue;},
 async addImageInternal(data,label){
  this.trusted();if(this.busy)throw Error('Wait for the current reply.');if(this.attachments.filter(x=>x.imageId).length>=3)throw Error('Attach at most three images per message.');
  const asset=await this.images.add(data,label);this.imageAssets.set(asset.id,await this.images.get(asset.id));this.attachments.push({imageId:asset.id,label:asset.label});await this.checkpoint();this.publish();return asset;
 },
 async pickImage(){
  this.trusted();const selected=await vscode.window.showOpenDialog({canSelectMany:true,filters:{Images:['png','jpg','jpeg']},openLabel:ui.translate('Attach image')});
  for(const uri of selected||[]){if(uri.scheme!=='file')throw Error('Choose a local image.');if((await fs.stat(uri.fsPath)).size>8_000_000)throw Error('Image exceeds 8 MB.');await this.addImage(await fs.readFile(uri.fsPath),path.basename(uri.fsPath));}
 },
 async receiveImage(event){if(typeof event.data!=='string'||event.data.length>10_700_000||!/^data:image\/(png|jpeg);base64,[A-Za-z0-9+/=]+$/.test(event.data))throw Error('Paste or drop a PNG/JPEG image under 8 MB.');return this.addImage(Buffer.from(event.data.split(',')[1],'base64'),event.name||'Image');},
 async useImage(id){this.trusted();if(this.busy)throw Error('Wait for the current reply.');if(!this.imageAssets.has(id))throw Error('Image is unavailable in this session.');if(this.attachments.filter(x=>x.imageId).length>=3)throw Error('Attach at most three images per message.');const a=await this.images.get(id);this.attachments.push({imageId:id,label:a.label});await this.checkpoint();this.publish();},
 async openImage(id){this.trusted();if(!this.imageAssets.has(id))throw Error('Unknown image');const a=await this.images.get(id);await vscode.commands.executeCommand('vscode.open',vscode.Uri.file(a.file));},
 async saveImage(id){
  this.trusted();if(!this.imageAssets.has(id))throw Error('Unknown image');const {asset,data}=await this.images.data(id),root=await this.project(false);
  const uri=await vscode.window.showSaveDialog({defaultUri:vscode.Uri.file(path.join(root||path.dirname(asset.file),'studio-image.'+asset.ext)),filters:{Images:[asset.ext]}});
  if(uri){await vscode.workspace.fs.writeFile(uri,data);await vscode.commands.executeCommand('vscode.open',uri);}
 },
 comfyTarget(){const o=this.options();return {host:o.host,identity:o.identity,executable:o.executable,python:o.python,baseUrl:vscode.workspace.getConfiguration('macstudio').get('comfy.baseUrl','http://127.0.0.1:8188')};},
 async comfyRequest(target,operation,extra={}){return JSON.parse(await sshRequest(target,{namespace:'comfy',operation,baseUrl:target.baseUrl,timeout:30,...extra}));},
 async inspectComfy(enable=false){
  this.trusted();if(enable)await vscode.workspace.getConfiguration('macstudio').update('comfy.enabled',true,vscode.ConfigurationTarget.Global);
  this.services.comfy={...this.services.comfy,state:'connecting'};this.publish();const start=Date.now(),target=this.comfyTarget();
  try{const info=await this.comfyRequest(target,'inspect');if(JSON.stringify(target)!==JSON.stringify(this.comfyTarget()))throw Error('ComfyUI settings changed; reconnect.');this.services.comfy={...info,state:'ready',location:'Mac / SSH',latencyMs:Date.now()-start,checkedAt:Date.now()};this.comfyCatalogTarget=JSON.stringify(target);return info;}
  catch(error){this.services.comfy={state:'offline',error:error.message};throw error;}finally{this.publish();}
 },
 async proposeImage(input,{fromUi=false}={}){
  this.trusted();const c=vscode.workspace.getConfiguration('macstudio');if(this.permission!=='review'||!c.get('allowImageGeneration',true))throw Error('Image generation requires Review mode and image permission.');if(!c.get('comfy.enabled',false))throw Error('Connect ComfyUI in Tools first.');
  if(!this.services.comfy?.models||this.comfyCatalogTarget!==JSON.stringify(this.comfyTarget())||Date.now()-this.services.comfy.checkedAt>300000)await this.inspectComfy();
  const catalog=this.services.comfy;if(catalog.safeJobs===false)throw Error('Use ComfyUI 0.41 or newer for durable job IDs and safe per-job cancellation.');
  const spec=validateSpec(input,{model:c.get('comfy.model','flux-2-klein-9b.safetensors'),encoder:c.get('comfy.encoder','flux2-klein-9b-ponpoke-f16.safetensors'),vae:c.get('comfy.vae','flux2-vae.safetensors')});
  for(const [key,list] of [['model',catalog.models],['encoder',catalog.encoders],['vae',catalog.vaes]])if(!list?.includes(spec[key]))throw Error('Select available FLUX.2 Klein files in Tools settings.');
  if(spec.workflow==='image-to-image'){if(!catalog.imageToImage||!this.imageAssets.has(spec.referenceImage))throw Error('Attach a reference image before using image-to-image.');await this.images.get(spec.referenceImage);}
  else delete spec.referenceImage;
  const conversationId=this.conversationId||this.session;
  const duplicate=[...this.imageJobs.values()].find(j=>j.conversationId===conversationId&&j.status==='awaiting_approval'&&JSON.stringify({...j.spec,seed:0})===JSON.stringify({...spec,seed:0}));if(duplicate)return {id:duplicate.id,status:duplicate.status};
  if(fromUi){await this.project(false);const row=this.add('user',spec.prompt);row.images=spec.referenceImage?[spec.referenceImage]:[];this.history.push({role:'user',content:'Image generation request: '+spec.prompt,...(row.images.length?{images:row.images}:{})});}
  const job={id:crypto.randomUUID(),conversationId,root:this.root,spec,target:this.comfyTarget(),status:'awaiting_approval',createdAt:new Date().toISOString(),assets:[]};
  this.imageJobs.set(job.id,job);await this.saveImageJob(job);this.add('tool','Image request ready for review.');await this.checkpoint();this.publish();return {id:job.id,status:job.status,note:'User must approve the visible generation card. Do not call terminal tools to bypass it.'};
 },
 async saveImageJob(job){await this.jobStore.save({...job,session:job.id});},
 async approveImage(id){
  this.trusted();const job=this.imageJobs.get(id),c=vscode.workspace.getConfiguration('macstudio');if(!job||job.status!=='awaiting_approval')return;
  if(this.permission!=='review'||!c.get('allowImageGeneration',true)||!c.get('comfy.enabled',false))throw Error('Image generation is disabled in the current permission mode.');
  if(JSON.stringify(job.target)!==JSON.stringify(this.comfyTarget()))throw Error('Connection settings changed. Reject this card and create a new request.');
  if(this.task.steps.length&&!this.task.approved)throw Error('Approve the task plan first.');
  job.status='submitting';job.submittedAt=Date.now();await this.saveImageJob(job);this.publish();
  try{const image=job.spec.referenceImage?(await this.images.data(job.spec.referenceImage)).data.toString('base64'):undefined;const result=await this.comfyRequest(job.target,'submit',{id:job.id,spec:job.spec,image});Object.assign(job,result);}
  catch(error){job.status='unknown';job.error=error.message;}
  await this.saveImageJob(job);this.publish();
 },
 async rejectImage(id){const job=this.imageJobs.get(id);if(job?.status==='awaiting_approval'){job.status='rejected';await this.saveImageJob(job);this.publish();}},
 async refreshImageJob(id){
  this.imageRefreshes||=new Map();if(this.imageRefreshes.has(id))return this.imageRefreshes.get(id);
  const task=this.refreshImageJobInternal(id).finally(()=>this.imageRefreshes.delete(id));this.imageRefreshes.set(id,task);return task;
 },
 async refreshImageJobInternal(id){
  this.trusted();const job=this.imageJobs.get(id);if(!job||job.status==='awaiting_approval'||job.status==='rejected')return;
  try{
   const result=await this.comfyRequest(job.target,'status',{id});if(['cancelled','rejected'].includes(job.status)||job.status==='completed'&&result.status!=='completed')return;delete job.error;Object.assign(job,result);job.lastChecked=Date.now();job.nextPollAt=Date.now()+(result.status==='unknown'?60000:5000);
   if(result.status==='completed'){
    for(let index=job.assets.length;index<(result.images||[]).length;index++){
     const output=await this.comfyRequest(job.target,'download',{id,index});const asset=await this.images.add(Buffer.from(output.data,'base64'),'Generated image '+(index+1));
     job.assets.push(asset.id);this.imageAssets.set(asset.id,await this.images.get(asset.id));await this.saveImageJob(job);
    }
    job.executionSeconds=result.execution_end_time&&result.execution_start_time?(result.execution_end_time-result.execution_start_time)/1000:undefined;
   }
  }catch(error){job.error=error.message;job.disconnected=true;job.nextPollAt=Date.now()+30000;}
  if(!job.error)delete job.disconnected;
  await this.saveImageJob(job);this.publish();
 },
 async pollImageJobs(){
  if(this.mediaPolling||!vscode.workspace.isTrusted)return;this.mediaPolling=true;
  try{for(const job of this.imageJobs.values())if(Date.now()>=(job.nextPollAt||0)&&(job.status!=='awaiting_approval'&&!terminal.has(job.status)||job.status==='completed'&&job.assets.length<(job.images||[]).length))await this.refreshImageJob(job.id);}
  finally{this.mediaPolling=false;}
 },
 async cancelImage(id){
  this.trusted();const job=this.imageJobs.get(id);if(!job||terminal.has(job.status))return;if(job.status==='awaiting_approval')return this.rejectImage(id);
  if(this.permission!=='review')throw Error('Switch to Review mode to cancel a remote job.');
  const result=await this.comfyRequest(job.target,'cancel',{id});if(result.cancelled){job.status='cancelled';await this.saveImageJob(job);}else await this.refreshImageJob(id);this.publish();
 },
 async setToolPermission(key,value){this.trusted();if(this.busy)throw Error('Wait for the current reply.');if(!['allowImageGeneration','allowFileEdits','allowCommands','allowMcpWrites'].includes(key)||typeof value!=='boolean')throw Error('Invalid permission');await vscode.workspace.getConfiguration('macstudio').update(key,value,vscode.ConfigurationTarget.Global);this.publish();},
 async openToolSettings(service){await vscode.commands.executeCommand('workbench.action.openSettings',service==='comfy'?'@ext:yyang-local.macstudio-assistant comfy':'@ext:yyang-local.macstudio-assistant');},
 async inspectServices(){
  this.trusted();if(!this.busy&&!this.skillLibrary?.items.length)await this.refreshSkillLibrary();const options=await this.connectionOptions(),start=Date.now();this.services.model={state:'connecting'};this.publish();
  try{const info=JSON.parse(await sshRequest(options,{operation:'service_status',mode:options.mode,timeout:20}));this.services.model={...info,location:'Mac / SSH',latencyMs:Date.now()-start,checkedAt:Date.now()};}
  catch(error){this.services.model={state:/404/.test(error.message)?'unreported':'offline',error:error.message};}this.publish();
 }
};
module.exports.validateSpec=validateSpec;
