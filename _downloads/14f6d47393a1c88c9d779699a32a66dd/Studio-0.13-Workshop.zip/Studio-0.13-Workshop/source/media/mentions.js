(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.mentionTools=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
  function active(text,caret){
    const before=text.slice(0,caret),match=/(?:^|\s)@(?:"([^"\n]*)|([^\s"@]*))$/.exec(before);
    if(!match)return null;
    const start=before.lastIndexOf('@');return {start,end:caret,query:match[1]??match[2],quoted:match[1]!==undefined};
  }
  function insert(text,token,path){
    if(/["\r\n]/.test(path))throw new Error('Invalid path');
    const value='@"'+path+'"';
    let end=token.end;
    if(token.quoted){while(end<text.length&&text[end]!=='"'&&text[end]!=='\n')end++;if(text[end]==='"')end++;}
    else while(end<text.length&&!/\s/.test(text[end]))end++;
    if(text[end]===' ')end++;
    return {text:text.slice(0,token.start)+value+' '+text.slice(end),caret:token.start+value.length+1};
  }
  return {active,insert};
});
