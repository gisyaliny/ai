/* Markdown is parsed with raw HTML disabled; only explicit HTTP(S) links survive. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./vendor/markdown-it.min.js'));
  else root.safeMarkdown = factory(root.markdownit);
})(typeof globalThis === 'object' ? globalThis : this, function (MarkdownIt) {
  function safeLink(value) {
    if (typeof value !== 'string' || !/^https?:\/\//i.test(value) || /[\u0000-\u0020\u007f]/.test(value)) return false;
    try { const u = new URL(value); return !!u.hostname && !u.username && !u.password; }
    catch { return false; }
  }
  const md = new MarkdownIt({ html: false, breaks: true, linkify: false, typographer: false });
  md.validateLink = safeLink;
  // No remote images/tracking requests and no SVG/HTML from model output.
  md.renderer.rules.image = (tokens, index, options, env, renderer) =>
    '<span class="image-placeholder">[Image: ' + md.utils.escapeHtml(renderer.renderInlineAsText(tokens[index].children || [], options, env)) + ']</span>';
  const linkOpen = md.renderer.rules.link_open || ((tokens, index, options, env, renderer) => renderer.renderToken(tokens, index, options));
  md.renderer.rules.link_open = (tokens, index, options, env, renderer) => {
    tokens[index].attrSet('rel', 'noopener noreferrer');
    tokens[index].attrSet('title', tokens[index].attrGet('href'));
    return linkOpen(tokens, index, options, env, renderer);
  };
  return { render: text => md.render(String(text || '')), safeLink };
});
