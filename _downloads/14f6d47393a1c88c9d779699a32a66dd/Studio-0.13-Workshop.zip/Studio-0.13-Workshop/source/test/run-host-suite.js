const {spawnSync}=require('node:child_process');
const {hostExecutable}=require('./host-executable');
(async()=>{
 const executable=await hostExecutable();
 const suite=require('node:crypto').randomBytes(6).toString('hex');
 for(const [run,file,phase] of [['experience13-ci','experience-host13.js',''],['ecosystem12-ci','ecosystem-host12.js',''],['project11-ci','project-host11.js',''],['workflow10-ci','workflow-host.js',''],['runtime10-ci','runtime-host10.js',''],['history10-ci','history-host082.js','save'],['history10-ci','history-host082.js','restore']]){
  const result=spawnSync(process.execPath,['test/run-host.js'],{stdio:'inherit',windowsHide:true,env:{...process.env,VSCODE_EXECUTABLE:executable,MACSTUDIO_TEST_RUN:run+'-'+suite,MACSTUDIO_HOST_TEST:file,STUDIO082_PHASE:phase}});
  if(result.status!==0)throw Error('Native host failed: '+file+' '+phase);
 }
})().catch(e=>{console.error(e);process.exitCode=1;});
