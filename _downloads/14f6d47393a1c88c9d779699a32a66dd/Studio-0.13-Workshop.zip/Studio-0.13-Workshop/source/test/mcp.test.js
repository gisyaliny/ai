const {test}=require('node:test');
const assert=require('node:assert/strict');
const http=require('node:http');
const {Server}=require('@modelcontextprotocol/sdk/server/index.js');
const {StreamableHTTPServerTransport}=require('@modelcontextprotocol/sdk/server/streamableHttp.js');
const {ListToolsRequestSchema,CallToolRequestSchema}=require('@modelcontextprotocol/sdk/types.js');
const {ReadonlyMcp,validateServer,permitted}=require('../src/mcp');
test('MCP config requires secure endpoints, explicit allowlists and scoped secret names',()=>{
  const config={id:'fixture',url:'http://127.0.0.1:1234/mcp',allowedTools:['read']};
  assert.ok(validateServer(config));
  for(const url of ['http://example.com/mcp','https://user:pass@example.com/mcp','https://example.com/mcp?token=secret'])assert.throws(()=>validateServer({...config,url}));
  assert.throws(()=>validateServer({...config,tokenSecret:'macstudio.apiKey'}));
  assert.equal(permitted({name:'read',annotations:{readOnlyHint:true}},config),true);
  assert.equal(permitted({name:'read'},config),false);assert.equal(permitted({name:'read',annotations:{readOnlyHint:true,destructiveHint:true}},config),false);
});
test('real HTTP MCP: discovery, credential, allowlist, invocation, changed metadata, bounded results, close',async t=>{
  let readOnly=true,executed=0,large=false,huge=false;const active=new Set();
  const web=http.createServer(async(req,res)=>{
    if(req.headers.authorization!=='Bearer fixture-token'){res.writeHead(401);res.end();return;}
    if(req.method!=='POST'){res.writeHead(405);res.end();return;}
    const server=new Server({name:'fixture',version:'1'},{capabilities:{tools:{}}});active.add(server);
    const transport=new StreamableHTTPServerTransport({sessionIdGenerator:undefined,enableJsonResponse:true});
    server.setRequestHandler(ListToolsRequestSchema,()=>({tools:[
      {name:'read',description:'read fixture',inputSchema:{type:'object',properties:{}},annotations:{readOnlyHint:readOnly,destructiveHint:false}},
      {name:'write',inputSchema:{type:'object'},annotations:{readOnlyHint:false}},
      {name:'unlisted',inputSchema:{type:'object'},annotations:{readOnlyHint:true}},
      {name:'no_hint',inputSchema:{type:'object'}}]}));
    server.setRequestHandler(CallToolRequestSchema,request=>{assert.equal(request.params.name,'read');executed++;return {content:[{type:'text',text:huge?'x'.repeat(2_100_000):large?'x'.repeat(30000):'fixture data'}]};});
    res.on('close',()=>{server.close().catch(()=>{});active.delete(server);});
    try{await server.connect(transport);await transport.handleRequest(req,res);}catch{if(!res.writableEnded)res.end();}
  });
  await new Promise(resolve=>web.listen(0,'127.0.0.1',resolve));
  const client=new ReadonlyMcp();t.after(async()=>{await client.close();await Promise.allSettled([...active].map(s=>s.close()));web.closeAllConnections();await new Promise(r=>web.close(r));});
  const config={id:'fixture',url:`http://127.0.0.1:${web.address().port}/mcp`,allowedTools:['read','write','no_hint'],tokenSecret:'macstudio.mcp.fixture'};
  await client.connect([config],{get:async()=> 'fixture-token'});assert.equal(client.definitions().length,1,JSON.stringify(client.status));
  const name=client.definitions()[0].function.name;
  assert.equal((await client.call(name,{})).content[0].text,'fixture data');assert.equal(executed,1);
  await assert.rejects(client.call('write',{}),/允许列表/);
  readOnly=false;await assert.rejects(client.call(name,{}),/不再声明/);assert.equal(executed,1);
  readOnly=true;large=true;assert.equal((await client.call(name,{})).truncated,true);
  huge=true;await assert.rejects(client.call(name,{}));
  await client.close();assert.equal(client.definitions().length,0);await assert.rejects(client.call(name,{}));
});
