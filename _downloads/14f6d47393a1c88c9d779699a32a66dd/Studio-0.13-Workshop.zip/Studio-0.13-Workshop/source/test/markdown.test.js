const test = require('node:test');
const assert = require('node:assert/strict');
const { render, safeLink } = require('../media/markdown');

test('formats Chinese emphasis, headings, lists, table and escaped code', () => {
  const html = render('# 标题\n\n**加粗** and *italic*\n\n- first\n- second\n\n| A | B |\n|---|---|\n| x | y |\n\n```html\n<script>alert(1)</script>\n```');
  for (const text of ['<h1>标题</h1>', '<strong>加粗</strong>', '<em>italic</em>', '<ul>', '<table>', '&lt;script&gt;']) assert.ok(html.includes(text), text);
  assert.ok(!html.includes('<script>'));
  assert.match(render('**stream'), /stream/);
  assert.match(render('**streamed**'), /<strong>streamed<\/strong>/);
});

test('raw HTML, executable URLs and remote images cannot become active content', () => {
  for (const url of ['javascript:alert(1)', 'command:workbench.action.reloadWindow', 'data:text/html,hello', 'file:///etc/passwd', 'vscode://extension/action', '//example.com', 'https://name:password@example.com']) {
    assert.equal(safeLink(url), false, url);
    assert.ok(!render(`[click](${url})`).includes('<a '), url);
  }
  assert.equal(safeLink('https://example.com\n'), false);
  const html = render('<img src=x onerror=alert(1)>\n<script>alert(1)</script>\n![alt](https://example.com/tracker.png)\n[encoded](jav&#x61;script:alert(1))');
  assert.ok(!/<(?:img|script|iframe)\b|href="(?:javascript|command|data):/i.test(html));
  assert.match(html, /Image: alt/);
  assert.equal(safeLink('https://example.com/docs?q=code#section'), true);
  assert.match(render('[Docs](https://example.com)'), /href="https:\/\/example.com"/);
});
