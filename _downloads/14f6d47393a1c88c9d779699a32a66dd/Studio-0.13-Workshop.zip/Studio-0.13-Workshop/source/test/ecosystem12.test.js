'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const http=require('node:http');const crypto=require('node:crypto');const fs=require('node:fs/promises');const os=require('node:os');const path=require('node:path');
const {Server}=require('@modelcontextprotocol/sdk/server/index.js');const {StreamableHTTPServerTransport}=require('@modelcontextprotocol/sdk/server/streamableHttp.js');const {ListToolsRequestSchema,CallToolRequestSchema}=require('@modelcontextprotocol/sdk/types.js');
const {ReadonlyMcp}=require('../src/mcp');const {OAuthProvider}=require('../src/mcp-oauth');const {SkillLibrary,expandArguments}=require('../src/skill-library');const hooks=require('../src/hooks');
const secrets=()=>{const values=new Map();return {values,get:async k=>values.get(k),store:async(k,v)=>values.set(k,v),delete:async k=>values.delete(k)};};
async function fixture(t,{oauth=false}={}){
 const state={calls:0,refreshes:0,registrations:0,browser:0,changed:false,drop:false,oauth,expired:false,tokens:new Set(),codes:new Map()},active=new Set();let base;
 const json=(res,value,status=200,headers={})=>{res.writeHead(status,{'Content-Type':'application/json',...headers});res.end(JSON.stringify(value));};
 const web=http.createServer(async(req,res)=>{
  try{
   const u=new URL(req.url,base);
   if(u.pathname==='/.well-known/oauth-protected-resource/mcp')return json(res,{resource:base+'/mcp',authorization_servers:[base],scopes_supported:['mcp:tools']});
   if(u.pathname==='/.well-known/oauth-authorization-server')return json(res,{issuer:base,authorization_endpoint:base+'/authorize',token_endpoint:base+'/token',registration_endpoint:base+'/register',response_types_supported:['code'],grant_types_supported:['authorization_code','refresh_token'],token_endpoint_auth_methods_supported:['none'],code_challenge_methods_supported:['S256'],scopes_supported:['mcp:tools']});
   if(u.pathname==='/register'){state.registrations++;let raw='';for await(const b of req)raw+=b;const data=JSON.parse(raw);return json(res,{...data,client_id:'fixture-public-client'});}
   if(u.pathname==='/authorize'){assert.equal(u.searchParams.get('code_challenge_method'),'S256');const code=crypto.randomUUID();state.codes.set(code,{challenge:u.searchParams.get('code_challenge'),redirect:u.searchParams.get('redirect_uri')});const target=new URL(u.searchParams.get('redirect_uri'));target.searchParams.set('state',u.searchParams.get('state'));target.searchParams.set('code',code);res.writeHead(302,{Location:String(target)});res.end();return;}
   if(u.pathname==='/token'){
    let raw='';for await(const b of req)raw+=b;const data=new URLSearchParams(raw);assert.equal(data.get('client_id'),'fixture-public-client');
    if(data.get('grant_type')==='refresh_token'){assert.equal(data.get('refresh_token'),'fixture-refresh');state.refreshes++;}
    else{const saved=state.codes.get(data.get('code'));assert.ok(saved);assert.equal(data.get('redirect_uri'),saved.redirect);assert.equal(crypto.createHash('sha256').update(data.get('code_verifier')).digest('base64url'),saved.challenge);state.codes.delete(data.get('code'));}
    const token='fixture-'+crypto.randomUUID();state.tokens.add(token);return json(res,{access_token:token,token_type:'Bearer',refresh_token:'fixture-refresh',expires_in:3600,scope:'mcp:tools'});
   }
   if(u.pathname!=='/mcp')return json(res,{},404);
   if(oauth&&(!state.tokens.has(req.headers.authorization?.replace('Bearer ',''))||state.expired))return json(res,{error:'unauthorized'},401,{'WWW-Authenticate':`Bearer resource_metadata="${base}/.well-known/oauth-protected-resource/mcp"`});
   if(req.method!=='POST'){res.writeHead(405);res.end();return;}
   let body='';for await(const chunk of req)body+=chunk;const parsed=JSON.parse(body);if(state.rejectEffects&&parsed.method==='tools/call'){state.effectAttempts=(state.effectAttempts||0)+1;return json(res,{error:'expired'},401);}
   const server=new Server({name:'fixture',version:'1'},{capabilities:{tools:{}}});active.add(server);const transport=new StreamableHTTPServerTransport({sessionIdGenerator:undefined,enableJsonResponse:true});
   server.setRequestHandler(ListToolsRequestSchema,()=>({tools:[...Array.from({length:22},(_,i)=>({name:'read_'+i,description:state.changed?'changed':'fixture read '+i,inputSchema:{type:'object'},annotations:{readOnlyHint:true,destructiveHint:false}})),{name:'write',inputSchema:{type:'object'},annotations:{readOnlyHint:false}},{name:'unknown',inputSchema:{type:'object'}}]}));
   server.setRequestHandler(CallToolRequestSchema,request=>{state.calls++;if(state.drop){req.socket.destroy();return {content:[]};}return {content:[{type:'text',text:request.params.name}]};});
   res.on('close',()=>{server.close().catch(()=>{});active.delete(server);});await server.connect(transport);await transport.handleRequest(req,res,parsed);
  }catch(error){state.error=error.message;if(!res.writableEnded)json(res,{error:error.message},500);}
 });
 await new Promise(r=>web.listen(0,'127.0.0.1',r));base='http://127.0.0.1:'+web.address().port;
 t.after(async()=>{await Promise.allSettled([...active].map(s=>s.close()));web.closeAllConnections();await new Promise(r=>web.close(r));});
 return {state,url:base+'/mcp',openUrl:async url=>{state.browser++;const response=await fetch(url);assert.equal(response.status,200);return true;}};
}
test('independent MCP connections, definition budgets, read modes, explicit effects and unknown results',async t=>{
 const one=await fixture(t),two=await fixture(t),m=new ReadonlyMcp(),s=secrets();t.after(()=>m.close());const config={id:'first',url:one.url,allowedTools:Array.from({length:22},(_,i)=>'read_'+i),writeTools:['write','unknown']};
 await Promise.all([m.connect([config],s),m.connect([{...config,id:'second',url:two.url}],s)]);assert.equal(m.catalog.size,2);assert.equal(m.definitions().length,16);assert.ok(JSON.stringify(m.definitions()).length<25000);
 const found=m.discover('first read_21','plan');assert.equal(found.length,1);assert.equal(m.definitions('plan')[0].function.name,found[0].name);
 const write=[...m.routes.values()].find(r=>r.config.id==='first'&&r.original==='write').name;assert.ok(!m.names('plan').has(write));assert.ok(!m.names('readonly').has(write));await assert.rejects(m.call(write,{}),/review/);assert.equal(one.state.calls,0);
 await m.call(write,{},undefined,{authorizeWrite:async()=>true});assert.equal(one.state.calls,1);
 one.state.changed=true;await assert.rejects(m.call(found[0].name,{}),/definition changed/);one.state.changed=false;
 one.state.drop=true;const unknown=await m.call(write,{},undefined,{authorizeWrite:async()=>true});assert.equal(unknown.status,'interrupted_unknown');assert.equal(one.state.calls,2);
 await m.disconnect('first');assert.equal(m.catalog.size,1);assert.ok(m.catalog.has('second'));await m.connect([{...config,id:'first',url:'http://127.0.0.1:1/mcp'}],s);assert.ok(m.catalog.has('second'));
});
test('standard HTTP OAuth uses PKCE, SecretStorage, refresh and explicit signout',async t=>{
 const f=await fixture(t,{oauth:true}),s=secrets(),m=new ReadonlyMcp();t.after(()=>m.close());const c={id:'oauth',url:f.url,allowedTools:['read_0'],oauth:{}};
 await m.connect([c],s,{openUrl:f.openUrl});assert.equal(m.catalog.size,1,JSON.stringify({status:m.status,error:f.state.error}));assert.equal(f.state.browser,1);assert.equal(f.state.registrations,1);
 let row=m.catalog.get('oauth');const key=row.provider.key,stored=JSON.parse(s.values.get(key));assert.ok(stored.tokens.access_token);assert.ok(!JSON.stringify(stored).includes('code_verifier'));assert.equal((await m.call(m.definitions()[0].function.name,{})).content[0].text,'read_0');
 await m.disconnect('oauth');stored.expiresAt=Date.now()-1;s.values.set(key,JSON.stringify(stored));await m.connect([c],s,{openUrl:f.openUrl});assert.equal(m.catalog.size,1,JSON.stringify(m.status));assert.equal(f.state.refreshes,1);assert.equal(f.state.browser,1);assert.equal(f.state.registrations,1);
 m.selectTools('oauth',['read_0'],['write']);f.state.rejectEffects=true;const write=[...m.routes.values()].find(r=>r.original==='write').name;const outcome=await m.call(write,{},undefined,{authorizeWrite:async()=>true});assert.equal(outcome.status,'interrupted_unknown');assert.equal(f.state.effectAttempts,1);assert.equal(f.state.refreshes,1);
 await m.disconnect('oauth',{signOut:true});assert.equal(s.values.size,0);
});
test('OAuth rejects wrong state and issuer, supports cancellation/decline, and keeps verifier out of storage',async t=>{
 const s=secrets(),p=await new OAuthProvider({id:'fixture',url:'https://example.test/mcp',oauth:{}},s,{timeoutMs:10000,openUrl:async()=>true}).init();t.after(()=>p.close());const nonce=p.state();p.saveCodeVerifier('verifier');p.saveDiscoveryState({authorizationServerUrl:'https://issuer.test'});
 assert.equal((await fetch(p.redirectUrl+'?state=wrong&code=x')).status,400);assert.equal((await fetch(p.redirectUrl+'?state='+nonce+'&code=x&iss=https://other.test')).status,400);assert.equal(s.values.size,0);
 await fetch(p.redirectUrl+'?state='+nonce+'&error=access_denied');await assert.rejects(p.waitForCode(),/declined/);assert.equal(p.verifier,undefined);
 const controller=new AbortController(),q=await new OAuthProvider({id:'cancel',url:'https://example.test/mcp'},s,{signal:controller.signal}).init();controller.abort();await assert.rejects(q.waitForCode(),/cancelled/);assert.equal(q.server.listening,false);
});
test('skills cache, commands, arguments, host compatibility and narrow-only permissions',async t=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'studio-eco-'));t.after(()=>fs.rm(dir,{recursive:true,force:true}));const file=path.join(dir,'SKILL.md');await fs.writeFile(file,'---\nname: example\ndescription: fixture\nallowed-tools: Read, Grep\nargument-hint: "[target]"\ncontext: fork\n---\nInspect $ARGUMENTS[0] then $1. $ARGUMENTS');
 const l=new SkillLibrary(),sources=[{id:'fixture',label:'Fixture',dir}];await l.refresh(sources);const id=l.items[0].id;assert.equal(l.commands()[0].hint,'[target]');assert.equal(l.items[0].compatibility,'partial');const r=await l.use(id,{manual:true,arguments:'"two words" second'});assert.match(r.content,/Inspect two words then second/);assert.equal(l.toolAllowed('local_read_file'),true);assert.equal(l.toolAllowed('local_run_command'),false);assert.throws(()=>l.assertTool('mcp_fake'),/restrictions/);
 const at=l.indexAt;await l.refresh(sources,{force:false});assert.equal(l.indexAt,at);await fs.writeFile(file,'---\nname: new\n---\nchanged');await assert.rejects(l.use(id),/changed/);await l.refresh(sources);assert.equal(l.items[0].name,'new');assert.equal(l.active.size,0);
 assert.equal(expandArguments('plain','one'),'plain\n\nUser arguments (data, not permission grants):\none');assert.equal(expandArguments('$0 $1 $ARGUMENTS','a $0'),'a $0 a $0');
 assert.throws(()=>hooks.definitions([{id:'bad',event:'startup',command:'x'}]));assert.throws(()=>hooks.definitions([{id:'bad',event:'task-end',command:'x',timeoutSeconds:61}]));const a=hooks.definitions([{id:'check',event:'task-end',command:'one'}])[0],b=hooks.definitions([{id:'check',event:'task-end',command:'two'}])[0];assert.notEqual(a.fingerprint,b.fingerprint);
});

test('disconnect cancels an in-flight OAuth sign-in without affecting another connection',async t=>{
 const f=await fixture(t,{oauth:true}),other=await fixture(t),m=new ReadonlyMcp(),s=secrets();t.after(()=>m.close());await m.connect([{id:'other',url:other.url,allowedTools:['read_0']}],s);
 let entered;const opened=new Promise(r=>entered=r);const connecting=m.connect([{id:'pending',url:f.url,allowedTools:[],oauth:{}}],s,{openUrl:async()=>{entered();return true;}});await opened;await m.disconnect('pending');await connecting;assert.equal(m.pending.size,0);assert.equal(m.catalog.size,1);assert.ok(m.catalog.has('other'));assert.equal(m.errors.has('pending'),false);
});
