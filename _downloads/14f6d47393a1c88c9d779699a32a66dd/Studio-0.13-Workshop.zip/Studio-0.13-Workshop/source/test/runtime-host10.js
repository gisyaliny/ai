const vscode=require('vscode');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const path=require('node:path');
exports.run=async()=>{
 const ext=vscode.extensions.getExtension('yyang-local.macstudio-assistant');assert.equal(ext.packageJSON.version,require('../package.json').version);
 const a=await ext.activate();await a.ready;await a.newChat();const root=await a.project();
 await vscode.commands.executeCommand('macstudio.open');
 const c=vscode.workspace.getConfiguration('macstudio');await c.update('commandBackgroundSeconds',1,vscode.ConfigurationTarget.Global);await c.update('commandTimeoutSeconds',120,vscode.ConfigurationTarget.Global);
 // Only this isolated fixture host replaces dialogs; production code always prompts.
 const original=vscode.window.showWarningMessage;let approvals=0;vscode.window.showWarningMessage=async()=>{approvals++;return 'Allow exact command for this task';};
 const command=process.platform==='win32'?"Write-Output 'first'; Start-Sleep -Seconds 2; Write-Output 'last'":"printf 'first\\n'; sleep 2; printf 'last\\n'";
 try{
  const result=await a.runCommand(command,root);assert.equal(result.status,'running');assert.equal(approvals,1);
  const same=await a.runCommand(command,root);assert.equal(same.id,result.id);assert.equal(approvals,1);
  assert.equal((await a.commandRunner.wait(result.id,{backgroundAfterMs:Infinity})).exitCode,0);
  await a.runCommand(command,root,undefined,{waitForExit:true});assert.equal(approvals,1);
  a.commandGrants.revoke(a.commandGrants.list(a.task.id)[0].id);await a.runCommand(command,root,undefined,{waitForExit:true});assert.equal(approvals,2);
  a.permission='plan';await assert.rejects(a.runCommand(command,root),/禁止/);a.permission='review';
  await a.checkpoint();const saved=await a.store.read(a.session);assert.equal(saved.schema,2);await a.loadSession(saved);assert.equal(a.commandGrants.list(a.task.id).length,0);assert.equal(a.commandRunner.list(a.task.id).length,3);
  for(let i=0;i<50&&!a.webviewReady;i++)await new Promise(r=>setTimeout(r,100));assert.ok(a.webviewReady);
  await fs.writeFile(path.resolve(__dirname,'../test-results/runtime10-host.json'),JSON.stringify({version:ext.packageJSON.version,background:true,noDuplicate:true,exactTaskGrant:true,revoke:true,planDenial:true,schema2:true,noRestoredGrant:true,webviewReady:true},null,2));
 }finally{vscode.window.showWarningMessage=original;await a.commandRunner.dispose();}
};
