const vscode=require('vscode');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const path=require('node:path');
const {execFile}=require('node:child_process');
exports.run=async()=>{
  const ext=vscode.extensions.getExtension('yyang-local.macstudio-assistant');assert.equal(ext.packageJSON.version,require('../package.json').version);
  const a=await ext.activate();await a.ready;await a.newChat();const root=await a.project();
  await vscode.commands.executeCommand('macstudio.open');
  for(const name of ['alpha.txt','beta.txt'])await fs.writeFile(path.join(root,name),'0');
  await fs.writeFile(path.join(root,'verify-fixture.cjs'),"const fs=require('node:fs');if(Number(fs.readFileSync('alpha.txt','utf8'))+Number(fs.readFileSync('beta.txt','utf8'))!==3){console.error('Expected total 3');process.exit(1);}console.log('Verified total 3');");
  await a.saveConstraints('Keep public API unchanged');
  a.task.goal='Repair a two-file fixture and verify the sum';a.permission='plan';
  await a.executeTool('local_update_plan',{steps:[{title:'Repair files'},{title:'Run verification'}]});
  a.permission='review';await assert.rejects(a.executeTool('local_propose_edit',{path:'alpha.txt'}),/批准计划/);
  let continuation=0,repairs=0;
  a.send=async text=>{
    continuation++;
    if(text.includes('Verification failed')){repairs++;await a.executeTool('local_propose_edit',{path:'beta.txt',old_text:'1',new_text:'2',summary:'Fix the failed sum'});}
    if(text.includes('verification passed'))await a.executeTool('local_update_plan',{steps:[{title:'Repair files',status:'done'},{title:'Run verification',status:'done'}]});
  };
  await a.approvePlan();assert.equal(continuation,1);
  for(const name of ['alpha.txt','beta.txt'])await a.executeTool('local_propose_edit',{path:name,old_text:'0',new_text:'1',summary:'First attempt'});
  await a.executeTool('local_propose_edit',{path:'created-by-agent.txt',old_text:'',new_text:'fixture',summary:'New file rewind fixture'});
  a.runCommand=async(command,cwd)=>{
    assert.equal(command,'node verify-fixture.cjs');
    return new Promise(resolve=>execFile('node',['verify-fixture.cjs'],{cwd,windowsHide:true},(error,stdout,stderr)=>resolve({exitCode:error?Number(error.code):0,output:stdout+stderr})));
  };
  await a.setVerification('node verify-fixture.cjs');await a.applyAllAndVerify();assert.equal(repairs,1);assert.equal(a.pending.size,1);assert.equal(a.task.checks[0].status,'failed');
  await a.checkpoint();const saved=(await a.store.list()).find(s=>s.session===a.session),calls=continuation;await a.loadSession(saved);assert.equal(continuation,calls);assert.equal(a.task.repairAttempts,1);assert.deepEqual(a.task.constraints,['Keep public API unchanged']);
  await a.applyAllAndVerify();assert.equal(a.task.checks.at(-1).status,'passed');assert.equal(a.task.steps.every(x=>x.status==='done'),true);assert.equal(repairs,1);
  const editFile=async(name,text)=>{const doc=await vscode.workspace.openTextDocument(vscode.Uri.file(path.join(root,name))),edit=new vscode.WorkspaceEdit();edit.replace(doc.uri,new vscode.Range(doc.positionAt(0),doc.positionAt(doc.getText().length)),text);assert.ok(await vscode.workspace.applyEdit(edit));await doc.save();};
  await editFile('alpha.txt','manual edit');await assert.rejects(a.rewind(a.edits[0].id),/后续修改/);assert.equal(await fs.readFile(path.join(root,'beta.txt'),'utf8'),'2');
  await editFile('alpha.txt','1');await a.rewind(a.edits[0].id);
  assert.equal(await fs.readFile(path.join(root,'alpha.txt'),'utf8'),'0');assert.equal(await fs.readFile(path.join(root,'beta.txt'),'utf8'),'0');await assert.rejects(fs.stat(path.join(root,'created-by-agent.txt')),{code:'ENOENT'});
  const length=a.history.length;await a.compact('extract');assert.equal(a.history.length,length);assert.ok(a.compaction.summary.goal);
  await a.attachPath('alpha.txt');assert.equal(a.attachments[0].text,'0');await assert.rejects(a.attachPath('../escape'));
  a.task.steps=[];
  const raced=await a.executeTool('local_propose_edit',{path:'alpha.txt',old_text:'0',new_text:'9',summary:'Race guard fixture'});
  const save=a.checkpoint.bind(a);let injected=false;
  a.checkpoint=async()=>{await save();if(!injected&&a.edits.at(-1)?.status==='applying'){injected=true;await editFile('alpha.txt','manual during save');}};
  await assert.rejects(a.apply(raced.id),/发生变化/);assert.equal(await fs.readFile(path.join(root,'alpha.txt'),'utf8'),'manual during save');
  a.checkpoint=save;a.pending.clear();await editFile('alpha.txt','0');
  const recovery=await a.executeTool('local_propose_edit',{path:'alpha.txt',old_text:'0',new_text:'9',summary:'Interrupted status fixture'});await a.apply(recovery.id);
  a.edits.at(-1).status='applying';await a.reconcileEdits();assert.equal(a.edits.at(-1).status,'applied');assert.equal(await fs.readFile(path.join(root,'alpha.txt'),'utf8'),'9');
  for(let i=0;i<50&&!a.webviewReady;i++)await new Promise(r=>setTimeout(r,100));assert.ok(a.webviewReady);
  await fs.writeFile(path.join(__dirname,'../test-results/workflow-host.json'),JSON.stringify({version:ext.packageJSON.version,planApproval:true,multiFileReview:true,realVerificationFailureAndPass:true,boundedRepairProposal:true,resumeWithoutReplay:true,rewindConflictBlocked:true,multiFileRewind:true,createdFileRewind:true,compactionPreservesHistory:true,attachments:true,applyRaceBlocked:true,interruptedCheckpointReconciled:true,webviewReady:true},null,2));
  console.log('PASS: 0.5 plan -> multi-file apply -> real test failure -> repair -> resume -> pass -> conflict-safe rewind');
};
