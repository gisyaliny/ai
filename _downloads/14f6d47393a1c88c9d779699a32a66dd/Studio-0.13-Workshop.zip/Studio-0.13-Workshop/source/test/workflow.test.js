const {test}=require('node:test');
const assert=require('node:assert/strict');
const {newTask,updatePlan,taskSummary,rewindPlan}=require('../src/workflow');
const {resolveThinking}=require('../src/thinking');
const {hash}=require('../src/files');
test('thinking sends real protocol parameters and refuses unsupported levels',()=>{
  assert.deepEqual(resolveThinking('default','qwen').parameters,{});
  assert.deepEqual(resolveThinking('off','qwen').parameters,{chat_template_kwargs:{enable_thinking:false}});
  assert.deepEqual(resolveThinking('on','qwen').parameters,{chat_template_kwargs:{enable_thinking:true}});
  assert.throws(()=>resolveThinking('high','qwen'));
  for(const level of ['low','medium','high'])assert.deepEqual(resolveThinking(level,'reasoning_effort').parameters,{reasoning_effort:level});
  assert.equal(resolveThinking('high','reasoning_effort').capabilityReported,false);
  assert.equal(resolveThinking('high','auto',{effortLevels:['low','high']}).capabilityReported,true);
  assert.throws(()=>resolveThinking('medium','auto',{effortLevels:['low','high']}));
  assert.throws(()=>resolveThinking('on','qwen',{},'openclaw'));
  assert.throws(()=>resolveThinking('high','auto'));
});
test('plan edits revoke approval while status updates preserve it',()=>{
  const task=newTask('fix');updatePlan(task,[{title:'read'},{title:'test'}]);assert.equal(task.approved,false);
  task.approved=true;updatePlan(task,[{title:'read',status:'done'},{title:'test',status:'running'}]);assert.equal(task.approved,true);
  updatePlan(task,[{title:'delete something'}]);assert.equal(task.approved,false);assert.equal(task.status,'awaiting_plan');
  assert.throws(()=>updatePlan(task,[{title:'oops',status:'approved'}]));
});
test('rewind composes a multi-file chain and detects intervening changes or unknown operations',()=>{
  const edit=(id,relative,original,updated,exists=true)=>({id,relative,original,updated,originalHash:hash(original),target:relative,exists,status:'applied'});
  const edits=[edit('a','a.txt','old','new'),edit('b','b.txt','','created',false),edit('c','a.txt','new','final')];
  const plan=rewindPlan(edits,'a');assert.equal(plan.files.length,2);assert.equal(plan.files[0].expectedHash,hash('final'));assert.equal(plan.files[0].restoreText,'old');assert.equal(plan.files[1].restoreExists,false);
  assert.throws(()=>rewindPlan([...edits,edit('d','a.txt','user edit','another')],'a'),/外部修改/);
  assert.throws(()=>rewindPlan([...edits,{...edit('d','c.txt','a','b'),status:'applying'}],'a'),/中断/);
});
test('structured compaction includes goals, requests, checks and unresolved operations',()=>{
  const task=newTask('repair');task.steps=[{title:'test',status:'pending'}];task.checks=[{command:'npm test',status:'failed',result:{exitCode:1,output:'failed fixture'}}];
  const summary=taskSummary(task,[{role:'user',content:'keep compatibility'}],[{name:'command',status:'interrupted_unknown'}],[{relative:'a.js',status:'applied'}]);
  assert.deepEqual(summary.changedFiles,['a.js']);assert.deepEqual(summary.unfinished,['test']);assert.equal(summary.verification[0].exitCode,1);assert.equal(summary.operationsToCheck.length,1);assert.equal(summary.userRequests[0],'keep compatibility');
});
