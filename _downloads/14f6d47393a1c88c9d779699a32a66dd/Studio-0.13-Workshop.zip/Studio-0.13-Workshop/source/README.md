# Studio 0.13.0 development preview — M0 through M4

This is a development build for the 1.0 milestones, not the stable release.
See [M4.md](M4.md) for read-only subagents, local history and connection setup.
See [M2-M3.md](M2-M3.md) for grouped changes, project tools, skill commands, reviewed MCP effects, OAuth and hooks. See [DEVELOPMENT.md](DEVELOPMENT.md) for build commands, permissions, persistence, limitations and rollback.

# Mac Studio Assistant 0.9.0

## 0.9 — Local images, durable jobs, and a Tools center

- **Tools** shows the configured language model, connection/device status, ComfyUI queue, skills, connected read-only MCP tools, and separate image/file/terminal controls. File and terminal operations run on the extension host; model inference and ComfyUI run on the SSH server. Disabling client tools does not sandbox tools independently provided by an external gateway.
- **+ → Attach image**, paste, or drop PNG/JPEG images into chat. Up to three images per message, 8 MB each, maximum 2048 pixels per side. A vision-capable model is required; text-only models cannot analyze images.
- **Tools → ComfyUI → Check connection**, then **+ → Generate image** or ask the agent to create an image. Review the prompt, size, model, steps and count on the card and approve generation. No image job is submitted before approval. Plan/read-only modes cannot generate images.
- Choose **Reference image** to edit an attached image, or **Use as reference** on a generated image. Open and save output images directly from the card. This is reference-conditioned editing, not masked inpainting.
- Jobs show queued/loading/generating/decoding/completed/error states when the server reports them. Cancel targets only that job. Reconnection/restart checks the existing job ID; uncertain submissions are never automatically replayed. Remote receipt files hold only job IDs, endpoint hashes and timestamps.
- Chats, image metadata/binaries and job records stay in extension global storage (`sessions`, `images`, `image-jobs`). Images are sent to the selected model/ComfyUI only when requested. Locally cached outputs remain available even if the remote server clears its history. Unknown jobs require inspection or a new explicitly approved request.
- The composer reports request waiting time, first-token latency and last-call duration. Device and model status are reported by the configured server rather than inferred from the model name.

### ComfyUI setup

Use an already running **ComfyUI 0.41+** on the SSH server, listening on loopback. Enable `macstudio.comfy.enabled` or use Check connection. Default URL: `http://127.0.0.1:8188`. Configure `comfy.model`, `comfy.encoder` and `comfy.vae` to match the files shown by the server. The current two built-in workflows support **FLUX.2 Klein**; arbitrary workflow graphs, automatic downloads and custom-node installation are not included.

The default distilled Klein workflow uses 4 steps / CFG 1. A base model uses CFG 5 and typically needs more steps (start with 20). Supported request limits: 1–4 images, 1–40 steps, dimensions divisible by 16, 256–1536 per side and at most one megapixel. The service must retain its job history for remote recovery; local cached images survive independently. Keep the language-model and image-model memory needs in mind when running both services.

### 使用提示

打开 **工具 → ComfyUI → 检查连接**，用 **＋ → 生成图片** 填写描述，审核卡片后生成。图片可粘贴、拖入、保存，也可用作参考图。聊天和图片保存在本机，重启后可从 **历史** 加载；中断任务不会自动重新提交。界面跟随 VS Code 显示语言。



## 0.8.2 本地历史与响应优化

- 顶部时钟图标 **历史 / History** 打开可搜索的本地聊天记录，按标题、项目名或日期查找。选择记录后恢复消息、工具结果、待审阅修改、固定约束与任务状态；恢复不会执行工具。选择其他项目的记录会在新窗口打开对应项目。
- 统一保存到 VS Code 扩展的 `globalStorage/yyang-local.macstudio-assistant/sessions`。Windows 默认位置为 `%APPDATA%/Code/User/globalStorage/yyang-local.macstudio-assistant/sessions`；其他发行版、Profile、便携模式或 Remote 扩展宿主的位置可能不同。记录是本机 JSON，聊天本身不上传到 GitHub；发送消息时，相关历史仍会发给你配置的模型。
- 首次启动复制旧工作区的会话到统一目录，保留原文件。恢复续篇按同一对话分组，底层快照保留；空记录不显示。不再因最近 100 个文件的限制而找不到较早对话。
- 新安装默认模型为 `qwen3.8-flash-next-abliterated-q6`。需要服务端确实部署该 ID；版本升级不会覆盖用户已选择的其他模型。
- `macstudio.skillRouting = integrated` 默认在正常工具调用中选择 skill，省去额外分类请求；需要独立预分类时可改回 `preflight`。自动/手动技能选择偏好保持有效。Direct 模式也省去每轮只为读取模型 ID 的 SSH 请求。
- 修复 llama.cpp router 模式的能力查询：查询所选模型，而不是空的路由器模板。

### 设置建议

保留 `contextTokens = 32768`、`maxOutputTokens = 4096`、`maxToolRounds = 12`，有具体长任务需要时再扩大。上下文预算应低于服务实际容量；262K 的模型容量并不要求每轮都发送 262K。`timeoutSeconds = 600` 只是等待上限，不是速度开关。`useServerTokenizer = false` 可避免额外网络往返，仍会执行保守预算检查；精确计数有需要时再启用。

Qwen 日常任务可设 `thinkingProtocol = qwen`、`thinkingLevel = off`；复杂调试和规划可在模型菜单切换 On。这会改变推理行为，并非无损加速。插件通用默认仍使用服务器 thinking 默认值，不擅自覆盖其他用户的选择。大模型按需加载、其他客户端请求及模型切换都可能影响首个响应时间。

## 0.8.1 界面修复

连接按钮改为项目行右侧的文字按钮；设置入口常驻右上角。顶部图标使用 32px 点击区域和原生前景色，修正操作区居中、更多菜单错位及省略号过淡的问题。新增 280–900px 宽度的布局和点击回归检查。

## 0.8 复用已有 Skills 与 MCP

点击 **＋ → 连接已有工具**，选择技能库或 MCP 配置。发现配置时不会启动进程，也不修改 Codex / Claude Code 原配置。

### 共享技能库

- 项目目录支持 `.agents/skills`、`.claude/skills`、`skills`。用户选择连接后，可复用用户级 Agent Skills、Codex、Claude Code 及其缓存插件目录；可添加自定义目录。缓存目录不代表插件已启用，必须明确选择来源。
- **＋ → Skills** 可手动选择最多三个、切换自动/手动模式、启用或禁用单个技能，以及查看实际使用的技能和选择原因。也支持 `$skill-name`；重名时建议使用选择器指定来源。
- 自动模式先提供精简元数据，默认在正常工具调用中激活匹配技能。可选 `preflight` 会额外进行一次禁止工具调用的分类请求，验证返回的 ID 后加载正文；分类独立检查预算，报告的 token 计入累计用量。失败可改为手动选择。OpenClaw 网关不执行额外分类请求。
- 后续可使用 `local_find_skills` 搜索、`local_use_skill` 激活、`local_read_skill_resource` 读取该技能目录中的引用或脚本文本。读取脚本不会执行；执行仍经过原有命令审批。图片、二进制资源、跨技能目录引用不在此版本支持范围内。
- 遵守 `disable-model-invocation: true` 及 `agents/openai.yaml` 的 `allow_implicit_invocation: false`。Claude 专属 Hooks、子代理配置、预授权以及专属账号/插件不会自动迁移。
- 每轮最多三个活跃技能；正文与单份引用最多 24,000 字符，超限报错。扫描上限 400 个技能 / 3,000 个目录；元数据目录默认 8,000 字符，截断会提示，模型仍可搜索未列出的技能。
- 每轮重新索引，已加载的正文和引用在本轮保持快照。原文件不复制、不改写。技能正文和所读引用会进入模型上下文或本地会话。
- 用户设置 `macstudio.skillLibraryPaths` 可登记可信绝对目录。支持 `CODEX_HOME`、技能目录的 `CLAUDE_CONFIG_DIR`；来源与执行位置均是扩展宿主环境。

### 导入 MCP

支持 Codex 用户/项目 `config.toml` 中的 `mcp_servers`、Claude Code 用户 `~/.claude.json` 中用户/当前项目定义，以及项目 `.mcp.json`。这是受限适配，不继承完整原应用设置、组织策略或授权。

1. **＋ → 连接已有工具 → 导入 MCP 配置**，查看来源、范围及协议。
2. 选择测试连接。HTTP 连接和 stdio 启动需明确确认；stdio 仅在审阅模式下允许启动，进程拥有当前用户权限。
3. 只选择明确声明只读且未声明破坏性的工具。没有符合条件的工具时不启用；只读声明并不是沙箱。
4. 支持 Streamable HTTP 和 stdio。环境变量在连接时解析；凭据仅用于本机连接，不进入模型或会话。独立手动凭据仍使用 SecretStorage。
5. OAuth、云端或进程内连接器、专属运行环境不自动迁移。缺少运行时、环境变量或认证时显示诊断。
6. 导入记录只保存配置指纹与工具列表，不保存原配置。调用前检查来源变化，变化后需重新连接。不会自动启动已导入服务。

来源禁用项、工具允许/排除列表和常见 Claude 项目启用/禁用列表会被检查。一次导入连接管理一个服务，连接新服务会断开上一个；原有 `macstudio.mcpServers` 多 HTTP 服务入口仍可使用，二者共享连接池。

## 0.7 界面与语言

界面跟随 **VS Code 显示语言**，优先于操作系统区域设置。中文语言环境使用简体中文，其他语言目前回退英文。修改 VS Code 的显示语言后按其提示重启窗口。模型回答、项目文件名、用户内容及外部命令/服务输出保持原文；已有会话记录不重新翻译。

- 输入框旁统一放置 `＋`、执行权限、模型/Thinking 和发送；顶部只保留连接状态、会话入口及上下文用量。
- `＋` 收纳项目文件、当前文件、选中代码、Skills 和只读 MCP；附件可逐个移除。MCP 凭据移到高级设置。
- 模型面板读取服务返回的真实模型列表，可搜索并直接选择；切换模型保留会话，Thinking 恢复默认。Qwen/OpenClaw 模式由远端配置决定模型，不伪造可选项。
- 主区域合并为 **对话 / 工作**，工作页集中修改、计划、固定约束、验证、检查点与摘要。
- 默认英文及中文语言包覆盖界面标签、命令面板、扩展设置说明与常用确认对话框；中文用户请求不会触发界面语言切换。


Windows / macOS / Linux VS Code 客户端经 SSH 使用远端本地模型，文件工具在扩展宿主所在电脑执行。当前实际验证环境：Windows x64 客户端、macOS 模型服务。

## 安装与开始

1. 安装 `macstudio-assistant-0.8.1.vsix`，运行 **Developer: Reload Window**。从 0.3 或更早版本升级前请复制仍需要的聊天。0.4 会话可恢复，但升级前未生成的文件检查点无法补建。
2. 用 **File → Open Folder** 打开项目，确认工作区可信。
3. 在扩展设置配置 SSH 主机、私钥路径、远端 loopback Base URL 和 Model ID。服务器指纹需预先验证；插件不自动接受未知指纹。
4. 打开 Mac Studio 侧栏，在模型面板的高级设置中选择 **Mac API · 编程助手**，点击顶部连接状态。API Key 通过密码输入框保存到 VS Code SecretStorage。
5. 选择 **只读**、**计划** 或 **审阅后修改**。修改需查看差异后点击 **应用并保存**；每条终端命令单独确认。

默认使用 `macstudio` SSH 别名、`~/.ssh/id_ed25519`、远端 `http://127.0.0.1:11436/v1`。按你的环境调整。请求通过 SSH 标准输入传入临时 Python 桥接进程，不需要转发 HTTP 端口。

## 0.6 约束、语义压缩与界面

- **工作 → 固定约束**：每行一条，保存后逐字写入每次编程请求，随会话恢复。最多 30 条、每条 2000 字符、合计 12,000 字符；超限拒绝保存，不静默截断。变更约束会撤销已有计划批准。自然语言约束不是执行沙箱。
- **`/compact`** 或 **压缩上下文**：调用当前配置的模型生成语义摘要，保留决定、下一步和原文约束候选。候选需点击 **确认并固定** 才成为固定约束。最近一轮和完整原始历史保留。摘要可能遗漏细节，不替代工具证据。
- 每次编程请求前检查预算；旧历史过大时先尝试语义压缩。最多 8 次分批摘要调用，沿用当前 Thinking 参数，每次预留输出和安全余量。失败保留旧摘要并明确提示使用预算裁剪；取消不会替换摘要。摘要调用的服务报告 token 计入累计用量。
- **`/compact extract`** 是不调用模型的提取式备选。OpenClaw 网关只支持此方式，避免让远程 agent 在摘要阶段自行使用工具。Mac API / Qwen 模式的摘要请求禁用工具，返回工具调用会被拒绝。
- **输入框内 `@` 补全**：输入路径、用 ↑↓ 选择，Enter/Tab 引用，Esc 关闭；支持带空格路径和中文输入法。候选只读取本地文件名，发送消息才读取附件。尊重忽略规则与敏感路径限制，最多显示 20 项；大项目可输入目录缩小扫描范围。
- **Studio 界面**：连接、历史、模型、Thinking 协议、Skills 与 MCP 分别位于模型面板的高级设置、顶部会话菜单和输入框＋菜单。对话 / 工作 保留，新图标同时提供 SVG 与 PNG，适配深浅色及高对比主题。

## 原有工作流

- **对话 / 工作** 两个页签：折叠工具日志、点击文件名打开编辑器、查看计划和验证结果。
- 输入 `/plan 任务` 生成结构化计划，或在工作页中编辑（用 `|` 分隔步骤）；点击 **批准并执行** 后转入审阅模式。模型修改计划标题会撤销原批准；步骤完成状态标明为模型报告，并不等同于测试通过。
- 在工作页审阅后，可逐文件应用，或点击 **应用全部并验证**。工作页可保存验证命令，每次执行仍需要单独批准。检查失败后默认最多自动请求 2 轮修复提议（`macstudio.maxRepairAttempts`）；每轮修改仍需用户审阅。验证通过后，助手继续整理或执行剩余已批准计划。
- 应用修改前保存文件检查点；**恢复到此修改之前** 会恢复该次及后续受跟踪修改。所有文件先核对哈希，存在人工修改时打开冲突差异并停止。支持删除插件新建的文件，保留原有未保存内容作为恢复基线，恢复后会保存到磁盘。
- 同一会话最多保留 100 次修改检查点。恢复不回滚终端副作用、数据库、远端服务、空目录或聊天记录。多个文件的保存并非数据库事务；若应用或恢复中断，点击 **核对中断检查点** 只读核对当前文件，无法确认的冲突仍需手动处理。
- `/compact extract` 可生成结构化摘录；默认 `/compact` 使用上文所述语义摘要。
- `＋ → 添加文件`使用可搜索文件选择器（最多展示 5000 项）；也可输入 `@"relative/path with spaces.py"`。`/` 提供命令补全：`/plan`、`/compact`、`/review`、`/test`、`/thinking`、`/help`。

## Thinking（思考控制）

模型面板 → 高级设置 → **思考协议** 按钮决定哪些档位可用；档位控制下一轮请求，任务进行时不可更改。

| 协议 | 可选档位 | 实际请求字段 |
| --- | --- | --- |
| Qwen 模板（默认） | 默认 / 关闭 / 开启 | `chat_template_kwargs.enable_thinking: false/true` |
| 分级强度 | 默认 / 关闭 / 低 / 中 / 高 | `reasoning_effort: none/low/medium/high` |
| 自动 | 仅服务报告的能力 | 根据 `/props` 的模板能力选择 |
| 服务默认 / OpenClaw 网关 | 默认 | 不发送覆盖参数 |

**默认** 不发送思考参数，沿用服务默认值。低、中、高不会被伪装成同一个布尔开关。能力未知时手动分级协议可以发送请求，但服务可能忽略它；打开“模型面板 → 高级设置”可查看协议、实际参数和能力报告状态。更换模型后需要重新核实兼容性。

当前 Qwen 服务实测：关闭时无思考流，开启时有思考流；low/high 请求均被接受，但不能据此证明真实推理强度有差异。插件只显示是否收到思考流，不保存或展示独立 reasoning_content/reasoning 字段；若服务把思考混入普通 content，则会按正文处理。`maxOutputTokens` 仍需覆盖模型生成预算；开启思考可能增加延迟和 token 使用，达到上限时提示错误，不会自动重放工具。

设置对应 `macstudio.thinkingProtocol` 和 `macstudio.thinkingLevel`；例如选择分级协议后输入 `/thinking high`。旧 Qwen 桥接强制关闭思考的覆盖已移除。

## 会话与中断恢复

- 消息、完整工具结果、执行记录和待审阅修改保存到 VS Code 扩展工作区存储的 `sessions/`；无工作区时使用扩展全局存储。通过临时文件替换避免半写入 JSON。
- 重启后恢复当前项目最近会话；**历史** 可选择其他会话。恢复创建独立续篇，避免两个窗口覆盖同一记录。选择器展示最近 100 个保存文件；旧文件不会自动删除。
- 工具执行前保存 started 记录，完成后保存结果。恢复不重放工具。中断时没有完成结果的操作标为状态未知，必须先检查真实文件/进程状态。没有自动回滚，也不保证命令的子进程已经退出。
- 待审阅修改恢复后仍核对文件原文与哈希，拒绝覆盖用户后续修改；不会自动应用。
- **新对话** 保存旧会话并开始新会话。保存失败阻止新的工具分发，每份会话上限 24 MB。进程突然退出时尚未完成的流式文字可能丢失；已保存的调用记录用于识别不确定状态。
- 本地 JSON 可能包含代码、命令输出和个人信息，使用系统账号权限保护，**不是加密归档**。认证配置不会写入会话，但用户粘贴的凭据、工具返回的敏感数据仍会成为聊天内容。不要把会话文件提交到公开仓库。

## 模型与上下文

状态区显示请求模型、响应声明的模型、SSH 方式、预算与服务端报告的输入/输出 token。累计值只累计实际报告的用量；缺失报告明确提示。API 模型名称不能证明服务器真正加载了哪些权重。

| 设置 | 默认 | 说明 |
| --- | --- | --- |
| `macstudio.contextTokens` | 32768 | 手动配置容量，不从模型名称推断 262K |
| `macstudio.maxOutputTokens` | 4096 | 每次请求预留输出 |
| `macstudio.includeUsage` | true | 请求流式 usage；服务不支持时手动关闭 |
| `macstudio.useServerTokenizer` | false | 可选尝试 llama.cpp /apply-template 与 /tokenize |
| `macstudio.maxToolRounds` | 12 | 每个用户任务最多模型调用轮数 |

每次模型调用前检查“容量 − 输出预算 − 1024 安全余量”。默认按序列化 UTF-8 字节数加协议开销保守估算，**不是精确 tokenizer，也不是对任意模型的数学上界**。服务端 tokenizer 可用时使用它的结果，否则标明回退估算；服务器仍是最终限制来源。

超预算时先缩短发送的长工具结果，再移除较早的完整轮次，在预算允许时附上简短历史摘录。调用与结果保持配对，本地原始历史保留。压缩不是无损总结，可能需要重新读取细节；最新任务仍超预算则停止并提示缩小范围。

**模型** 按钮读取 /models，让你明确选择 direct 模式下一任务的模型，不自动选列表第一项。Qwen 配置模式每次任务开始读取远端默认模型，中途变化则停止。

## 项目理解与权限

- 可信工作区加载根目录 AGENTS.md / CLAUDE.md，以及最近读取文件（或当前编辑器文件）路径上的同名指令，总计最多 24,000 字符。状态区列出来源。指令不能绕过执行权限。
- local_diagnostics 读取语言扩展提供的编辑器诊断，最多 100 项；不自行编译。空诊断不表示测试通过。
- 搜索按需遍历，尊重 .gitignore 和敏感路径排除，每页 30 条命中，可按目录缩小范围、继续分页。不再只搜索前 400 个文件；扫描上限 100,000 个目录项，返回扫描/跳过/截断状态。目录列表仍最多 400 项，可指定子目录。
- 文本工具读取不超过 160 KB 的文件，优先使用未保存的编辑器内容，支持读取指定行范围。排除常见凭据、构建目录、路径越界和指向项目外的符号链接；不保证识别所有敏感信息。

| 权限 | 读取/搜索/诊断 | 提议修改 | 应用修改 | 终端命令 |
| --- | --- | --- | --- | --- |
| 只读 | 允许 | 阻止 | 阻止 | 阻止 |
| 计划 | 允许，以计划为输出 | 阻止 | 阻止 | 阻止 |
| 审阅后修改 | 允许 | 允许 | 点击应用后 | 每条确认后 |

限制在工具分发、文件应用、命令执行入口实施。任务中不能从界面切换权限。终端拥有系统用户权限，**不是沙箱**，默认 60 秒超时、保留末尾 24 KB 输出。文件工具和任意终端命令的权限边界不同。

## Skills

请使用上文 0.8 的共享技能库入口。原项目目录和手动选择保持兼容。技能提供流程指令，MCP 提供实际工具；它们不会自动继承其他应用的账号或执行权限。

## 只读 MCP

此手动设置入口支持 **Streamable HTTP**；stdio 请使用上文的已有配置导入入口。暂不支持旧 SSE、OAuth 登录和 MCP resources/prompts。只连接可信服务器。远端服务可经已有可信 SSH 转发访问。

在 VS Code **用户设置** 配置；示例端点和工具名需替换为实际服务：

```json
{
  "macstudio.mcpServers": [{
    "id": "docs",
    "url": "http://127.0.0.1:9000/mcp",
    "allowedTools": ["search_docs", "read_doc"],
    "tokenSecret": "macstudio.mcp.docs"
  }]
}
```

1. 需要 Bearer token 时点击 **MCP 凭据**；无需认证时省略 tokenSecret。
2. 点击 **连接只读 MCP**。只暴露允许列表内且声明 readOnlyHint=true、未声明 destructiveHint=true 的工具。
3. 每次调用重新核对声明；配置/凭据改变时断开旧连接。每服务器最多 64 个允许工具，响应限制 2 MB，提供给模型的结果最多 24,000 字符。

只读声明来自服务器，**不是远端执行沙箱**。错误或恶意实现仍可能产生副作用。客户端能限制允许调用哪些工具，无法保证外部服务器内部行为。扩展重启后需重新连接，不复用其他应用的登录。

## 连接与显示

- **Mac API**：直接使用配置的模型 API，本地权限限制有效。
- **Qwen · OpenClaw 配置**：读取远端默认模型与凭据后直接调用模型，不加载 OpenClaw 内部工具。
- **OpenClaw**：请求远端 agent，内部工具/技能/权限由服务器控制。此版禁止在只读/计划模式使用该网关，客户端不能约束网关内部行为。

助手支持 Markdown 加粗、标题、列表、引用、表格和可复制代码块；禁用原始 HTML、远程图片、可执行链接。用户和工具消息显示原文。尚未提供视觉附件、语义索引、系统沙箱、跨工具事务回滚、自动项目记忆、通用 Hooks 或子代理调度。

## 开发验证

```sh
npm ci
npm test
npm run build
npm run package
```

- npm test：会话恢复、权限、预算、搜索、诊断、Markdown、路径约束与真实 loopback HTTP MCP。
- Windows 离线宿主测试：设置 MACSTUDIO_HOST_TEST=workflow-host.js 后运行 npm run test:host；使用独立 VS Code profile 与合成项目。
- 实际服务测试：设置 MACSTUDIO_SSH_HOST 后运行 node test/live-features.js；凭据在远端读取，仅发送合成文本，验证 usage、模型元数据、切换保护。
- test/preview.js 使用实际 Webview 生成合成预览；test/browser-workflow.js 用 Playwright CLI 验证界面，不是用户会话截图。

安装包不包含测试会话、密钥或用户项目。插件没有遥测；模型和 MCP 服务的数据处理取决于服务器配置。


0.5 实测脚本：`test/workflow-host.js` 验证审批、跨文件修改、真实测试失败/修复/通过、恢复与冲突拦截；`test/agent05-host.js` 需要 MACSTUDIO_SSH_HOST，使用实际模型完成合成任务；`test/live-thinking.js` 检查思考参数的服务端响应。
