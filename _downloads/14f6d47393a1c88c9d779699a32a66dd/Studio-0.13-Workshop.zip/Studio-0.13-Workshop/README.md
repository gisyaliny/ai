# Studio 0.13 advanced workshop

Start with Lab 9: https://gisyaliny.github.io/ai/docs/workshops/macstudio-agent/09-studio-preview-and-connection.html

Development preview, not final 1.0. See source/M4.md and source/DEVELOPMENT.md.
Windows: run install-preview.ps1 next to the VSIX; Linux/macOS: code --install-extension macstudio-assistant-0.13.0-preview.vsix --force.
Create a new disposable project with python exercises/make_fixture.py studio-demo (python3 on Linux/macOS).
The initial math.test.cjs assertion is intentionally failing.
Run npm ci in source/ (npm.cmd on Windows) before node exercises/workshop-mcp.cjs from this folder.
No personal settings, model weights, API keys, session records or generated test profiles are distributed.
