﻿#Requires -Version 5.1
<#
.SYNOPSIS
Verify and install the bundled Mac Studio Assistant 0.13.0 VS Code extension.
.EXAMPLE
powershell -NoProfile -ExecutionPolicy Bypass -File .\install-preview.ps1
.EXAMPLE
.\install-preview.ps1 -VerifyOnly
#>
[CmdletBinding()]
param(
    [string]$CodePath,
    [string]$ExtensionsDir,
    [switch]$VerifyOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$extensionId = 'yyang-local.macstudio-assistant'
$version = '0.13.0'
$packagePath = Join-Path $PSScriptRoot "macstudio-assistant-$version-preview.vsix"
$expectedHash = '2FDA545FF1C3E05F2FEBFDC994196C3A59C9249231E83CD251105FFCEC4A4A66'

try {
    if (-not (Test-Path -LiteralPath $packagePath -PathType Leaf)) {
        throw 'VSIX not found. Download the entire macstudio-assistant folder, not just install-preview.ps1.'
    }
    # .NET hashing also works when another PowerShell runtime shadows Get-FileHash.
    $stream = [System.IO.File]::OpenRead($packagePath)
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    try { $actualHash = [System.BitConverter]::ToString($sha256.ComputeHash($stream)).Replace('-', '') }
    finally { $stream.Dispose(); $sha256.Dispose() }
    if ($actualHash -ne $expectedHash) {
        throw 'SHA-256 mismatch. Installation stopped; download a fresh copy of this release.'
    }
    Write-Host "Verified Mac Studio Assistant $version (SHA-256)."
    if ($VerifyOnly) { exit 0 }

    if (-not $CodePath) {
        $cli = Get-Command code -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($cli) { $CodePath = $cli.Source }
        else {
            foreach ($base in @($env:LOCALAPPDATA, $env:ProgramFiles, ${env:ProgramFiles(x86)})) {
                if (-not $base) { continue }
                foreach ($relative in @('Microsoft VS Code\bin\code.cmd', 'Programs\Microsoft VS Code\bin\code.cmd')) {
                    $candidate = Join-Path $base $relative
                    if (Test-Path -LiteralPath $candidate -PathType Leaf) { $CodePath = $candidate; break }
                }
                if ($CodePath) { break }
            }
        }
    }
    if (-not $CodePath -or -not (Test-Path -LiteralPath $CodePath -PathType Leaf)) {
        throw 'VS Code CLI not found. Install VS Code or pass -CodePath pointing to bin\code.cmd.'
    }
    $cliArgs = @()
    if ($ExtensionsDir) { $cliArgs += @('--extensions-dir', $ExtensionsDir) }
    & $CodePath @cliArgs --install-extension $packagePath --force
    if ($LASTEXITCODE -ne 0) { throw "VS Code installation failed (exit $LASTEXITCODE)." }

    $installed = @(& $CodePath @cliArgs --list-extensions --show-versions)
    if ($LASTEXITCODE -ne 0) { throw 'Could not verify installed extensions.' }
    if ($installed -notcontains "$extensionId@$version") { throw "Installation verification failed: expected $extensionId@$version." }
    Write-Host "Installed and verified $extensionId@$version."
    Write-Host 'In VS Code: Ctrl+Shift+P -> Developer: Reload Window.'
    Write-Host 'Open a project, then configure your SSH host, model endpoint, model ID and API key.'
    Write-Host 'Development preview: use Tools -> Set up connection. Existing connection settings are preserved.'
    exit 0
}
catch {
    Write-Error -Message $_.Exception.Message -ErrorAction Continue
    exit 1
}
