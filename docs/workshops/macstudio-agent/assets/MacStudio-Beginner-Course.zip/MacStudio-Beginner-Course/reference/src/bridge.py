"""Ephemeral SSH bridge. Credentials are passed over SSH or loaded remotely; stdout is protocol only."""
import json
import os
import sys
import urllib.request
import urllib.error
from urllib.parse import urlparse


def main():
    request = json.load(sys.stdin)
    mode = request.get('mode', 'openclaw')
    payload = request.get('payload', {})
    if mode != 'direct':
        with open(os.path.expanduser(request['config']), encoding='utf-8') as f:
            config = json.load(f)
    if mode == 'direct':
        direct = request.get('direct', {})
        base = direct.get('baseUrl', '').rstrip('/')
        parsed = urlparse(base)
        if parsed.scheme not in ('http', 'https') or parsed.hostname not in ('localhost', '127.0.0.1', '::1') or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError('Direct endpoint must be a loopback HTTP(S) URL on the Mac')
        key = direct.get('apiKey')
        payload['model'] = direct.get('model')
        if not isinstance(payload['model'], str) or not payload['model'].strip():
            raise ValueError('Model ID is required')
    elif mode == 'openclaw':
        gateway = config.get('gateway', {})
        base = 'http://127.0.0.1:' + str(int(gateway.get('port', 18789))) + '/v1'
        auth = gateway.get('auth', {})
        key = auth.get('token') if auth.get('mode', 'token') == 'token' else auth.get('password')
        payload['model'] = 'openclaw/main'
    elif mode == 'qwen':
        primary = config['agents']['defaults']['model']['primary']
        provider_id, model_id = primary.split('/', 1)
        provider = config['models']['providers'][provider_id]
        base, key = provider['baseUrl'].rstrip('/'), provider.get('apiKey')
        if urlparse(base).hostname not in ('localhost', '127.0.0.1', '::1'):
            raise ValueError('Direct model must run on the remote Mac loopback interface')
        payload['model'] = model_id
        payload['chat_template_kwargs'] = {'enable_thinking': False, 'reasoning_effort': 'none'}
        payload.update(temperature=0.7, top_p=0.8, presence_penalty=1.5)
    else:
        raise ValueError('Unknown mode')
    if not isinstance(key, str) or not key:
        raise ValueError('Remote credential is missing or uses an unsupported SecretRef')
    probe = request.get('operation') == 'probe'
    url = base + ('/models' if probe else '/chat/completions')
    headers = {'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'}
    req = urllib.request.Request(url, data=None if probe else json.dumps(payload).encode(), headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=int(request.get('timeout', 600))) as response:
            if probe:
                data = json.load(response)
                print(json.dumps({'ok': True, 'mode': mode, 'models': [x['id'] for x in data.get('data', [])]}), flush=True)
            else:
                for line in response:
                    sys.stdout.buffer.write(line)
                    sys.stdout.buffer.flush()
    except urllib.error.HTTPError as error:
        detail = error.read(4096).decode(errors='replace').replace(key, '[redacted]')
        if error.code == 404 and mode == 'openclaw':
            detail = 'Enable gateway.http.endpoints.chatCompletions.enabled on the Mac.'
        raise RuntimeError('Remote HTTP %s: %s' % (error.code, detail)) from None


try:
    main()
except BrokenPipeError:
    pass
except Exception as error:
    print(str(error), file=sys.stderr)
    sys.exit(1)
