/* All model text is rendered with textContent; never executable HTML. */
const vscode = acquireVsCodeApi();
const el = id => document.getElementById(id);
const send = (type, extra = {}) => vscode.postMessage({ type, ...extra });
let busy = false;
function button(label, action) { const b = document.createElement('button'); b.textContent = label; b.addEventListener('click', action); return b; }
function submit() { const text = el('prompt').value.trim(); if (!busy && text) { send('send', { text }); el('prompt').value = ''; vscode.setState({ draft: '' }); } }
for (const id of ['connect', 'settings', 'attach', 'stop', 'new']) el(id).addEventListener('click', () => send(id));
el('send').addEventListener('click', submit);
el('mode').addEventListener('change', () => send('mode', { value: el('mode').value }));
el('prompt').addEventListener('keydown', event => { if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) { event.preventDefault(); submit(); } });
el('prompt').value = vscode.getState()?.draft || '';
el('prompt').addEventListener('input', () => vscode.setState({ draft: el('prompt').value }));
window.addEventListener('message', event => {
  if (event.data.type !== 'state') return;
  const state = event.data.state; busy = state.busy;
  el('connection').textContent = state.connection; el('mode').value = state.mode;
  el('project').textContent = `Client project: ${state.project}`;
  for (const id of ['send', 'attach', 'mode', 'new']) el(id).disabled = busy;
  el('stop').hidden = !busy;
  const container = el('messages'); const nearBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 100;
  container.replaceChildren();
  if (!state.messages.length) {
    const welcome = document.createElement('div'); welcome.className = 'welcome';
    const title = document.createElement('h2'); title.textContent = 'Your Mac, ready to help.';
    const body = document.createElement('p'); body.textContent = 'Open a project and start chatting. Files are read on demand; edits await review. OpenClaw mode delegates remote capabilities to the server.';
    welcome.append(title, body); container.append(welcome);
  }
  for (const row of state.messages) {
    if (!row.text && !busy) continue;
    const article = document.createElement('article'); article.className = `message ${row.role}`;
    const label = document.createElement('div'); label.className = 'label'; label.textContent = { user: 'You', assistant: 'MAC STUDIO', tool: 'Tool', error: 'Notice' }[row.role] || row.role;
    const body = document.createElement('div'); body.className = 'body'; body.textContent = row.text || 'Thinking...';
    article.append(label, body); container.append(article);
  }
  if (nearBottom) container.scrollTop = container.scrollHeight;
  el('attachments').replaceChildren();
  if (state.attachments.length) { const text = document.createElement('span'); text.textContent = state.attachments.join(' · '); el('attachments').append(text, button('Clear', () => send('clearAttachments'))); }
  el('changes').replaceChildren();
  for (const change of state.pending) {
    const card = document.createElement('div'); card.className = 'change';
    const name = document.createElement('b'); name.textContent = change.path;
    const summary = document.createElement('p'); summary.textContent = change.summary;
    const preview = button('View diff', () => send('preview', { id: change.id }));
    const apply = button('Apply and save', () => send('apply', { id: change.id })); apply.disabled = busy;
    const reject = button('Reject', () => send('reject', { id: change.id })); reject.disabled = busy;
    card.append(name, summary, preview, apply, reject); el('changes').append(card);
  }
});
send('ready');
