// Explicit live test: calls the user's Mac; uses fixture text only, never sends messages.
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const { completion, sshRequest } = require('../src/transport');
async function main() {
  const results = [];
  for (const mode of (process.env.MACSTUDIO_TEST_MODES || 'direct').split(',')) {
    const options = { host: 'macstudio', identity: '~/.ssh/id_ed25519', mode, timeout: 300 };
    if (mode === 'direct') {
      assert.ok(process.env.MACSTUDIO_API_KEY, 'Set MACSTUDIO_API_KEY for the live test');
      options.direct = { baseUrl: 'http://127.0.0.1:11436/v1', model: 'qwen3.8-flash-next-q6', apiKey: process.env.MACSTUDIO_API_KEY };
    }
    const probe = JSON.parse(await sshRequest(options, { mode, operation: 'probe', timeout: 30 }));
    assert.equal(probe.ok, true);
    console.log(mode, 'probe passed');
    const tools = [{ type: 'function', function: { name: 'local_read_file', description: 'Read a test fixture on the CLIENT PC. The remote host cannot read this file.', parameters: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'], additionalProperties: false } } }];
    const session = 'vscode-test:' + Date.now();
    const messages = [{ role: 'system', content: 'Integration test. Use only the supplied client local_read_file function. Do not send messages, access server files, execute commands, or modify anything.' }, { role: 'user', content: 'Call local_read_file with path fixture.txt. After its result, reply only with the code contained in the fixture.' }];
    const started = Date.now();
    const first = await completion(options, { messages, tools, tool_choice: { type: 'function', function: { name: 'local_read_file' } }, max_tokens: 1024, user: session });
    assert.equal(first.tool_calls?.[0]?.function.name, 'local_read_file');
    assert.equal(JSON.parse(first.tool_calls[0].function.arguments).path, 'fixture.txt');
    messages.push(first);
    for (const call of first.tool_calls) messages.push({ role: 'tool', tool_call_id: call.id, content: 'Fixture code: WINDOWS_MAC_BRIDGE_OK' });
    const last = await completion(options, { messages, tools, tool_choice: 'none', max_tokens: 1024, user: session });
    assert.match(last.content, /WINDOWS_MAC_BRIDGE_OK/);
    results.push({ mode, success: true, seconds: (Date.now() - started) / 1000, answer: last.content });
    console.log(mode, 'tool call + tool-result continuation passed', last.content);
  }
  await fs.mkdir(path.join(__dirname, '../test-results'), { recursive: true });
  await fs.writeFile(path.join(__dirname, '../test-results/live.json'), JSON.stringify(results, null, 2));
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
