const { sshRequest, completion } = require('../src/transport');

async function main() {
  if (!process.env.MACSTUDIO_API_KEY) throw new Error('Set MACSTUDIO_API_KEY first');
  const options = {
    host: 'macstudio', identity: '~/.ssh/macstudio_course',
    python: '/usr/bin/python3', mode: 'direct', timeout: 120,
    direct: {
      baseUrl: 'http://127.0.0.1:11436/v1',
      model: 'YOUR_MODEL_ID',
      apiKey: process.env.MACSTUDIO_API_KEY
    }
  };
  console.log(await sshRequest(options, {mode: 'direct', operation: 'probe', timeout: 20}));
  await completion(options, {
    messages: [{role: 'user', content: 'Explain what an extension host does in one sentence.'}],
    max_tokens: 256
  }, undefined, text => process.stdout.write(text));
  process.stdout.write('\n');
}

main().catch(error => { console.error(error.message); process.exitCode = 1; });
