# Mac Studio Assistant — course reference

This English-language reference accompanies ../COURSE.md.

Run `npm ci`, press F5, and open a disposable local project in the Extension Development Host.
Use Mac Studio: Open chat, Direct mode, and your own API key.

Tests: `npm test`, `npm run test:bridge`, `npm run test:live`, `npm run test:host`.
Live tests need MACSTUDIO_API_KEY in the process environment.

Build: `npm run package`. Do not publish under the example publisher ID.
