# Mac Studio VS Code coding-agent course

Start with **[COURSE.md](COURSE.md)**.

The course contains 16 lessons with complete copyable files, an architecture diagram, a first-extension checkpoint, SSH/API diagnostics, a coding exercise, UI implementation, tests, packaging, model-switching behavior, and optional MCP/skills designs.

- `reference/`: completed English-language extension source and dependency lockfile.
- `exercise-project/`: deliberately broken addition function and its test for the hands-on lesson.
- `VALIDATION.md`: what was checked on the real Mac and Windows environment, and what remains outside that evidence.

The archive excludes private keys, service credentials, installed dependencies, VS Code test profiles, and logs. Use your own connection details. The reference uses the same extension ID as the original local extension; prefer F5 development mode until you intend to replace the installed edition.

This is a Markdown course. In VS Code, open COURSE.md and press Ctrl+Shift+V to preview it. Copy code using the fenced blocks in the text editor or your Markdown viewer.
